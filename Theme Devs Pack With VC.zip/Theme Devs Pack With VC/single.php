<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package gonzainsu
 */

get_header();

$meta = get_post_meta(get_the_ID(), 'blog_post_tab', true);

$banner_enable = Corsicana_set($meta,'banner_enable');
$banner_img = Corsicana_set($meta,'banner_img');
$feature_img = Corsicana_set($meta,'feature_img');
$banner_title = Corsicana_set($meta,'banner_title');
$banner_text = Corsicana_set($meta,'banner_text');

?>

<?php if($banner_enable){ ?>


<!--======== PAGE TITLE ========-->
      <section class="page-title-area d-flex align-items-end" style="background-image: url('<?php echo esc_url(Corsicana_set($banner_img,'url')); ?>');">
         <div class="container">
            <div class="row align-items-end">
               <div class="col-md-12">
                  <div class="section-content mb-50 mb-xs-80">
                     <h1><?php echo esc_html($banner_title); ?></h1>
                     <p><?php echo esc_html($banner_text); ?></p>

                     <div class="breadcrumb mt-45 mt-xs-20">
                        <ul>
                           <li><a href="<?php echo esc_url(home_url('/')); ?>"><i class="fal fa-home-lg-alt"></i> Home</a></li>
                           <li><a href="#"><?php the_title(); ?></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--======== PAGE TITLE// ========-->


<?php }else{?>


<!--======== PAGE TITLE ========-->
      <section class="page-title-area d-flex align-items-end" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/page-title/bg.jpg');">
         <div class="container">
            <div class="row align-items-end">
               <div class="col-md-12">
                  <div class="section-content mb-50 mb-xs-80">
                     <h1><?php the_title(); ?></h1>
                     <p>Customized insurance solutions for your unique needs.</p>

                     <div class="breadcrumb mt-45 mt-xs-20">
                        <ul>
                           <li><a href="<?php echo esc_url(home_url('/')); ?>"><i class="fal fa-home-lg-alt"></i> Home</a></li>
                           <li><a href="#"><?php the_title(); ?></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--======== PAGE TITLE// ========-->
		
<?php }?>


      <!--======== BLOG AREA ========-->
      <section class="blog-details pt-120 pb-120 pt-md-80 pb-md-80 pt-xs-70 pb-xs-70">
         <div class="container">
            <div class="row gx-5">
               <div class="col-lg-8 col-md-7">
                  
		<?php while (have_posts()): the_post(); ?>		  
				  
                  <!-- BLOG CONTENT  -->
                  <div class="blog-item">
                     <div class="blog-thumb position-relative mb-30 mb-xs-20">
                        <img class="w-100" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(),'full'));  ?>" alt="">
                        <span class="el-absolute bottom-left text-uppercase fz-2"><?php echo get_the_date(); ?></span>
                     </div>
                     <div class="blog-content">
                        <div class="meta mb-20">
                           <ul class="d-flex align-items-center">
                              <li>By <?php the_author(); ?></li>
                              <li><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/comment.svg" alt=""> <?php comments_number('No Comment', '1 Comment', '% Comments'); ?></li>
                           </ul>
                        </div>
                        <h2 class="mb-30 mb-xs-20"><?php the_title(); ?> </h2>
                        <p> <?php the_content(); ?> </p>

                        <div class="row align-items-center mt-50 mb-50 mt-xs-20 mb-xs-20 mb-md-30 mt-lg-30">
                           <div class="col-xl-6">
                              <p><?php echo Corsicana_set( $meta,'des1');  ?></p>
                              <div class="feature-check-list check-list-2 mt-40 mt-xs-20 mb-xs-30 mb-md-30 mb-lg-30">
                                 <ul>
								 
								 
								  <?php $addlistitems = Corsicana_set($meta,'addlistitems');?>
		
								<?php if (is_array($addlistitems) || is_object($addlistitems)){?>
								
								 <?php foreach ($addlistitems as $addlistitem): ?>
									<?php if(!empty($addlistitem)){?>
										
										  <li> <img src="<?php echo get_template_directory_uri(); ?>/assets/img/icons/check.svg" alt=""> <?php echo Corsicana_set($addlistitem,'tiitlename');?></li>
									<?php }?>
								<?php endforeach; ?>
								
							<?php 	}?> 
					 

									
                                 </ul>
                              </div>
                           </div>
                           <div class="col-xl-6">
                              <img class="border-radius" src="<?php echo Corsicana_set(Corsicana_set( $meta,'bg_image'), 'url');  ?>" alt="">
                           </div>
                        </div>

                        <p><?php echo Corsicana_set( $meta,'des2');  ?></p>

			<?php $viedo_enable = Corsicana_set( $meta,'viedo_enable');  ?>			
			<?php if($viedo_enable){ ?>			
                        <div class="video-box position-relative bg-attachment mt-50 mb-50 mt-xs-30 mb-xs-30" style="background-image: url('<?php echo Corsicana_set(Corsicana_set( $meta,'banner_img'), 'url');  ?>');">
                           <a href="<?php echo Corsicana_set( $meta,'video_url');  ?>" class="video-btn pulse-btn"><span></span></a>
                        </div>
			<?php }else{?>


			<?php }?>
                        <h3 class="mb-30 mb-xs-20"><?php echo Corsicana_set( $meta,'custitle');  ?></h3>
                        <p><?php echo Corsicana_set( $meta,'des3');  ?></p>

					<?php $quote_des = Corsicana_set( $meta,'qute_des');  ?>	
					
				<?php if ($quote_des){?>	
                        <div class="blgo-qoute d-flex align-items-start mt-50 mt-xs-30">
                           <img src="<?php echo get_template_directory_uri(); ?>/assets/img/blog-page/qoute.svg" alt="">
                           <p class="flex-1"><?php echo Corsicana_set( $meta,'qute_des');  ?></p>
                        </div>
						
				<?php }else{}?>		

                        <div class="row mt-30 mb-30 mb-xs-20">
                           <div class="col-6">
                              <img class="border-radius" src="<?php echo Corsicana_set(Corsicana_set( $meta,'gal_ima1'), 'url');  ?>" alt="">
                           </div>
                           <div class="col-6">
                              <img class="border-radius" src="<?php echo Corsicana_set(Corsicana_set( $meta,'gal_ima2'), 'url');  ?>" alt="">
                           </div>
                        </div>
                        <p><?php echo Corsicana_set( $meta,'des4');  ?></p>
                     </div>
                  </div>

				  
				  
              <?php   if ( comments_open() || get_comments_number() ) :
	                comments_template();
	            endif; ?>
				  
		 <?php endwhile;  ?>		  
               </div>
			   
			   
	<?php 
		$terms = get_the_terms( get_the_ID(), 'category' );
			$term_list = wp_list_pluck( $terms, 'slug' );
			$related_args = array(
				'post_type' => 'post',		
				'posts_per_page' => 4,
				'post_status' => 'publish',
				'post__not_in' => array( get_the_ID() ),
				'orderby' => 'rand',
				'tax_query' => array(
					array(
						'taxonomy' => 'category',
						'field' => 'slug',
						'terms' => $term_list
					)
				)
			);
			$query  =  new WP_Query( $related_args );
		?>		
			   
			   
               <div class="col-lg-4 col-md-5">
                  <div class="blog-sidebar mt-xs-70">
                    
					   <div class="recent-blog">
                        <h3 class="mb-40 position-relative">Recent News</h3>
	
			<?php if ($query->have_posts()): ?>
							<?php  while ($query->have_posts()): $query->the_post(); ?>			
                        <!-- single item  -->
                        <div class="blog-item mt-30">
                           <div class="blog-thumb position-relative mb-20">
                              <img class="w-100" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(),'full'));  ?>" alt="">
                              <span class="el-absolute bottom-left text-uppercase"><?php echo get_the_date(); ?></span>
                           </div>
                           <div class="blog-content">
                              <h5><a href="<?php the_permalink()?> "><?php the_title(); ?> </a></h5>
                              <div class="meta">
                                 <ul class="d-flex align-items-center">
                                    <li>By <?php the_author(); ?></li>
                                 </ul>
                              </div>
                           </div>
                        </div>

             <?php endwhile; wp_reset_postdata(); ?>
						<?php endif; ?>   
						
						
                     </div>
					 
					 
                     <div class="sidebar-categories">
                        <h3 class="mb-40 position-relative">Categories</h3>
                        <div class="categories-list">
						
						
						<?php
							  $categories = get_categories();
							  $i = 0;
							  foreach ($categories as $category) {
								$i++;
								echo ' <a href="' . get_category_link($category->term_id) . '">' . $category->name . '<span>' . $category->category_count . '</span></a>';
							  }
					    ?> 

                        </div>
                     </div>
					 
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--======== BLOG AREA// ========-->


<?php get_footer();
