<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <!-- Required meta tags -->
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    	<?php 	
			$options = get_option('platinumeagle');

			$site_fevicon = Corsicana_set($options,'sitefavi');
			$enable_cusmeta = Corsicana_set($options,'enable_cusmeta');
			$site_meta_img = Corsicana_set($options,'site_meta_img');
			$site_meta_des = Corsicana_set($options,'site_meta_des');
		?>
	<?php if ($enable_cusmeta) : ?>		
		<meta property="og:image"  content="<?php echo esc_url($site_meta_img['url']);?>">
		<meta name="description" content="<?php echo $site_meta_des; ?>">
	<?php endif; ?>		
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo $site_fevicon['url']?>">	
	
<?php wp_head(); ?>	
</head>
<?php 	
$options = get_option('kg1forgedv2');

	$site_logo = Corsicana_set($options,'sitelogo');
	$site_logo2 = Corsicana_set($options,'site_logo2');
	$site_fevicon = Corsicana_set($options,'sitefavi');
	$headerbg = Corsicana_set($options,'hedbg');
	$headerphone = Corsicana_set($options,'hphone');
	$headeremail = Corsicana_set($options,'hemail');
	
    
	//contact button
	$contacttext = Corsicana_set($options,'contacttext');
	$contacturl = Corsicana_set($options,'contacturl');
	
	//enable variable
	
	$enable_contact = Platinum_set($options,'enable_contact');
	$enable_email = Platinum_set($options,'enable_email');
	$enable_phone = Platinum_set($options,'enable_phone');
	$enable_chat = Platinum_set($options,'enable_chat');
	$enable_login = Platinum_set($options,'enable_login');
	
	//social
	$enable_fb = Corsicana_set($options,'enable_fb');
	$fb_icon = Corsicana_set($options,'fb_icon');
	$fb_label = Corsicana_set($options,'fb_label');
	$fb_url = Corsicana_set($options,'fb_url');
	$enable_ins = Corsicana_set($options,'enable_ins');
	$ins_icon = Corsicana_set($options,'ins_icon');
	$ins_label = Corsicana_set($options,'ins_label');
	$ins_url = Corsicana_set($options,'ins_url');
	
    
	//copyright content
	
	$foo_text = Corsicana_set($options,'foo_text');

    
    //theme color
    $primaycolor = Corsicana_set($options,'primaycolor');
    $secondarycolor = Corsicana_set($options,'secondarycolor');
     $thirdcolor = Corsicana_set($options,'thirdcolor');
     $headingcolor = Corsicana_set($options,'headingcolor');
    
	
	//icon enable disable 
	
		$enable_contact = Corsicana_set($options,'enable_contact');
		$contact_label = Corsicana_set($options,'contact_label');
		$contact_url = Corsicana_set($options,'contact_url');
		
		$enable_phone = Corsicana_set($options,'enable_phone');
		$phone_icon = Corsicana_set($options,'phone_icon');
		$phone_num = Corsicana_set($options,'phone_num');
		
		$enable_eamil = Corsicana_set($options,'enable_eamil');
		$email_icon = Corsicana_set($options,'email_icon');
		$email_address = Corsicana_set($options,'email_address');
		
		$enable_chat = Corsicana_set($options,'enable_chat');
		$chat_icon = Corsicana_set($options,'chat_icon');
		$chat_label = Corsicana_set($options,'chat_label');
		$chat_url = Corsicana_set($options,'chat_url');


		

?>	

<!--Theme Color Css---->

<style type="text/css"> 

:root {
  --theme-color: <?php echo $primaycolor; ?>;
  --theme-color2:<?php echo $secondarycolor; ?>;
  --text-color:<?php echo $thirdcolor; ?>;
  --heading-color: <?php echo $headingcolor; ?>;
}

</style>

<body <?php body_class();?>>

    <!-- PRELOADER -->
    <div class="preloader">
        <div class="preloder-dotwrap">
            <div class="dot-container">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
            <div class="dot-container">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
            <div class="dot-container">
                <div class="dot"></div>
                <div class="dot"></div>
                <div class="dot"></div>
            </div>
        </div>
    </div>
    <!-- PRELOADER END -->


    <!-- HEADER AREA -->
    <header class="header-area">
        <div class="header-top">
            <div class="container">
                <div class="header-top-inner">
                    <div class="row justify-content-end">
                        <div class="col-md-11 col-lg-9">
                            <div class="header-top-info">
                                <div class="header-contact">
                                    <ul>
									
									<?php if ($enable_phone && $phone_icon && $phone_num) : ?>	
                                        <li>
                                            <a href="tel:<?php echo esc_attr($phone_num); ?>">
                                                <span class="circle-icon">
                                                    <i class="fas fa-<?php echo trim(str_replace('fa fa-','',esc_html($phone_icon))); ?>"></i>
                                                </span>
                                              <?php echo esc_html($phone_num); ?>
                                            </a>
                                        </li>
									<?php endif; ?>	
										
									<?php if ($enable_eamil && $email_icon && $email_address) : ?>		
                                        <li>
                                            <a href="mailto:<?php echo esc_attr($email_address); ?>">
                                                <span class="circle-icon">
                                                    <i class="fas fa-<?php echo trim(str_replace('fa fa-','',esc_html($email_icon))); ?>"></i>
                                                </span>
                                                <?php echo esc_html($email_address); ?>
                                            </a>
                                        </li>
									<?php endif; ?>	
										
                                    </ul>
                                </div>
                                <div class="header-login">
                                    <ul>
									<?php if ($enable_chat && $chat_icon && $chat_label && $chat_url) : ?>	
                                        <li>
                                            <a href="<?php echo esc_url($chat_url); ?>"><?php echo esc_html($chat_label); ?>
                                                <span class="circle-icon">
                                                    <i class="fal fa-<?php echo trim(str_replace('fa fa-','',esc_html($chat_icon))); ?>"></i>
                                                </span></a>
                                        </li>
									<?php endif; ?>		
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-content">
            <div class="container">
                <div class="header-cotent-inner">
                    <div class="row align-items-center">
                        <div class="col-md-2 col-lg-3">
                            <div class="logo">
                                <a href="<?php echo esc_url(home_url('/')); ?>">
                                    <img src="<?php echo esc_url($site_logo['url']);?>" alt="">
                                    <img src="<?php echo esc_url($site_logo2['url']);?>" alt="" class="logo-assist">
                                </a>
                            </div>
                            <div class="sidebar-slide-overlay d-lg-none"></div>

                            <div class="humberger-bar d-lg-none">
                                <span></span>
                                <span></span>
                            </div>

                            <div class="sidebar-slide d-lg-none">
                                <div class="sidebar-menu">
                                    <?php wp_nav_menu(array(
										   'menu' => '', 
										   'items_wrap'=>'%3$s', 
										   'container' => false,
										   'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
										   'theme_location'    => "mobile"
										)); ?>
                                </div>

                                <div class="sidebar-others">
                                    <div class="sidebar-btns text-center">

                                        <ul class="social-list mb-30">
										
										
										<?php $sociamedia=Platinum_set($options,'sociamedia');?>
		
										<?php if (is_array($sociamedia) || is_object($sociamedia)){?>
										
										 <?php foreach ($sociamedia as $socilaitem): ?>
											<?php if(!empty($socilaitem)){?>
											
											 <li>
												<a href="<?php echo esc_url(Platinum_set($socilaitem,'social_url'));?>"
														target="_blank">
														<img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/eagle.png" alt="" class="absolute-img">
														<i class="fab fa-<?php echo trim(str_replace('fa fa-','',esc_html(Platinum_set($socilaitem,'social_icon')))); ?>"></i>
														<?php echo esc_html(Platinum_set($socilaitem,'social_label'));?>
												  </a>
											</li>
											<?php 	}?> 
										<?php endforeach; ?>
										
									<?php 	}?>  
														
			
												
                                        </ul>

										
								<?php if ($enable_contact && $contact_label && $contact_url ) : ?>			
                                        <a href="<?php echo esc_url($contact_url); ?>" class="site-btn"><?php echo esc_html($contact_label); ?></a>
								<?php endif; ?>
                                    </div>

                                    <div class="copyright">
									<?php echo esc_html($foo_text); ?>
                                        
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 d-none d-lg-block">
                            <div class="mainmenu">
                                <?php wp_nav_menu(array(
								   'menu' => '', 
								   'items_wrap'=>'%3$s', 
								   'container' => false,
								   'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
								   'theme_location'    => "main-menu"
								)); ?>
                            </div>
                        </div>
                        <div class="col-lg-2 d-none d-lg-block">
                            <ul class="inline-group">
							
							
							<?php $sociamedia=Platinum_set($options,'sociamedia');?>
		
										<?php if (is_array($sociamedia) || is_object($sociamedia)){?>
										
										 <?php foreach ($sociamedia as $socilaitem): ?>
											<?php if(!empty($socilaitem)){?>
											
											 <li>
												<a href="<?php echo esc_url(Platinum_set($socilaitem,'social_url'));?>" class="hover-circle"> <i class="fab fa-<?php echo trim(str_replace('fa fa-','',esc_html(Platinum_set($socilaitem,'social_icon')))); ?>"></i></a>
											</li>

											<?php 	}?>
										<?php endforeach; ?>
										
									<?php 	}?>  
				
							
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- HEADER AREA// -->