<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package TexasTires
 */

get_header();

$meta = get_post_meta( get_the_ID(), 'page_meta_opt', true );
$banner_enable = Corsicana_set($meta,'banner_enable');
$banner_img = Corsicana_set($meta,'banner_img');
$feature_img = Corsicana_set($meta,'feature_img');
$banner_title = Corsicana_set($meta,'banner_title');
$banner_text = Corsicana_set($meta,'banner_text');

?>

<?php if($banner_enable){ ?>
<!-- PAGE TITLE -->
        <section class="page-title bg-attachment"
            style="background-image: url(<?php echo esc_url(Corsicana_set($banner_img,'url')); ?>)">
            <div class="page-title-img bg-attachment"
                style="background-image: url(<?php echo esc_url(Corsicana_set($feature_img,'url')); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="section-content white-content">
                            <h1><?php echo esc_html($banner_title); ?></h1>
                            <p><?php echo esc_html($banner_text); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- PAGE TITLE// -->
<?php }else{?>

<!-- PAGE TITLE -->
        <section class="page-title bg-attachment"
            style="background-image: url(<?php echo esc_url(Corsicana_set($banner_img,'url')); ?>)">
            <div class="page-title-img bg-attachment"
                style="background-image: url(<?php echo esc_url(Corsicana_set($feature_img,'url')); ?>);"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="section-content white-content">
                            <h1><?php the_title(); ?></h1>                       
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- PAGE TITLE// -->		
<?php }?>


	<main class="main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/content', 'page' );

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php

get_footer();
