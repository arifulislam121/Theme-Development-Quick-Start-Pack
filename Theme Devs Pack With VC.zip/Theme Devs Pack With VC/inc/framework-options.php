<?php

// Control core classes for avoid errors
if (class_exists('CSF')) {

    //
    // Set a unique slug-like ID
    $prefix = 'kg1forgedv2';

    //
    // Create options
    CSF::createOptions($prefix, array(
        'menu_title' => 'KG1 Forged Options',
        'menu_slug'  => 'kg1forged-options',
    ));

    CSF::createSection($prefix, array(
        'title'     => 'General',
        'icon'      => 'fa fa-cog',
        'fields'    => array(
            
                         array(
                'type'    => 'heading',
                'content' => 'Primary Color',
            ),
            array(
                'id'          => 'primaycolor',
                'type'        => 'color',
                'title'       => 'Select Your Primary color',
                'default'      =>'#f8f406'
               
                
            ),
             array(
                'type'    => 'heading',
                'content' => 'Secondary Color',
            ),
            array(
                'id'          => 'secondarycolor',
                'type'        => 'color',
                'title'       => 'Select Your Secondary color',
                'default'      =>'#242424'
               
                
            ),
            array(
                'type'    => 'heading',
                'content' => 'Third Color',
            ),
            array(
                'id'          => 'thirdcolor',
                'type'        => 'color',
                'title'       => 'Select Your Third color',
                'default'      =>'#0e121b'
               
                
            ),
            array(
                'type'    => 'heading',
                'content' => 'Heading Color',
            ),
            array(
                'id'          => 'headingcolor',
                'type'        => 'color',
                'title'       => 'Select Your Heading color',
                'default'      =>'#101010'
               
                
            ),
				array(
                'type'    => 'heading',
                'content' => 'Site Meta Info',
            ),
			array(
				'id'          => 'enable_cusmeta',
				'type'        => 'switcher',
				'title'       => 'Enable Custeom Meta',
				'default'     => false,
			),
			array(
                'id'          => 'site_meta_img',
                'type'        => 'media',
                'title'       => 'Upload Banner Image',
				'dependency'  => array('enable_cusmeta', '==', 'true'),
            ),
			array(
                'id'          => 'site_meta_des',
                'type'        => 'textarea',
                'title'       => 'Write Your Meta Descriptions',
				'dependency'  => array('enable_cusmeta', '==', 'true'),
            ),
           


        )
    ));

    //
    // Create a section
    // 
    CSF::createSection( $prefix, array(
  'id'    => 'header',
  'title' => 'Header',
  'icon'  => 'fa fa-plus-circle',
) );

    CSF::createSection($prefix, array(
        'parent'      => 'header',
        'title'  => 'Header',
        'icon'    => 'fa fa-code',
        'fields' => array(
   
        


            array(
                'id'          => 'sitelogo',
                'type'        => 'media',
                'title'       => 'Upload Logo',

            ),
			  array(
                'id'          => 'sitefavi',
                'type'        => 'media',
                'title'       => 'Upload Site Fevicon',

            ),  
			array(
                'id'        => 'coronaupdate',
                'type'      => 'textarea',
                'title'     => 'Corona Virus Warning Info Descriptions',
				'default'  => 'We care about your health and continue to service our customers safely',
            ),
			array(
                'id'        => 'cvreadmbtn',
                'type'      => 'text',
                'title'     => 'Corona Virus Warning Info Readmore Button link',
				'default'  => '#',
            ),
			array(
				'id'          => 'enable_search',
				'type'        => 'switcher',
				'title'       => 'Enable Search Icon',
				'default'     => false,
			),
			array(
				'id'    => 'search_icon',
				'type'  => 'icon',
				'title' => 'Search Icon',
				'dependency'  => array('enable_search', '==', 'true'),
			),
			
			 array(
				'id'          => 'enable_wishlist',
				'type'        => 'switcher',
				'title'       => 'Enable Wishlist Icon',
				'default'     => false,
			),
			array(
				'id'    => 'wishlist_icon',
				'type'  => 'icon',
				'title' => 'Wishlist Icon',
				'dependency'  => array('enable_wishlist', '==', 'true'),
			),
			array(
				'id'    => 'wishlist_url',
				'type'  => 'text',
				'title' => 'Wishlist URL',
				'default'     =>'#',
				'dependency'  => array('enable_wishlist', '==', 'true'),
			),
			array(
				'id'          => 'enable_user',
				'type'        => 'switcher',
				'title'       => 'Enable User Icon',
				'default'     => false,
			),
		   array(
				'id'    => 'user_icon',
				'type'  => 'icon',
				'title' => 'User Icon',
				'dependency'  => array('enable_user', '==', 'true'),
			),
			array(
				'id'    => 'user_url',
				'type'  => 'text',
				'title' => 'User Page URL',
				'default'     =>'#',
				'dependency'  => array('enable_user', '==', 'true'),
			),	
			array(
				'id'          => 'enable_cart',
				'type'        => 'switcher',
				'title'       => 'Enable Cart Icon',
				'default'     => false,
			),
			array(
				'id'    => 'cart_icon',
				'type'  => 'icon',
				'title' => 'Cart Icon',
				'dependency'  => array('enable_cart', '==', 'true'),
			),
			 array(
				'id'    => 'cart_url',
				'type'  => 'text',
				'title' => 'Cart URL',
				'default'     =>'#',
				'dependency'  => array('enable_cart', '==', 'true'),
			),
          

        )
    )
);

	

	
	
    CSF::createSection($prefix, array(
        'title'     => 'Social',
        'icon'      => 'fa fa-share',
        'fields'    => array(
            array(
                'type'    => 'heading',
                'content' => 'Follow us',
                ),
				 array(
                    'id'    => 'widget_title',
                    'type'  => 'text',
                    'title' => 'Widget Title',
                ),
				
               array(
				  'id'        => 'sociamedia',
				  'type'      => 'group',
				  'title'     => 'Add Social Media',
				  'fields'    => array(
				  
					  array(
						'id'    => 'social_label',
						'type'  => 'text',
						'title' => 'Label',
					),
					 array(
						'id'    => 'social_url',
						'type'  => 'text',
						'title' => 'URL',
						'default'     =>'#',						
					),
					array(
						'id'    => 'social_icon',
						'type'  => 'icon',
						'title' => 'Scoial Icon',
					),
					
					
				  ),
				),
				
               
               

        )
    ));	

	//Blog Options=========================//

/*	
   CSF::createSection($prefix, array(
        'id'    => 'blog_options',
        'title' => 'Blog Settings',
        'icon'  => 'fa fa-plus-circle',
    ));
    CSF::createSection($prefix, array(
        'parent'      => 'blog_options',
        'title'  => 'Blog Page Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
              array(
                'id'    => 'blog_banner_enable',
                'type'  => 'switcher',
                'title' => 'Banner Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
             array(
                'id'          => 'blog_banner_bg_shop',
                'type'        => 'media',
                'title'       => 'Upload Banner Image',
                'dependency'  => array('blog_banner_enable', '==', 'true'),

            ),
              array(
                'id'    => 'blog_title',
                'type'    => 'text',
                'title'    => 'Banner Title',
                'default'  => 'Shop',
                'desc'    => 'Enter main title fr the blog page banner.',
                'dependency' => array('blog_banner_enable', '==', 'true'),
            ),

        )
    ));

*/
	
 //==========404 Options========================//

/*
		
    CSF::createSection($prefix, array(
        'title'  => '404',
        'icon'    => 'fa fa-code',
        'fields' => array(
            array(
                'type'    => 'heading',
                'content' => '404 Page',
            ),

              array(
                'id'    => '404_banner_enable',
                'type'  => 'switcher',
                'title' => 'Banner Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
             array(
                'id'          => 'banner_bg_404',
                'type'        => 'media',
                'title'       => 'Upload Banner Image',
                'dependency'  => array('404_banner_enable', '==', 'true'),

            ),
              array(
                'id'    => 'title_404',
                'type'    => 'text',
                'title'    => 'Banner Title',
                'default'  => 'Shop',
                'desc'    => 'Enter main title fr the shop page banner.',
                'dependency' => array('404_banner_enable', '==', 'true'),
            ),
         
            array(
                'id'          => 'error_side_image',
                'type'        => 'media',
                'title'       => 'Upload 404 page side Image',

            ),
           
            array(
                'id'        => 'error_title',
                'type'      => 'text',
                'title'     => 'Title',
                'default'   => 'Sorry! The Page Not Found',
            ),
             array(
                'id'        => 'error_subtitle',
                'type'      => 'text',
                'title'     => 'Subtitle',
                'default'   => 'The Link You Followed Probably Broken, or the page has been removed.',
            ),
               array(
                'id'          => 'enable_404_btn',
                'type'        => 'switcher',
                'title'       => 'Enable Button?',
                'default'     => true,
            ),
            array(
                'id'        => 'enable_404_btn_label',
                'type'      => 'text',
                'title'     => 'Button Label',
                'default'   => 'Return to Home',
                'dependency' => array('enable_404_btn', '==', 'true'),
            ),
            array(
                'id'        => 'enable_404_btn_link',
                'type'      => 'text',
                'title'     => 'Button Link',
                'default'   => '#',
                'dependency' => array('enable_404_btn', '==', 'true'),
            ),
           
            array(
                'id'          => 'enable_social_icons',
                'type'        => 'switcher',
                'title'       => 'Enable Social Icons',
                'default'     => true,
            ),
            array(
                'id'        => '404_fb_link',
                'type'      => 'text',
                'title'     => 'Facebook Link',
                'default'   => '#',
                'dependency' => array('enable_social_icons', '==', 'true'),
            ),
             array(
                'id'        => '404_tw_link',
                'type'      => 'text',
                'title'     => 'Twitter Link',
                'default'   => '#',
                'dependency' => array('enable_social_icons', '==', 'true'),
            ),
              array(
                'id'        => '404_insta_link',
                'type'      => 'text',
                'title'     => 'Instagram Link',
                'default'   => '#',
                'dependency' => array('enable_social_icons', '==', 'true'),
            ),
           
        )
    ));

*/	
	

//WooCommerce Options
	
  CSF::createSection($prefix, array(
        'id'    => 'woocommerce_options',
        'title' => 'WooCommerce Settings',
        'icon'  => 'fa fa-plus-circle',

    ));
     CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'General Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
             
            array(
                'id'    => 'enable_pro_price',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Product Price',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
			array(
                'id'    => 'enable_carttbtn',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Add To Cart button',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
			 array(
                'id'    => 'cart_btn_label',
                'type'    => 'text',
                'title'    => 'Button Label',
                'default'  => 'Add To Cart',
                'desc'    => 'Enter button label for all products.',
                'dependency' => array('enable_carttbtn', '==', 'true'),
            ),
			 array(
                'id'    => 'enable_qty_field',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Quantity Field',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
            
			 array(
                'id'    => 'enable_call',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Call button',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),

            array(
                'id'    => 'call_btn_label',
                'type'    => 'text',
                'title'    => 'Button Label',
                'default'  => 'Call Now',
                'dependency' => array('enable_call', '==', 'true'),
            ),
             array(
                'id'    => 'phone_number',
                'type'    => 'text',
                'title'    => 'Phone Number',
                'default'  => '#',
                'dependency' => array('enable_call', '==', 'true'),
            ),
			array(
                'id'    => 'enable_email',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Eamil button',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),

            array(
                'id'    => 'email_btn_label',
                'type'    => 'text',
                'title'    => 'Button Label',
                'default'  => 'Eamil Now',
                'dependency' => array('enable_email', '==', 'true'),
            ),
             array(
                'id'    => 'email_address',
                'type'    => 'text',
                'title'    => 'Email Address',
                'default'  => '#',
                'dependency' => array('enable_email', '==', 'true'),
            ),
			array(
                'id'    => 'enable_wishtbtn',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Wishlist button',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
			array(
                'type'    => 'heading',
                'content' => 'Single Product Tab Section',
            ),
			array(
                'id'    => 'enable_des_tab',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Description Tab',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
			array(
                'id'    => 'enable_adi_tab',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Aditional Tab',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
			array(
                'id'    => 'enable_videgal_tab',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Video & Gallery Tab',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
			
			
        )
    ));
	
/*	

    CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'Shop Page Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
              array(
                'id'    => 'enable_shopcart',
                'type'  => 'switcher',
                'title' => 'Enable/Disable Cart button',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),

            array(
                'id'    => 'shopcart_btn_label',
                'type'    => 'text',
                'title'    => 'Button Label',
                'default'  => 'Call Now',
                'dependency' => array('enable_shopcart', '==', 'true'),
            ),
         

        )
    ));
	
    CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'Single Products Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
		
		    array(
                'type'    => 'heading',
                'content' => 'Header Section',
            ),
              array(

                'id'    => 'p_banner_enable',
                'type'  => 'switcher',
                'title' => 'Banner Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
             array(
                'id'          => 'p_banner_bg_shop',
                'type'        => 'media',
                'title'       => 'Upload Header Banner Image',
                'dependency'  => array('p_banner_enable', '==', 'true'),

            ),
			array(
                'id'          => 'p_feature_img',
                'type'        => 'media',
                'title'       => 'Feature Image',
                'dependency'  => array('p_banner_enable', '==', 'true'),

            ),
              array(
                'id'    => 'p_title_singleshop',
                'type'    => 'text',
                'title'    => 'Banner Title',
                'desc'    => 'Enter main title fr the shop page banner.',
                'dependency' => array('p_banner_enable', '==', 'true'),
            ),
			 array(
                'id'    => 'p_des_singleshop',
                'type'    => 'textarea',
                'title'    => 'Banner Title',
                'desc'    => 'Enter Descriptions On Single shop page banner.',
                'dependency' => array('p_banner_enable', '==', 'true'),
            ),

			array(
                'type'    => 'heading',
                'content' => 'Content Section',
            ),
             array(
                'id'          => 'p_single_content_bg_shop',
                'type'        => 'media',
                'title'       => 'Content Background Image',
              
            ),
			array(
                'type'    => 'heading',
                'content' => 'Related Product Section',
            ),
             array(
                'id'          => 'p_single_relatedpro_bg',
                'type'        => 'media',
                'title'       => 'Related Product Background Image',
              
            ),
			array(
                'id'          => 'p_single_relatedproshape_bg',
                'type'        => 'media',
                'title'       => 'Related Product Feature Image',
              
            ),
        
        )
    ));

    CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'Checkout Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
           
            array(
                'id'          => 'ch_login_bg',
                'type'        => 'media',
                'title'       => 'Login Form Background',
               

            ),
            array(
                'id'          => 'ch_login_feature',
                'type'        => 'media',
                'title'       => 'Login Form Image',
               

            ),
			array(
                'id'          => 'ch_biling_bg',
                'type'        => 'media',
                'title'       => 'Billing Form Background',
               

            ),
        
        )
    ));
	    CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'My Account Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
           
            array(
                'id'          => 'myacc_bg',
                'type'        => 'media',
                'title'       => 'Background Image',
               

            ),
         
        
        )
    ));
	  CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'Login/Register Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
           
            array(
                'id'          => 'login_bg',
                'type'        => 'media',
                'title'       => 'Header Background',
            ),
            array(
                'id'          => 'login_feature_img',
                'type'        => 'media',
                'title'       => 'Header Feature Image',
            ),
			array(
                'id'          => 'login_title',
                'type'        => 'text',
                'title'       => 'Title',
            ),
			array(
                'id'          => 'login_des',
                'type'        => 'textarea',
                'title'       => 'Short Descriptions',
            ),
			 array(
                'id'          => 'login_ctnbg',
                'type'        => 'media',
                'title'       => 'Login Form Background',
            ),
         
        
        )
    ));
		  CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'Forget Password Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
           
            array(
                'id'          => 'forget_bg',
                'type'        => 'media',
                'title'       => 'Header Background',
            ),
            array(
                'id'          => 'forget_feature_img',
                'type'        => 'media',
                'title'       => 'Header Feature Image',
            ),
			array(
                'id'          => 'forget_title',
                'type'        => 'text',
                'title'       => 'Title',
            ),
			array(
                'id'          => 'forget_des',
                'type'        => 'textarea',
                'title'       => 'Short Descriptions',
            ),
			 array(
                'id'          => 'forget_ctnbg',
                'type'        => 'media',
                'title'       => 'Forget Form Background',
            ),
         
        
        )
    ));
    CSF::createSection($prefix, array(
        'parent'      => 'woocommerce_options',
        'title'  => 'Thank You Page Settings',
        'icon'    => 'fa fa-code',
        'fields' => array(
          array(
                'id'          => 'thank_bg',
                'type'        => 'media',
                'title'       => 'Header Background',
            ),
            array(
                'id'          => 'thank_feature_img',
                'type'        => 'media',
                'title'       => 'Header Feature Image',
            ),
			array(
                'id'          => 'thank_title',
                'type'        => 'text',
                'title'       => 'Title',
            ),
			array(
                'id'          => 'thank_des',
                'type'        => 'textarea',
                'title'       => 'Short Descriptions',
            ),
			 array(
                'id'          => 'thank_ctnbg',
                'type'        => 'media',
                'title'       => 'Thank You Content Background',
            ),
        )
    ));			

*/	
    CSF::createSection( $prefix, array(
  'id'    => 'footer',
  'title' => 'Footer',
  'icon'  => 'fa fa-plus-circle',
) );
     CSF::createSection($prefix, array(
        'title'  => 'Footer Top',
        'parent'      => 'footer',
        'icon'    => 'fa fa-picture-o',
        'fields' => array(
              array(
                'type'    => 'heading',
                'content' => 'Footer Background',
            ),
              array(
                  'id'    => 'footer_top_bg',
                  'type'  => 'media',
                  'title' => 'Background Image',
                 
                ),
							array(
                'type'    => 'heading',
                'content' => 'Footer Useful Links',
            ),
           
				array(
					  'id'        => 'fmenulink',
					  'type'      => 'group',
					  'title'     => 'Footer Usefull Link-01',
					  'fields'    => array(
						array(
						  'id'    => 'tiitlename',
						  'type'  => 'text',
						  'title' => 'Title Name',
						),
						array(
						  'id'    => 'titlelink',
						  'type'  => 'text',
						  'title' => 'Title Link',
						),
						
					  ),
					),
				array(
					  'id'        => 'fmenulink2',
					  'type'      => 'group',
					  'title'     => 'Footer Usefull Link-02',
					  'fields'    => array(
						array(
						  'id'    => 'tiitlename2',
						  'type'  => 'text',
						  'title' => 'Title Name',
						),
						array(
						  'id'    => 'titlelink2',
						  'type'  => 'text',
						  'title' => 'Title Link',
						),
						
					  ),
					),
  
                    array(
                    'type'    => 'heading',
                    'content' => ' Our Company Info',
                 ),
                   array(
					'id'          => 'comlogo',
					'type'        => 'media',
					'title'       => 'Add Your Company Logo',
					),
					 array(
					'id'          => 'comsdes',
					'type'        => 'textarea',
					'title'       => 'Write Your Company Short Descriptons',
					'default'     =>'5Texas Tires have advanced significantly from its beginnings to among the number one custom wheel, tire repair and full-service auto shop in Dallas, TX'
					),
					

               array(
                    'type'    => 'heading',
                    'content' => ' Footer Gallary',
                 ),
                   array(
					'id'          => 'foogal',
					'type'        => 'gallery',
					'title'       => 'Add Your Gallary Image',
					),

			
				
				
        )
    ));
	
 CSF::createSection($prefix, array(
        'title'  => 'Subscription',
        'parent'      => 'footer',
        'icon'    => 'fa fa-picture-o',
        'fields' => array(
            
            array(
                'type'    => 'heading',
                'content' => 'Subscription Content ',
            ),
            array(
                'id'          => 'subs_text',
                'type'        => 'text',
                'title'       => 'Subscription Title',
                'default'     =>'SUBSCRIBE TO OUR NEWSLETTER'

            ),
			array(
                'id'          => 'subs_des',
                'type'        => 'text',
                'title'       => 'Subscription Descriptions',
                'default'     =>'Sign up to our newsletter today to receive amazing news and latest service updates.'

            ),


        )
    ));
	
    CSF::createSection($prefix, array(
        'title'  => 'Footer Bottom',
        'parent'      => 'footer',
        'icon'    => 'fa fa-picture-o',
        'fields' => array(
            
            array(
                'type'    => 'heading',
                'content' => 'Footer Bottom ',
            ),
            array(
                'id'          => 'foot_btom',
                'type'        => 'color',
                'title'       => 'Background',
                'default'     =>'#17171A'

            ),

            array(
                'id'          => 'foo_text',
                'type'        => 'wp_editor',
                'title'       => '@Copyright',
                'default'     =>'Copyright 2020, TexastireV1. All Rights Reserved. Created By DesignNearMe.com'

            ),
             
      


        )
    ));
}

// metabox

// Control core classes for avoid errors
if (class_exists('CSF')) {

    //
    // Set a unique slug-like ID
    $prefix = 'page_meta_opt';


    // Create a metabox
    CSF::createMetabox($prefix, array(
        'title'     => 'Page Settings',
        'post_type' => 'page',
        'context'   => 'normal'
    ));

    //
    // Create a section
    CSF::createSection($prefix, array(
        'title'  => 'Header',
        'fields' => array(
            array(
                'id'    => 'banner_enable',
                'type'  => 'switcher',
                'title' => 'Banner Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),
            array(
                'id'    => 'banner_img',
                'type'  => 'media',
                'title' => 'Background Image',
                'dependency'  => array('banner_enable', '==', 'true'),
            ),
			 array(
                'id'    => 'feature_img',
                'type'  => 'media',
                'title' => 'Feature Image',
                'dependency'  => array('banner_enable', '==', 'true'),
            ),
            array(
                'id'    => 'banner_title',
                'type'  => 'text',
                'title' => 'Banner Title',
                'dependency'  => array('banner_enable', '==', 'true'),
            ), 
            array(
                'id'    => 'banner_text',
                'type'  => 'textarea',
                'title' => 'Banner Descriptions',
                'dependency'  => array('banner_enable', '==', 'true'),
            ),

        )
    ));

    //
    // Create a section
    CSF::createSection($prefix, array(
        'title'  => 'Footer',
        'fields' => array(

            // A textarea field
            array(
                'id'    => 'footer_enable',
                'type'  => 'switcher',
                'title' => 'Footer Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),

        )
    ));

    // Create a metabox
    CSF::createMetabox('product_tab', array(
        'title'     => 'Additional Information',
        'post_type' => 'product',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section
    CSF::createSection('product_tab', array(
        'title'  => 'Additional Description',

        'fields' => array(
            array(
                'id'    => 'addi_img_1',
                'type'  => 'media',
                'title' => 'Left Image',

            ),

            array(
                'id'    => 'addi_img_2',
                'type'  => 'media',
                'title' => 'Right Image',

            ),
            array(
                'id'    => 'addi_des_1',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),
            array(
                'type'    => 'heading',
                'content' => 'Video Block',
            ),
            array(
                'id'    => 'addi_video_thumb',
                'type'  => 'media',
                'title' => 'Video Thumbnail',

            ),
            array(
                'id'    => 'addi_video',
                'type'  => 'text',
                'title' => 'Video Url',
            ),
            array(
                'id'    => 'addi_des_2',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),
            array(
                'type'    => 'heading',
                'content' => 'Left Image Block',
            ),
            array(
                'id'    => 'addi_left_img',
                'type'  => 'media',
                'title' => 'Left Image',

            ),
            array(
                'id'    => 'addi_left_img_right_des',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),

            array(
                'type'    => 'heading',
                'content' => 'Right Image Block',
            ),

            array(
                'id'    => 'addi_right_img',
                'type'  => 'media',
                'title' => 'Right Image',

            ),
            array(
                'id'    => 'addi_right_img_left_des',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),

        )
    ));

    CSF::createSection('product_tab', array(
        'title'  => 'Specification',

        'fields' => array(
            array(
                'id'    => 'specification_tb',
                'type'  => 'wp_editor',
                'title' => 'Description',

            ),

        )
    ));
	
			 CSF::createMetabox('testimornial_tab', array(
        'title'     => 'Testimornial Setting',
        'post_type' => 'testimornial',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section testimornial
    CSF::createSection('testimornial_tab', array(
        'title'  => 'Ratings',

        'fields' => array(
            array(
                'id'    => 'conemt',
                'type'  => 'textarea',
                'title' => 'Write Your Comment',
            ),
			array(
				  'id'          => 'raat',
				  'type'        => 'select',
				  'title'       => 'Select Your Rating',
				  'options'     => array(
					'1'  => '01 Star Rating',
					'2'  => '02 Star Rating',
					'3'  => '03 Star Rating',
					'4'  => '04 Star Rating',
					'5'  => '05 Star Rating',
					
				  ),
				  'default'     => '5'
				),
			
           
        )
    ));

    CSF::createMetabox('services_tab', array(
        'title'     => 'Services Information',
        'post_type' => 'dnm_services',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section
    CSF::createSection('services_tab', array(
        'title'  => 'Services Image',

        'fields' => array(
            array(
                'id'    => 'ser_img',
                'type'  => 'media',
                'title' => 'Service Image',
            ),

           
        )
    ));
	
	CSF::createSection('services_tab', array(
        'title'  => 'Button',

        'fields' => array(
            
            array(
                'id'    => 'btn_text',
                'type'  => 'text',
                'title' => 'Button label',
            ),
			array(
                'id'    => 'btn_link',
                'type'  => 'text',
                'title' => 'Button Link',
            ),
        )
    ));
	CSF::createSection('services_tab', array(
        'title'  => 'Extra Setting',

        'fields' => array(
            
            array(
                'id'    => 'activecls',
                'type'  => 'switcher',
                'title' => 'Enable/Disable',
            ),
			
        )
    ));
	
	 CSF::createMetabox('works_gal_tab', array(
        'title'     => 'Works Gallery Information',
        'post_type' => 'our_works',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section
    CSF::createSection('works_gal_tab', array(
        'title'  => 'Works Image',

        'fields' => array(
            array(
                'id'    => 'works_img',
                'type'  => 'media',
                'title' => 'Background Image',
            ),

           
        )
    ));
	// Create a section
    CSF::createSection('works_gal_tab', array(
        'title'  => 'Works Video',

        'fields' => array(
            array(
                'id'    => 'works_video',
                'type'  => 'text',
                'title' => 'Works Video URL',
            ),

           
        )
    ));
	
	CSF::createMetabox('blog_post_tab', array(
        'title'     => 'Post Extra setting',
        'post_type' => 'post',
        'priority'    => 'high',
        'context'   => 'normal'

    ));
	// Create a section
    CSF::createSection('blog_post_tab', array(
        'title'  => 'Background Image',

        'fields' => array(
            array(
                'id'    => 'bg_image',
                'type'  => 'media',
                'title' => 'Add Post Background Image',
            ),

           
        )
    ));
	// Create a section
    CSF::createSection('blog_post_tab', array(
        'title'  => 'Extra Settings',

        'fields' => array(
            array(
                'id'    => 'activeclass',
                'type'  => 'switcher',
                'title' => 'Enable /Disable Post Box Style',
            ),

           
        )
    ));
	
	
	
	
}
