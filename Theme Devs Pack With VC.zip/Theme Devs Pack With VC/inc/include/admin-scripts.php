<?php

function qsinspectionadmin_scripts()
{

	wp_enqueue_style('admin_style-css', get_theme_file_uri('/assets/css/admin/admin_style.css'), array(), time());
	wp_enqueue_style('admin-bootstrap-css', get_theme_file_uri('/assets/css/admin/cs-bootstrap.css'));
 //wp_enqueue_script( 'restyling_templates_js', get_theme_file_uri( '/assets/js/vc-templates.js' ), array( ), time(),true );

}
add_action('admin_enqueue_scripts', 'qsinspectionadmin_scripts');