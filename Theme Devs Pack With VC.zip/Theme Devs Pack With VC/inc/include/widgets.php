<?php

function qsinspectionwidgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'qsinspection' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'qsinspection' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)

	);
	register_sidebar(array(
		'name'          => esc_html__( 'Footer Widgets', 'qsinspection' ),
		'id'            => 'footer-1',
		'description'   => esc_html__( 'Add widgets here.', 'qsinspection' ),
		'before_widget' => '<div class="col-xl-3 col-lg-3 col-sm-6">
			<div class="widgets-single-item footer-menu">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	));
}
add_action( 'widgets_init', 'qsinspectionwidgets_init' );