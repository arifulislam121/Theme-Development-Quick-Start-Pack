<?php
/**
 * ACF Options
 */
 
/*
if( function_exists('acf_add_options_page') ) {

	acf_add_options_page(array(
		'page_title' 	=> 'QSInspection Options',
		'menu_title'	=> 'QSInspection Options',
		'menu_slug' 	=> 'qsinspection-options',
		'capability'	=> 'edit_posts',
		'position' => '12',
		'updated_message' => __("Options Updated", 'acf'),
		'redirect'		=> false
	));



}

*/