<?php
if ( ! function_exists( 'texastiresetup' ) ) :

	function texastiresetup() {

		load_theme_textdomain( 'texastire', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );


		add_theme_support( 'post-thumbnails' );


		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'main-menu' => esc_html__( 'Main Menu', 'texastire' ),
				'toggle-menu' => esc_html__( 'Toggle Menu', 'texastire' ),
				'mobile' => esc_html__( 'Mobile', 'texastire' ),
			)

		);


		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'qsinspectioncustom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );


		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
		
		
  //--------------------woocommerce support ------------------------------------//	
		

        //     woocommerce
        add_theme_support('woocommerce');
        add_theme_support('woocommerce', array(
            'thumbnail_image_width' => 295,
            'single_image_width'    => 900,

            'product_grid'          => array(
                'default_rows'    => 3,
                'min_rows'        => 2,
                'max_rows'        => 8,
                'default_columns' => 4,
                'min_columns'     => 2,
                'max_columns'     => 5,
            ),
        ));
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');

        add_theme_support('title-tag');
        add_image_size( 'shop-images', 295, 445 );
        add_image_size( 'cart-images', 64, 100 );
		add_image_size( 'checkout-images', 256, 400 );
        add_image_size( 'compare-images', 156, 200 );
        add_theme_support('post-thumbnails');



		
	}
endif;
add_action( 'after_setup_theme', 'texastiresetup' );

function qsinspectioncontent_width() {

	$GLOBALS['content_width'] = apply_filters( 'qsinspectioncontent_width', 640 );
}
add_action( 'after_setup_theme', 'qsinspectioncontent_width', 0 );