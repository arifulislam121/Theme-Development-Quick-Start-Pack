<?php


/**
 * Enqueue scripts and styles.
 */
function kg1forgedv2scripts() {
   
 
    //wp_enqueue_style('animate-css',get_theme_file_uri('/assets/css/animate.css'),array(),_S_VERSION);
    

   
    
   	
	 //wp_enqueue_style('custom-responsive-css',get_theme_file_uri('/assets/css/custom-responsive.css'),array(),_S_VERSION);
	//root Theme css
	
	wp_enqueue_style( 'texastirv1-stylesheet', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'qsinspection-style', 'rtl', 'replace' );

	//Wocommerce Custom Css
	
	//wp_enqueue_style('woocss',get_theme_file_uri('/woocommerce.css'),array(),_S_VERSION);

	//---------javascript file from here-------------------//
	
	//wp_enqueue_script( 'popper-js', get_theme_file_uri('/assets/js/popper.min.js'), array('jquery'), _S_VERSION, true );

	
	
	// CUSTOM Main JS
	
	//wp_enqueue_script( 'main', get_theme_file_uri('/assets/js/main.js'), array('jquery'), _S_VERSION, true );
	//wp_enqueue_script( 'custom-js', get_theme_file_uri('/assets/js/custom.js'), array('jquery'), _S_VERSION, true );

 
 wp_enqueue_script('jquery');
 


}
add_action( 'wp_enqueue_scripts', 'kg1forgedv2scripts' );