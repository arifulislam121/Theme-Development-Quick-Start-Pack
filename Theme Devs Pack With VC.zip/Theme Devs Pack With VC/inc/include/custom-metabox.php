<?php

// -------------custom metabox metabox make Functions(include functions.php)----------------

function rpa_custombtn_metabox(){
	
	add_meta_box(
	'button_one',
	'Add Your Button-1',
	'meta_box_er_output1',
	'product',
	'normal'
	);
	add_meta_box(
	'button_two',
	'Add Your Button-2',
	'meta_box_er_output2',
	'product',
	'normal'
	);
	
}

add_action('add_meta_boxes','rpa_custombtn_metabox');

function meta_box_er_output1($post){ ?>
	<label for="food">Button Label</label>
	<p><input class="widefat" id="food" type="text" name="btnlab_one" placeholder="Button Label"
	value="<?php echo get_post_meta($post->ID,'btnlab_one',true);?>"/></p>
	
	
	<label for="poet">Button Url</label>
	<p><input class="widefat" id="poet" type="text" name="btnurl_one" placeholder="Button Url"
	value="<?php echo get_post_meta($post->ID,'btnurl_one',true);?>"/></p>

<?php }


function meta_box_er_output2($post){ ?>
	<label for="food">Button Label</label>
	<p><input class="widefat" id="food" type="text" name="btnlab_two" placeholder="Button Label"
	value="<?php echo get_post_meta($post->ID,'btnlab_two',true);?>"/></p>
	
	
	<label for="poet">Button Url</label>
	<p><input class="widefat" id="poet" type="text" name="btnurl_two" placeholder="Button Url"
	value="<?php echo get_post_meta($post->ID,'btnurl_two',true);?>"/></p>

<?php }


function Dtabase_a_pathabo($post_id){
	
	update_post_meta($post_id,'btnlab_one',$_POST['btnlab_one']);
	update_post_meta($post_id,'btnurl_one',$_POST['btnurl_one']);
	update_post_meta($post_id,'btnlab_two',$_POST['btnlab_two']);
	update_post_meta($post_id,'btnurl_two',$_POST['btnurl_two']);
}


add_action('save_post','Dtabase_a_pathabo');


//----------------end-------------//





add_action( 'woocommerce_product_meta_start', 'learnalwayss_after_add_to_cart_btn',999);
function learnalwayss_after_add_to_cart_btn(){
global $product;
$btnlabel1 = get_post_meta(get_the_ID(),'btnlab_one',true);
$btnurl1 =get_post_meta(get_the_ID(),'btnurl_one',true);
$btnlabel2 = get_post_meta(get_the_ID(),'btnlab_two',true);
$btnurl2 =get_post_meta(get_the_ID(),'btnurl_two',true);	
?>
<div class="wd-after-add-to-cart">	
<?php	

if ( ! is_user_logged_in() ) { 

	if ($btnlabel1 && $btnurl1){
		
	echo '<a class="single_add_to_cart_button button" href="'.$btnurl1.'">'.$btnlabel1.'</a>';
		
	}
	if ($btnlabel2 && $btnurl2){
		
	echo '<a class="single_add_to_cart_button button btn22" href="'.$btnurl2.'" target="_blank" rel="noopener">'.$btnlabel2.'</a>';

	} 

}else{
	
	if ($btnlabel1 && $btnurl1){
		
	echo '<a class="single_add_to_cart_button button" href="'.$btnurl1.'">'.$btnlabel1.'</a>';
		
	}
	if ($btnlabel2 && $btnurl2){
		
	echo '<a class="single_add_to_cart_button button btn22" href="'.$btnurl2.'" target="_blank" rel="noopener">'.$btnlabel2.'</a>';

	} 
	
}
	

?>

</div>
<?php	



}



