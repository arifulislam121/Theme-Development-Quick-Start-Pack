
<?php 

add_filter('woocommerce_checkout_fields', 'custom_override_checkout_fields');

function custom_override_checkout_fields($fields)
 {

//==========include Billing Field===========//

 
	 //$fields['billing']['billing_company']['placeholder'] = 'Business Name';
	 //$fields['billing']['billing_company']['label'] = '';
	 $fields['billing']['billing_first_name']['placeholder'] = 'First Name'; 
	 $fields['billing']['billing_first_name']['label'] = 'First Name';
	 $fields['billing']['billing_last_name']['placeholder'] = 'Last Name';
	 $fields['billing']['billing_last_name']['label'] = 'Last Name';
	 $fields['billing']['billing_email']['placeholder'] = 'Email Address ';
	 $fields['billing']['billing_email']['label'] = 'Email Address';
	 $fields['billing']['billing_phone']['placeholder'] = 'Phone ';
	 $fields['billing']['billing_phone']['label'] = 'Phone';
	 $fields['billing']['billing_postcode']['placeholder'] = 'Postcode';
	 $fields['billing']['billing_postcode']['label'] = 'Postcode';
	 $fields['billing']['billing_country']['label'] = '';
	 $fields['billing']['billing_address_1']['label'] = 'Address';
	 $fields['billing']['billing_address_1']['placeholder'] = 'Street Address';	 
	 $fields['billing']['billing_address_2']['label'] = 'Address';
	 $fields['billing']['billing_address_2']['placeholder'] = 'Apartment, Suite, Unit etc.';
	 $fields['billing']['billing_city']['placeholder'] = 'Town / City';
	 $fields['billing']['billing_city']['label'] = 'Town / City';
	 $fields['billing']['billing_state']['label'] = 'State';
	 
//====Modify Billing   Field ==========//	 
	//$fields['billing']['billing_state']['label'] = '';
	 //$fields['billing']['billing_state']['placeholder'] = 'Country / Region';
  
//======Remove Billing Field===========//  
 
//unset($fields['billing']['billing_country']);
//unset($fields['billing']['billing_address_2']);
//unset($fields['billing']['billing_company']);
//unset($fields['billing']['billing_state']);


 
//========shipping field======================//


//===include shipping Field --------------//
 
	
	$fields['shipping']['shipping_address_1']['label'] = '';
	//$fields['shipping']['shipping_state']['label'] = '';
	//$fields['shipping']['shipping_state']['placeholder'] = 'County';

 	$fields['shipping']['shipping_postcode']['placeholder'] = 'Postcode';
 	$fields['shipping']['shipping_postcode']['label'] = 'Postcode
';
  	$fields['shipping']['shipping_city']['placeholder'] = 'Town / City';
 	$fields['shipping']['shipping_city']['label'] = 'Town / City'; 
	
	
//=====Modify shipping   Field --------------//	 
 
  $fields['order']['order_comments']['placeholder'] = _x('Order Notes', 'placeholder', 'woocommerce');
  $fields['order']['order_comments']['label'] = '';
  
//==Remove shipping Field --------------//  
 
	unset($fields['shipping']['shipping_first_name']);
	unset($fields['shipping']['shipping_last_name']);
	unset($fields['shipping']['shipping_company']);
	//unset($fields['shipping']['shipping_country']);
	unset($fields['shipping']['shipping_address_2']);
    unset($fields['shipping']['shipping_state']);
	
//==Remove specific Field Label-----------------//	

	$fields['shipping']['shipping_country']['label'] = false;
	
//=== Disable Postcode/ZIP Validation on the WooCommerce Checkout Page=====//

unset($fields['billing']['billing_postcode']['validate']);
unset($fields['shipping']['shipping_postcode']['validate']);
	
	
	
	return $fields;
 }
 
 
 //============= Convert All Label Text to Placeholder text Of Checkout Input Field ===================//
 
/* 
	function custom_form_field_args( $args, $key, $value ) {
        $args['placeholder'] = $args['label'];
        return $args;
    };
    add_filter( 'woocommerce_form_field_args', 'custom_form_field_args',      10, 3 );
	
*/	

 //============= Change or Modify Checkout Input Field Placeholder Text ===================//
 
 /*
	 //placeholder text
		add_filter( 'woocommerce_form_field_args', 'custom_form_field_args',      10, 3 );
		function custom_form_field_args( $args, $key, $value ) { 
		   if ( $args['id'] == 'billing_first_name' ) {
			  $args['placeholder'] = 'FIRST NAME';
		   } elseif ( $args['id'] == 'billing_last_name' ) {
			   $args['placeholder'] = 'LAST NAME dddd';
		   } elseif ( $args['id'] == 'shipping_state' ) {
			   $args['placeholder'] = 'State';
		   } elseif ( $args['id'] == 'account_first_name' ) {
			   $args['placeholder'] = 'FIRST NAME';
		   } elseif ( $args['id'] == 'account_last_name' ) {
			   $args['placeholder'] = 'LAST NAME';
		   } elseif ( $args['id'] == 'account_email' ) {
			   $args['placeholder'] = 'email';  
		   } elseif ( $args['id'] == 'account_password_current' ) {
			   $args['placeholder'] = 'password';
		   } elseif ( $args['id'] == 'account_password_1' ) {
			   $args['placeholder'] = 'new password';   
		   } elseif ( $args['id'] == 'account_password_2' ) {
			   $args['placeholder'] = 'confirm password';
		   }

		   return $args;
		};
	 
*/

 
 //============= Add Custom Product Tab In Single Product Page ===================//
  
  
add_filter( 'woocommerce_product_tabs', 'woo_custom_product_tabs' );
function woo_custom_product_tabs( $tabs ) {

    // 1) Removing tabs

    
    unset( $tabs['additional_information'] );   // Remove the additional information tab
    unset( $tabs['description'] );   // Remove the descriptiontab

    $options = get_option('petrolyne_options');
    $enable_des_tab = Corsicana_set($options,'enable_des_tab');
    $enable_adi_tab = Corsicana_set($options,'enable_adi_tab');
    $enable_videgal_tab = Corsicana_set($options,'enable_videgal_tab');
    $enable_review_tab = Corsicana_set($options,'enable_review_tab');
 	$meta = get_post_meta(get_the_ID(), 'product_tab', true);
 	
   if ($enable_des_tab) {
		 if (Corsicana_set($meta, 'enable_des')) {

			//Attribute Description tab
			$tabs['attrib_description_tab'] = array(
				'title'     => __( 'Description', 'woocommerce' ),
				'priority'  => 100,
				'callback'  => 'woo_attrib_description_tab_content'
			);
		}
   }

 if ($enable_adi_tab) {
	 
    $enable_adi = Corsicana_set($meta, 'enable_adi');
  	if ( $enable_adi ) {
        $tabs['attrib_aditional_tab'] = array(
            'title'     => __( 'Additional', 'woocommerce' ),
            'priority'  => 110,
            'callback'  => 'woo_attrib_aditional_tab_content'
        );
    }
}	


	if ($enable_review_tab) {
		 
		 $tabs['reviews'] = array(
			'title'     => __( 'Reviews', 'woocommerce' ),
			'priority'  => 150,
			'callback'  => 'comments_template'
		);
		
	 }else{
		 
		  unset( $tabs['reviews'] );
	 }	
	
	
 if ($enable_videgal_tab) {	
	 $enable_videgal = Corsicana_set($meta, 'enable_videgal');
    if ( $enable_videgal ) { 
    // Adds the qty pricing  tab
        $tabs['attrib_videgal_tab'] = array(
            'title'     => __( 'Videos & Gallery', 'woocommerce' ),
            'priority'  => 130,
            'callback'  => 'woo_attrib_videgal_tab_content'
        );
    }
 }
    return $tabs;

}

// New Tab contents callback



function woo_attrib_description_tab_content() {
      $meta = get_post_meta(get_the_ID(), 'product_tab', true);
      $des_bg_img = Corsicana_set($meta, 'des_bg_img');
      $des_des = Corsicana_set($meta, 'des_des');
      $des_lists = Corsicana_set($meta, 'des_list');
      $des_fetaure_img = Corsicana_set($meta, 'des_fetaure_img');
      $des_perform_lubricant = Corsicana_set($meta, 'des_perform_lubricant');
      $des_enhance_mileage = Corsicana_set($meta, 'des_enhance_mileage');
      $des_enhance_img = Corsicana_set($meta, 'des_enhance_img');
      $des_provide_lists = Corsicana_set($meta, 'des_provide_list');
     if (Corsicana_set($meta, 'enable_des')) : 
            
         echo  '<img src="'.Corsicana_set($des_bg_img, 'url').'" alt="" class="absolute-img">
			 <p>'.Corsicana_set($meta, 'des_des').'</p>
			<div class="row align-items-center mt-20">
				<div class="col-md-6 mb-30">
					<div class="single-shop-descrip-list">';
					 if ( $des_lists ) : 
                                echo '<ul>';
                                 foreach ( $des_lists as $des_list ) : 
                                        echo '<li>'. Corsicana_set($des_list, 'deslidt').'</li>'; 
                                    endforeach;
                                echo '</ul>'; 
                         endif; 
					echo '</div>
				</div>
				<div class="col-md-6 mb-30">
					<div class="description-img">
						<img src="'.Corsicana_set($des_fetaure_img, 'url').'" alt="">
					</div>
				</div>
			</div>
			<div class="section-content mb-60 mb-xs-40 mb-md-50">
			 <p>'.Corsicana_set($meta, 'des_perform_lubricant').'</p>
			</div>
			<div class="row">
				<div class="col-md-6 mb-30">
					<div class="section-content">
						<p>'.Corsicana_set($meta, 'des_enhance_mileage').'</p>';
						
				 if ( $des_provide_lists ) : 
                                echo '<div class="commitment-list text-start">
							<ul>';		
						 foreach ( $des_provide_lists as $des_prolist ) : 
						  $enhance_img =  Corsicana_set($des_prolist, 'des_enhance_iconimg'); 
								echo '<li class="mb-20 mb-xs-10">
									<div class="row align-items-center">
										<div class="col-md-2 col-3">
											<img src="'.Corsicana_set($enhance_img,'url').'" alt="">
										</div>
										<div class="col-md-10 col-9">
											'. Corsicana_set($des_prolist, 'providelistt').'
										</div>
									</div>
								</li>';
							 endforeach;
					echo '</ul>
						</div>';		
					  endif;	
						
					echo '</div>
				</div>
				<div class="col-md-6">
					<div class="service-right">
						<div class="service-img-wrap bg-attachment"
							style="background-image: url('.Corsicana_set($des_enhance_img, 'url').');">
						</div>
					</div>
				</div>
			</div>'; 
        endif;
}

function woo_attrib_aditional_tab_content() {
    $meta = get_post_meta(get_the_ID(), 'product_tab', true); 
    $enable_adi = Corsicana_set($meta, 'enable_adi');
    $adi_info_list = Corsicana_set($meta, 'adi_info_list');
    $adi_desctn = Corsicana_set($meta, 'adi_desctn');
    $adi_feature_list = Corsicana_set($meta, 'adi_feature_list');
    $adi_applicat_titile = Corsicana_set($meta, 'adi_applicat_titile');
    $adi_applicat_des = Corsicana_set($meta, 'adi_applicat_des');
   
  if ( $enable_adi ) :   
	if ( $adi_info_list ) : 
			echo '<div class="additional-info mb-110 mb-xs-50 mb-md-70">
			<ul>';
				  foreach ( $adi_info_list as $adi_info_lis ) : 
					echo '<li>
						<div class="row">
							<div class="col-md-4 col-6">'. Corsicana_set($adi_info_lis, 'adi_infotitle').'</div>
							<div class="col-md-8 col-6"><span>'. Corsicana_set($adi_info_lis, 'adi_infodes').'</span></div>
						</div>
					</li>';
				endforeach;
			echo '</ul>
				
			</div>';
	 endif;	
	 if ( $adi_desctn ) : 	
			echo'<div class="section-content mb-60 mb-xs-40 mn-md-50">
				
				<p>'.Corsicana_set($meta,'adi_desctn').'</p>
			</div>';
	endif;
	echo'<div class="row">
			<div class="col-md-6 mb-30">
					<div class="endu-box">
						<h5>'.Corsicana_set($meta,'adi_featlist_titile').'</h5>';
						
					if ( $adi_feature_list ) : 		
						echo '<ul>';
						 foreach ( $adi_feature_list as $adi_feature_lis ) : 
								echo '<li>'. Corsicana_set($adi_feature_lis, 'adi_featurelisttitle').'</li>';
							endforeach;
						echo '</ul>';
					 endif; 	
						
		echo '</div>
			</div>
			<div class="col-md-6 mb-30">
					<div class="endu-box">
						<h5>'.Corsicana_set($meta,'adi_applicat_titile').'</h5>
						<p>'.Corsicana_set($meta,'adi_applicat_des').'</p>
					</div>
				</div>
			</div>';	
		
		
   endif; 
}
function woo_attrib_videgal_tab_content() {
       $meta = get_post_meta(get_the_ID(), 'product_tab', true); 
    $enable_videgal = Corsicana_set($meta, 'enable_videgal');
    $adi_video_gal = Corsicana_set($meta, 'adi_video_gal');
    if ( $enable_videgal ) : 
	
		if ( $adi_video_gal ) : 
        echo '<div class="gallery pt-70 pb-50 pt-xs-40 pb-xs-20 pt-md-50 pb-md-30">
						<div class="row">';
				 foreach ( $adi_video_gal as $adi_video_gl ) : 
				 $vgalimg_img =  Corsicana_set($adi_video_gl, 'videogal_img'); 
				 $videoicon =  Corsicana_set($adi_video_gl, 'videoicon'); 
					echo '<div class="'. Corsicana_set($adi_video_gl, 'select_layout').'">
						<div class="gallery-item bg-attachment"
							style="background-image: url('.Corsicana_set($vgalimg_img,'url').');">';
							
						if($videoicon == true){	
							echo '
							 <a href="'.Corsicana_set($meta,'vurl').'" class="play-icon video-btn">
                                   <i class="fas fa-play"></i>
                               </a>';
						}else{
							echo '<a href="#" class="gallery-icon">
								 <i class="fab fa-instagram"></i>
							</a>
							';
						}	
						echo '</div>
					</div>';
				endforeach;	
			echo '</div>
			</div>';
		endif;		
			
        endif;
}

/**checkout Forms input field customize with php function*/

/*
add_filter( 'woocommerce_form_field', 'my_woocommerce_form_field' );
function my_woocommerce_form_field( $field ) {
    return preg_replace(
        '#<p class="form-row (.*?)"(.*?)>(.*?)</p>#',
        '<div class="hii"$2>$3</div>',
        $field
    );
}
*/
/**checkout Forms input field customize with core file*/

if ( ! function_exists( 'woocommerce_form_field' ) ) {

	/**
	 * Outputs a checkout/address form field.
	 *
	 * @param string $key Key.
	 * @param mixed  $args Arguments.
	 * @param string $value (default: null).
	 * @return string
	 */
	function woocommerce_form_field( $key, $args, $value = null ) {
		$defaults = array(
			'type'              => 'text',
			'label'             => '',
			'description'       => '',
			'placeholder'       => '',
			'maxlength'         => false,
			'required'          => false,
			'autocomplete'      => false,
			'id'                => $key,
			'class'             => array(),
			'label_class'       => array(), //add extra class in label
			'input_class'       => array(),//add extra class in input field
			'return'            => false,
			'options'           => array(),
			'custom_attributes' => array(),
			'validate'          => array(),
			'default'           => '',
			'autofocus'         => '',
			'priority'          => '',
		);

		$args = wp_parse_args( $args, $defaults );
		$args = apply_filters( 'woocommerce_form_field_args', $args, $key, $value );

	//=============added custom HTML tag in Input Label Require===================//
	
		if ( $args['required'] ) {
			$args['class'][] = 'validate-required';
			$required        = '&nbsp;<abbr class="required" title="' . esc_attr__( 'required', 'woocommerce' ) . '">*</abbr>';
		} else {
			$required = '&nbsp;<span class="optional">(' . esc_html__( 'optional', 'woocommerce' ) . ')</span>';
		}
		

		if ( is_string( $args['label_class'] ) ) {
			$args['label_class'] = array( $args['label_class'] );
		}

		if ( is_null( $value ) ) {
			$value = $args['default'];
		}

		// Custom attribute handling.
		$custom_attributes         = array();
		$args['custom_attributes'] = array_filter( (array) $args['custom_attributes'], 'strlen' );

		if ( $args['maxlength'] ) {
			$args['custom_attributes']['maxlength'] = absint( $args['maxlength'] );
		}

		if ( ! empty( $args['autocomplete'] ) ) {
			$args['custom_attributes']['autocomplete'] = $args['autocomplete'];
		}

		if ( true === $args['autofocus'] ) {
			$args['custom_attributes']['autofocus'] = 'autofocus';
		}

		if ( $args['description'] ) {
			$args['custom_attributes']['aria-describedby'] = $args['id'] . '-description';
		}

		if ( ! empty( $args['custom_attributes'] ) && is_array( $args['custom_attributes'] ) ) {
			foreach ( $args['custom_attributes'] as $attribute => $attribute_value ) {
				$custom_attributes[] = esc_attr( $attribute ) . '="' . esc_attr( $attribute_value ) . '"';
			}
		}

		if ( ! empty( $args['validate'] ) ) {
			foreach ( $args['validate'] as $validate ) {
				$args['class'][] = 'validate-' . $validate;
			}
		}

		$field           = '';
		$label_id        = $args['id'];
		$sort            = $args['priority'] ? $args['priority'] : '';
		
//=============added custom HTML tag in Input field container===================//	
	
		$field_container = '<div class="input-filed-item mb-20 form-row %1$s" id="%2$s" data-priority="' . esc_attr( $sort ) . '">%3$s</div>';
		

		switch ( $args['type'] ) {
			case 'country':
				$countries = 'shipping_country' === $key ? WC()->countries->get_shipping_countries() : WC()->countries->get_allowed_countries();

				if ( 1 === count( $countries ) ) {

					$field .= '<strong>' . current( array_values( $countries ) ) . '</strong>';

					$field .= '<input type="hidden" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="' . current( array_keys( $countries ) ) . '" ' . implode( ' ', $custom_attributes ) . ' class="country_to_state" readonly="readonly" />';

				} else {
					$data_label = ! empty( $args['label'] ) ? 'data-label="' . esc_attr( $args['label'] ) . '"' : '';

	//=============added custom HTML tag Label in Country Dropdown===================//	
			
					$field = '<label for="country">Country<span>*</span></label><select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="country_to_state country_select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ? $args['placeholder'] : esc_attr__( 'Select a country / region&hellip;', 'woocommerce' ) ) . '" ' . $data_label . '><option value="">' . esc_html__( 'Select a country / region&hellip;', 'woocommerce' ) . '</option>';

					foreach ( $countries as $ckey => $cvalue ) {
						$field .= '<option value="' . esc_attr( $ckey ) . '" ' . selected( $value, $ckey, false ) . '>' . esc_html( $cvalue ) . '</option>';
					}

					$field .= '</select>';

					$field .= '<noscript><button type="submit" name="woocommerce_checkout_update_totals" value="' . esc_attr__( 'Update country / region', 'woocommerce' ) . '">' . esc_html__( 'Update country / region', 'woocommerce' ) . '</button></noscript>';

				}

				break;
			case 'state':
				/* Get country this state field is representing */
				$for_country = isset( $args['country'] ) ? $args['country'] : WC()->checkout->get_value( 'billing_state' === $key ? 'billing_country' : 'shipping_country' );
				$states      = WC()->countries->get_states( $for_country );

				if ( is_array( $states ) && empty( $states ) ) {

					$field_container = '<p class="form-row %1$s" id="%2$s" style="display: none">%3$s</p>';

					$field .= '<input type="hidden" class="hidden" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="" ' . implode( ' ', $custom_attributes ) . ' placeholder="' . esc_attr( $args['placeholder'] ) . '" readonly="readonly" data-input-classes="' . esc_attr( implode( ' ', $args['input_class'] ) ) . '"/>';

				} elseif ( ! is_null( $for_country ) && is_array( $states ) ) {
					$data_label = ! empty( $args['label'] ) ? 'data-label="' . esc_attr( $args['label'] ) . '"' : '';

		//=============added custom HTML tag in State Dropdown===================//	
					
					$field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="state_select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ? $args['placeholder'] : esc_html__( 'Select an option&hellip;', 'woocommerce' ) ) . '"  data-input-classes="' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . $data_label . '>
						<option value="">' . esc_html__( 'Select an option&hellip;', 'woocommerce' ) . '</option>';

					foreach ( $states as $ckey => $cvalue ) {
						$field .= '<option value="' . esc_attr( $ckey ) . '" ' . selected( $value, $ckey, false ) . '>' . esc_html( $cvalue ) . '</option>';
					}

					$field .= '</select>';

				} else {

					$field .= '<input type="text" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" value="' . esc_attr( $value ) . '"  placeholder="' . esc_attr( $args['placeholder'] ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" ' . implode( ' ', $custom_attributes ) . ' data-input-classes="' . esc_attr( implode( ' ', $args['input_class'] ) ) . '"/>';

				}

				break;
			case 'textarea':
			
		//=============added custom HTML tag class/id or more in order note teaxtarea===================//	
		
				$field .= '<textarea name="' . esc_attr( $key ) . '" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '" ' . ( empty( $args['custom_attributes']['rows'] ) ? ' rows="2"' : '' ) . ( empty( $args['custom_attributes']['cols'] ) ? ' cols="5"' : '' ) . implode( ' ', $custom_attributes ) . '>' . esc_textarea( $value ) . '</textarea>';

				break;
			case 'checkbox':
				$field = '<label class="checkbox ' . implode( ' ', $args['label_class'] ) . '" ' . implode( ' ', $custom_attributes ) . '>
						<input type="' . esc_attr( $args['type'] ) . '" class="input-checkbox ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="1" ' . checked( $value, 1, false ) . ' /> ' . $args['label'] . $required . '</label>';

				break;
			case 'text':
			case 'password':
			case 'datetime':
			case 'datetime-local':
			case 'date':
			case 'month':
			case 'time':
			case 'week':
			case 'number':
			case 'email':
			case 'url':
			case 'tel':
			
	//=============added custom HTML tag class/id or more in Input field===================//		
			
				$field .= '<input type="' . esc_attr( $args['type'] ) . '" class="input-text ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" placeholder="' . esc_attr( $args['placeholder'] ) . '"  value="' . esc_attr( $value ) . '" ' . implode( ' ', $custom_attributes ) . ' />';

				break;
			case 'hidden':
				$field .= '<input type="' . esc_attr( $args['type'] ) . '" class="input-hidden ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" value="' . esc_attr( $value ) . '" ' . implode( ' ', $custom_attributes ) . ' />';

				break;
			case 'select':
				$field   = '';
				$options = '';

				if ( ! empty( $args['options'] ) ) {
					foreach ( $args['options'] as $option_key => $option_text ) {
						if ( '' === $option_key ) {
							// If we have a blank option, select2 needs a placeholder.
							if ( empty( $args['placeholder'] ) ) {
								$args['placeholder'] = $option_text ? $option_text : __( 'Choose an option', 'woocommerce' );
							}
							$custom_attributes[] = 'data-allow_clear="true"';
						}
						$options .= '<option value="' . esc_attr( $option_key ) . '" ' . selected( $value, $option_key, false ) . '>' . esc_html( $option_text ) . '</option>';
					}

					$field .= '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $args['id'] ) . '" class="select ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" ' . implode( ' ', $custom_attributes ) . ' data-placeholder="' . esc_attr( $args['placeholder'] ) . '">
							' . $options . '
						</select>';
				}

				break;
			case 'radio':
				$label_id .= '_' . current( array_keys( $args['options'] ) );

				if ( ! empty( $args['options'] ) ) {
					foreach ( $args['options'] as $option_key => $option_text ) {
						$field .= '<input type="radio" class="input-radio ' . esc_attr( implode( ' ', $args['input_class'] ) ) . '" value="' . esc_attr( $option_key ) . '" name="' . esc_attr( $key ) . '" ' . implode( ' ', $custom_attributes ) . ' id="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '"' . checked( $value, $option_key, false ) . ' />';
						$field .= '<label for="' . esc_attr( $args['id'] ) . '_' . esc_attr( $option_key ) . '" class="radio ' . implode( ' ', $args['label_class'] ) . '">' . esc_html( $option_text ) . '</label>';
					}
				}

				break;
		}

		if ( ! empty( $field ) ) {
			$field_html = '';

			if ( $args['label'] && 'checkbox' !== $args['type'] ) {
				
//=============added custom HTML tag Label in Input Fields===================//		
		
				$field_html .= '<h6><label for="' . esc_attr( $label_id ) . '" class="' . esc_attr( implode( ' ', $args['label_class'] ) ) . '">' . wp_kses_post( $args['label'] ) . $required . '</label></h6>';
				
			}

//=============added custom HTML tag Before Input Fields===================//	
	
			$field_html .= '<span class="woocommerce-input-wrapper">' . $field;

			if ( $args['description'] ) {
				$field_html .= '<span class="description" id="' . esc_attr( $args['id'] ) . '-description" aria-hidden="true">' . wp_kses_post( $args['description'] ) . '</span>';
			}

			$field_html .= '</span>';

			$container_class = esc_attr( implode( ' ', $args['class'] ) );
			$container_id    = esc_attr( $args['id'] ) . '_field';
			$field           = sprintf( $field_container, $container_class, $container_id, $field_html );
		}

		/**
		 * Filter by type.
		 */
		$field = apply_filters( 'woocommerce_form_field_' . $args['type'], $field, $key, $args, $value );

		/**
		 * General filter on form fields.
		 *
		 * @since 3.4.0
		 */
		$field = apply_filters( 'woocommerce_form_field', $field, $key, $args, $value );

		if ( $args['return'] ) {
			return $field;
		} else {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $field;
		}
	}
}


//=============================woocommerce function ========================//



//====remove Add to cart Button Form Products=============//


	/*	
		add_filter( 'woocommerce_is_purchasable', '__return_false'); // DISABLING PURCHASE FUNCTIONALITY AND REMOVING ADD TO CART BUTTON FROM NORMAL PRODUCTS

		remove_action('woocommerce_single_variation', 'woocommerce_single_variation', 10); // REMOVING PRICE FROM VARIATIONS

		remove_action('woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20); // REMOVING ADD TO CART BUTTON FROM VARIATIONS

	*/

//-------============End===============-------//

//====Remove price from woocomerce store============//

	/*
		remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
		remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
	
	*/
	
//-------============End===============-------//

//====Remove Woocommerce Page Functionality==========================================//
	

		// Mike Code
		add_filter( 'woocommerce_product_is_visible','product_invisible');
		function product_invisible(){
		return false;
		}
		//Remove single page
		add_filter( 'woocommerce_register_post_type_product','hide_product_page',12,1);
		function hide_product_page($args){
		$args["publicly_queryable"]=false;
		$args["public"]=false;
		return $args;
		}

		//redirect to Home page, when a product category archive page is called:

		add_action( 'template_redirect', 'wc_redirect_to_shop');
		function wc_redirect_to_shop() {
			// Only on product category archive pages (redirect to shop)
			if ( is_product_category() ) {
				wp_redirect( wc_get_page_permalink( 'home' ) );
				exit();
			}
		}
		
		////redirect to Home page, when a Cart  page is called:
		
		add_action( 'template_redirect', 'cart_redirect_404' );
			function cart_redirect_404(){
				// Redirect to non existing page that will make a 404
				if ( is_cart() ) {
					wp_redirect( wc_get_page_permalink( 'home' ) );
					exit();
				}
			}
	//-------===========================-------//



//====remove woocomer default style=====//

/*	add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );*/
		

//====html star review rating modify==== //

/*
	add_filter('woocommerce_get_star_rating_html', 'replace_star_ratings', 10, 2);
	function replace_star_ratings($html, $rating) {
		$html = ""; // Erase default HTML
		for($i = 0; $i < 5; $i++) {
			$html .= $i < $rating ? '<li class="ratted"><i class="far fa-star"></i></li>' : '<li><i class="far fa-star"></i></li>';
		}
		return $html;
	}
*/	



//====Display html star review rating In Cart Page Below Title==== //


// with hook------------------

/*
	add_filter('woocommerce_after_cart_item_name', 'woocommerce_after_cart_item_name', 10, 2);
	function woocommerce_after_cart_item_name( $cart_item, $cart_item_key  ){
		$product      = wc_get_product( $cart_item['product_id'] );
		$rating_count = $product->get_rating_count();
		$review_count = $product->get_review_count();
		$average      = $product->get_average_rating();
		if ( $rating_count > 0 ) : ?>
			<div class="woocommerce-product-rating">
				<?php echo wc_get_rating_html( $average, $rating_count ); // WPCS: XSS ok. ?>
				<div class="count"><?php echo esc_html( $review_count ); ?> Reviews</div>
			</div>
		<?php endif;
	}
*/

// direct use in any where--------------


/*
	<?php 
	
		$product      = wc_get_product( $cart_item['product_id'] );
		$rating_count = $product->get_rating_count();
		$review_count = $product->get_review_count();
		$average      = $product->get_average_rating();
		if ( $rating_count > 0 ) : ?>
			<div class="woocommerce-product-rating">
				<?php echo wc_get_rating_html( $average, $rating_count ); // WPCS: XSS ok. ?>
				<div class="count"><?php echo esc_html( $review_count ); ?> Reviews</div>
			</div>
		<?php endif;
										
										
	?>

*/

//=========Display In Frontend Receive Order Image In Thank You Page ===========//

/*
	if ( ! is_order_received_page() ) {
		return ;
	}

	// Get a list of all items that belong to the order
	$products = $order->get_items();

	// Loop through the items and get the product image
	foreach( $products as $product ) {                  

		$product_obj = new WC_Product( $product["product_id"] );

		echo $product_obj->get_image();

	}	

*/
//===============  Display Custom Add to Cart / Add to wishlist only Button In Frontend =============//

//use below code only frontend anywhere

//Add to Cart Button-----------------------------	

/*	  
	<?php if ( Restling_set($sec_one, 'enable_btn' ) ==='true'?true :false) : ?>	
			<a href="<?php echo esc_url(home_url('/?add-to-cart=')); ?><?php echo esc_html(Restling_set( $sec_one, 'pro_id' )); ?>" class="site-btn mt-15"><?php echo esc_html(Restling_set( $sec_one, 'btn_label' )); ?></a>
	<?php endif; ?>	

			//Add to Wishlist Button-------------------	
				
	<?php if ( Restling_set($sec_one, 'wenable_btn' ) ==='true'?true :false) : ?>	
					
		   <?php if(is_plugin_active('yith-woocommerce-wishlist/init.php'))
			  {
				   //plugin is activated 
				$base_url=yith_wcwl_get_current_url();
				//$product_id = $product->get_id();
				$product_ids =esc_html(Restling_set( $sec_one, 'wpro_id' )); 
			?>	
			
		<?php if ( is_user_logged_in() ) :?>		
			<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'add_to_wishlist', $product_ids, $base_url ), 'add_to_wishlist' ) ); ?>" class="site-btn mt-15"><?php echo esc_html(Restling_set( $sec_one, 'wbtn_label' )); ?></a>
		<?php endif;?>	
		
			 <?php }else
			  {
				  //plugin is not activated
				
			  } ?>
	<?php endif; ?>  

*/
//===============  Display Custom Message when click on  Add to wishlist =============//

//use below code In Frontend singlr-product0cintent.php
/*
			<?php if (QSInspection_set($_GET,'add_to_wishlist')) : ?>
				<div class="col-lg-12 col-md-12 wishlist-info">
					<p>Product added to wishlist</p>
				</div>
			<?php endif;?>
*/

//===============  Display Customer Login/Logout Button only In Frontend =============//

//use below code only frontend anywhere
/*
 <?php if ( is_user_logged_in() ) {?>
		<h5>Returning customer?
			<span>Click here to Logout</span>
		</h5>
		<a href="<?php echo wp_logout_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ) ; ?>" class="theme-black-btn">Log Out</a>
	<?php }else{?>
		<h5>Returning customer?
			<span>Click here to login</span>
		</h5>
	<a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" class="theme-black-btn">Login Now</a>
	<?php }?>	

*/

//===============  Display user/minicart/wishlist icon Button only In Frontend =============//

//use below code only frontend anywhere	

/*
  //for mobile view
  <div class="page_icon_area circle-list22 d-lg-none ml-30"></div>
*/

/*
   <div class="circle-list22 d-inline-block ml-30">
						
	<?php
	//icon enable disable 

		$enable_search_btn = ramsesOil_set($options,'enable_search_btn');
		
		$enable_wishlist = ramsesOil_set($options,'enable_wishlist');
		$wish_icon = ramsesOil_set($options,'wish_icon');		
		$wish_url = ramsesOil_set($options,'wish_url');
		
		$enable_user = ramsesOil_set($options,'enable_user');
		$user_icon = ramsesOil_set($options,'user_icon');
		$user_url = ramsesOil_set($options,'user_url');
		
		$enable_mini_cart = ramsesOil_set($options,'enable_mini_cart');
		$topbar_address_url = ramsesOil_set($options,'topbar_address_url');
	
	?>
	
	   <ul>
				
			<?php //if ( is_user_logged_in() ) :?>	
					<?php if ($enable_wishlist) : ?>			
				<li> 
						<?php
							$count = 0;
							if( function_exists( 'yith_wcwl_count_products' ) ){
								$count = yith_wcwl_count_products();
							}
						?>
						<a href="<?php echo esc_url(home_url('/wishlist')); ?>" class="hert-btn"><i class="far fa-heart"></i></a>
					<sup><?php echo $count; ?></sup>
				</li>
			<?php endif;?>	
					
				<?php //endif; ?>	
			<?php if ($enable_user) : ?>	
				<li> 
					
						<a id="usericon" href="<?php echo esc_url(get_permalink( wc_get_page_id( 'myaccount' ) )); ?>" class="hert-btn"><i class="far fa-user"></i></a>
					
				
				</li>
			<?php endif; ?>	
			<?php if ($enable_mini_cart) : ?>
				<li> 
			
				<?php global $woocommerce;?>
					<a href="<?php echo esc_url(wc_get_cart_url() ); ?>">
						<i class="fas fa-shopping-bag"></i>
						
					</a>
			  				
					<sup><?php echo sprintf(_n('%d', '%d', $woocommerce->cart->cart_contents_count, 'restling'), $woocommerce->cart->cart_contents_count); ?></sup>
				</li>
			<?php endif; ?>	
			</ul>
	</div>

*/
		
//===== remove the action breadcrumb====//

/*
	remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);

*/
	
//=========change all thins breadcrumb===========//

/*
	function ecom_woocommerce_breadcrum(){

		return array(
			'delimiter'  => '&#47;',
			'wrap_before'  => '<div class="breadcrumb-inner"><ul class="list-inline list-unstyled">',
			'wrap_after'  => '</ul></div>',
			'before'  => '<li>',
			'after'  => '</li>',
			'home'  => _x('Home','breadcrum','woocommerce'),
		);

	}
	add_filter('woocommerce_breadcrumb_defaults','ecom_woocommerce_breadcrum');

	
*/	
	
//=========Dsiplay Custom Breadcrumb===========//

/*
	function texasTiresv_the_breadcrumb() {
		global $wp_query;

		$queried_object = get_queried_object();

		$breadcrumb = '';
		$delimiter = ' / ';
		$before = '<li class="breadcrumb-item">';
		
		$after = '</li>';

		if ( ! is_front_page() )
		{
			$breadcrumb .= $before . '<a href="'.home_url( '/' ).'">'.esc_html__( 'Home', 'actavista' ).'</a>' . $after;
			// If category or single post/

			if(is_category())
			{
				$cat_obj = $wp_query->get_queried_object();
				$this_category = get_category( $cat_obj->term_id );

				if ( $this_category->parent != 0 ) {
					$parent_category = get_category( $this_category->parent );
					$breadcrumb .= get_category_parents($parent_category, TRUE, $delimiter );
				}	
				$breadcrumb .= $before . '<a href="'.get_category_link(get_query_var('cat')).'">'.single_cat_title('', FALSE).'</a>' . $after;
			}
			elseif ( $wp_query->is_posts_page ) {
				$breadcrumb .= $before . $queried_object->post_title . $after;
			}
			elseif( is_tax() )
			{
				$breadcrumb .= $before . '<a href="'.get_term_link($queried_object).'">'.$queried_object->name.'</a>' . $after;
			}
			elseif(is_page()) // If WP pages //
			{
				global $post;
				if($post->post_parent)
				{
					$anc = get_post_ancestors($post->ID);
					foreach($anc as $ancestor)
					{
						$breadcrumb .= $before . '<a href="'.get_permalink( $ancestor ).'">'.get_the_title( $ancestor ).' &nbsp;</a>' . $after;
					}
					$breadcrumb .= $before . ''.get_the_title( $post->ID ).'' . $after;
					
				}else $breadcrumb .= $before . ''.get_the_title().'' . $after;
			}
			elseif ( is_singular() )
			{
				if( $category = wp_get_object_terms( get_the_ID(), array( 'category', 'location', 'tax_feature' ) ) )
				{

					if( !is_wp_error($category) )
					{
						$breadcrumb .= $before . '<a href="'.get_term_link( QSInspection_set($category, '0' ) ).'">'.QSInspection_set( QSInspection_set( $category, '0' ), 'name').'&nbsp;</a>' . $after;
						$breadcrumb .= $before . ''.get_the_title().'' . $after;
					} else {
						$breadcrumb .= $before . ''.get_the_title().'' . $after;
					}
				}else{
					$breadcrumb .= $before . ''.get_the_title().'' . $after;
				}

			}
			elseif(is_tag()) $breadcrumb .= $before . '<a href="'.get_term_link($queried_object).'">'.single_tag_title('', FALSE).'</a>' . $after; //If tag template//
			elseif(is_day()) $breadcrumb .= $before . '<a href="#">'.esc_html__('Archive for ', 'actavista').get_the_time('F jS, Y').'</a>' . $after; // If daily Archives //
			elseif(is_month()) $breadcrumb .= $before . '<a href="' .get_month_link(get_the_time('Y'), get_the_time('m')) .'">'.__('Archive for ', 'actavista').get_the_time('F, Y').'</a>' . $after; 
			// If montly Archives //
			elseif(is_year()) $breadcrumb .= $before . '<a href="'.get_year_link(get_the_time('Y')).'">'.__('Archive for ', 'actavista').get_the_time('Y').'</a>' . $after; // If year Archives //
			elseif(is_author()) $breadcrumb .= $before . '<a href="'. esc_url( get_author_posts_url( get_the_author_meta( "ID" ) ) ) .'">'.__('Archive for ', 'actavista').get_the_author().'</a>' . $after; // If author Archives //
			elseif(is_search()) $breadcrumb .= $before . ''.esc_html__('Search Results for ', 'actavista').get_search_query().'' . $after; // if search template //
			elseif(is_404())  {
				$breadcrumb .= $before . ''.esc_html__('404 - Not Found', 'actavista').'' . $after; // if search template //
			}  
			elseif ( is_post_type_archive('product') ) 
			{
				
				$shop_page_id = wc_get_page_id( 'shop' );
				if( get_option('page_on_front') !== $shop_page_id  )
				{
					$shop_page    = get_post( $shop_page_id );
					
					$_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
					
					if ( ! $_name ) {
						$product_post_type = get_post_type_object( 'product' );
						$_name = $product_post_type->labels->singular_name;
					}
					
					if ( is_search() ) {
						
						$breadcrumb .= $before . '<a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a>' . $delimiter . esc_html__( 'Search results for &ldquo;', 'actavista' ) . get_search_query() . '&rdquo;' . $after;
						
					} elseif ( is_paged() ) {
						
						$breadcrumb .= $before . '<a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a>' . $after;
						
					} else {
						
						$breadcrumb .= $before . $_name . $after;
						
					}
				}
				
			}
			else 

				$breadcrumb .= $before . '<a href="'.get_permalink().'">'.get_the_title().'</a>' . $after; 
				// Default value //
			
		}

		return $breadcrumb;
	}
*/


//Display In Frontend
/*
	<?php echo texasTiresv_the_breadcrumb(); ?>

*/
	
//===== Display Product Specific Attribuite value in Single Product rule-01====//	

/*	
	function nt_product_attributes() {
			global $product;
				if ( $product->has_attributes() ) {

					$attributes = array (
					//'color'              => $product->get_attribute('pa_color'),
					//'size'            => $product->get_attribute('pa_size'),
					'brand'            => $product->get_attribute('pa_brand'),
					);
				return $attributes;
				}
			}
	
	
*/

/*
only use for single product page
-----------------------------------------
 Display in frontend 
 <?php $attributes = nt_product_attributes();?>
 <?php echo $attributes['brand']; ?>
*/


//=====Display Specific Variabel Product Attribuite value rule-02=======//

/*
	<?php if (  $product->has_attributes() && $product->is_type( 'variable' ) ) :
            $vari =$product->get_variation_attributes();
            $brand=TirePro_set($vari, 'pa_brands');
            $array_lenght = count($brand);
        ?>
        <?php foreach ($brand as $x =>  $value) : ?>
            <span><?php echo $value; ?></span>

        <?php endforeach; ?>
            
        <?php 
    endif; ?>

*/

//==Display Product By Specific Attribuite Filter in Frontend (Must Be Checkbox tick Enable archives?)=======//
// install category image plugin for get image
//use below code only frontend anywhere

/*
		$terms = get_terms( 'pa_brands' );
						
		echo '<div class="brand-acive-slider">';
		foreach ($terms as $each_term) {
			 if (function_exists('z_taxonomy_image_url')) 
				$img = z_taxonomy_image_url($each_term->term_id);
			
			echo '<div class="single-brand-wrap style-border">';   
			//echo '<img src="'.$img.'" alt="" /><a href="' . get_term_link( $each_term ) . '">' . $each_term->name . '</a>';
			echo '<div class="signle-brand">
								<a href="'. get_term_link( $each_term ) . '"><img src="'.$img.'" alt=""></a>
							</div>';
			
			echo '</div>';   
		}
		echo '</div>';

*/	
//===remove sale flush from single or shop========//

/*
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
	remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
*/

//===customize sale flush Text========//

/*
	function bbloomer_rename_sale_badge() {
	   return '<span class="onsale">ON OFFER</span>';
	}
	add_filter( 'woocommerce_sale_flash', 'bbloomer_rename_sale_badge', 9999 );	
	
*/
	
//====remove sidebar from single product page====//

/*
	function remove_sidebar_shop() {
		if ( is_singular('product') ) {
			remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar');
		}
	}
	add_action('template_redirect', 'remove_sidebar_shop');
*/

//===related product position=====//

/*
	remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
	add_action('woocommerce_after_single_product', 'woocommerce_output_related_products', 9);

*/

//===Remove woocommerce_result_count=====//

/*
	function ecom_remove_show_result(){
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
	}
	add_action('init','ecom_remove_show_result');

*/
//===Display woocommerce_result_count Anywhere=====//

/*
just call below code and modify woo in result-count.php file

<?php woocommerce_result_count();?>

*/

	
//===Remove woocommerce_catalog_ordering=====//

/*
	function ecom_remove_ordering(){
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
	}
	add_action('init','ecom_remove_ordering');
*/
	
//=========woocommerce custom Catalog ordering=========//
 
/* 
	function ecom_custom_woocommerce_catalog_orderby( $sortby ) {
		$sortby['random_list'] = 'position';
		$sortby['price-desc'] = 'Price:Lowest first';
		$sortby['price'] = 'Price:HIghest first';
		$sortby['menu_order'] = 'Product Name:A to Z';
		unset($sortby['popularity']);
		unset($sortby['rating']);
		unset($sortby['date']);
		return $sortby;
	}
	add_filter( 'woocommerce_catalog_orderby', 'ecom_custom_woocommerce_catalog_orderby' );	

*/
	
//======display product per page show dorpdown  option in shop archive page beside catelog ordering======= //

/*
	add_action( 'woocommerce_before_shop_loop', 'ps_selectbox', 25 );
	function ps_selectbox() {
		$per_page = filter_input(INPUT_GET, 'perpage', FILTER_SANITIZE_NUMBER_INT);     
		echo '<div class="select-item">';
		echo '<span>VIEW </span>';
		echo '<select onchange="if (this.value) window.location.href=this.value">';   
		$orderby_options = array(
			'8' => '8',
			'16' => '16',
			'32' => '32',
			'64' => '64',
			'-1' 		=> __('All', 'woocommerce'),
		);
		foreach( $orderby_options as $value => $label ) {
			echo "<option ".selected( $per_page, $value )." value='?perpage=$value'>$label</option>";
		}
		echo '</select>';
		echo '</div>';
	}
	add_action( 'pre_get_posts', 'ps_pre_get_products_query' );
	function ps_pre_get_products_query( $query ) {
	   $per_page = filter_input(INPUT_GET, 'perpage', FILTER_SANITIZE_NUMBER_INT);
	   if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'product' ) ){
			$query->set( 'posts_per_page', $per_page );
		}
	}

*/

//shop page post per page//

/*

	add_action( 'woocommerce_product_query', 'woocommerce_product_query' );
	function woocommerce_product_query( $q ) {
		if ( $q->is_main_query() && ( $q->get( 'wc_query' ) === 'product_query' ) ) {
			$q->set( 'posts_per_page', '4' );
		}
	}

*/

//===============  Remove shop pagination=============//

/*
	function ecom_remove_paginatation(){
		remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
	}
	add_action('init','ecom_remove_paginatation');
*/

//=============== wordpress custom pagination=============//

/*
	function ecom_pagination(){
		global $wp_query;

		if ( $wp_query->max_num_pages <= 1 ) return; 

		$big = 999999999; // need an unlikely integer

		$pages = paginate_links( array(
			'base'    	=> str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format'  	=> '?paged=%#%',
			'current' 	=> max( 1, get_query_var('paged') ),
			'total'   	=> $wp_query->max_num_pages,
			'type'    	=> 'array',
			'prev_next' => true,
			'prev_text' => __('<i class="fa fa-angle-left" aria-hidden="true"></i>'),
			'next_text' => __('<i class="fa fa-angle-right" aria-hidden="true"></i>'),
		) );
		
		if( is_array( $pages ) ) {
			$paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
			echo '<div class="pagination-container test"><ul class="list-inline list-unstyled">';
			foreach ( $pages as $page ) {
					echo "<li>$page</li>";
			}
		   echo '</ul></div>';
		}
	}

*/


//=============== Remove Review Tab=============//

/*
	add_filter( 'woocommerce_product_tabs', 'delete_tab', 98 );

	function delete_tab( $tabs ) {

		if ( ! have_comments() ) {
			unset( $tabs['reviews'] );
		}

		return $tabs;
	}

*/

//=============== Display custom Style Shipping Checkbox toggle (Use Fontend) =============//
/*
	<div class="sip_difrent" id="ship-to-different-address">
	   <input id="ship-to-different-address-checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" <?php checked( apply_filters( 'woocommerce_ship_to_different_address_checked', 'shipping' === get_option( 'woocommerce_ship_to_destination' ) ? 1 : 0 ), 1 ); ?> type="checkbox" name="ship_to_different_address" value="1" />
                  
	  <label for="ship-to-different-address-checkbox" class="checkbox"><span></span>
		<?php _e( 'Ship to a different address?', 'woocommerce' ); ?></label>
	</div>

*/	
//=============== Display Icon In My Account Nave Menu (Use Fontend) =============//	
/*	
	//call below code Outside Foreach loop 
	<?php 
		$icons = [
		'dashboard' => '<i class="far fa-tachometer"></i>',
		'orders' => '<i class="far fa-calendar-alt"></i>',
		'edit-account' => ' <i class="fal fa-cog"></i> ',
		'customer-logout' => '<i class="fal fa-sign-out"></i>',
		'downloads' => '<i class="icon-downloads"></i>',
		'edit-address' => '<i class="far fa-map-marker-alt"></i>'
	];

	?>
	
  //call below code inside foreach loop
 <?php echo $icons[$endpoint] ?>  
	
*/

//===============  WooCommerce: My Account Orders Pagination - per page setting =============//

/*
	function kbnt_my_account_orders( $args ) {
		$args['posts_per_page'] = 5; // add number or -1 (display all orderes per page)
		return $args;
	}
	add_filter( 'woocommerce_my_account_my_orders_query', 'kbnt_my_account_orders', 10, 1 );

*/

//=============== Display Custom Pagination In Order History (Use Fontend) =============//	

/*
	<?php
	$args = array(
		'base'          => esc_url( wc_get_endpoint_url( 'orders') ) . '%_%',
		'format'        => '%#%',
		'total'         => $customer_orders->max_num_pages,
		'current'       => $current_page,
		'show_all'      => false,
		'end_size'      => 3,
		'mid_size'      => 3,
		'prev_next'     => true,
		'prev_text'     => '&larr;',
		'next_text'     => '&rarr;',
		'type'          => 'list',
		'add_args'      => false,
		'add_fragment'  => ''
	);
	echo paginate_links( $args );
	?>

*/

//===============  change woocomerce place order button text =============//	

/*
	//change woocomerce place order button text
	add_filter( 'woocommerce_order_button_text', 'woo_custom_order_button_text' ); 

	function woo_custom_order_button_text() {
		return __( 'Complete Order', 'woocommerce' ); 
	}


*/

//===============  converts an html color name to a hex color value =============//	

/*
	function color_name_to_hex($color_name)
	{
		// standard 147 HTML color names
		$colors  =  array(
			'aliceblue'=>'F0F8FF',
			'antiquewhite'=>'FAEBD7',
			'aqua'=>'00FFFF',
			'aquamarine'=>'7FFFD4',
			'azure'=>'F0FFFF',
			'beige'=>'F5F5DC',
			'bisque'=>'FFE4C4',
			'black'=>'000000',
			'blanchedalmond '=>'FFEBCD',
			'blue'=>'0000FF',
			'blueviolet'=>'8A2BE2',
			'brown'=>'A52A2A',
			'burlywood'=>'DEB887',
			'cadetblue'=>'5F9EA0',
			'chartreuse'=>'7FFF00',
			'chocolate'=>'D2691E',
			'coral'=>'FF7F50',
			'cornflowerblue'=>'6495ED',
			'cornsilk'=>'FFF8DC',
			'crimson'=>'DC143C',
			'cyan'=>'00FFFF',
			'darkblue'=>'00008B',
			'darkcyan'=>'008B8B',
			'darkgoldenrod'=>'B8860B',
			'darkgray'=>'A9A9A9',
			'darkgreen'=>'006400',
			'darkgrey'=>'A9A9A9',
			'darkkhaki'=>'BDB76B',
			'darkmagenta'=>'8B008B',
			'darkolivegreen'=>'556B2F',
			'darkorange'=>'FF8C00',
			'darkorchid'=>'9932CC',
			'darkred'=>'8B0000',
			'darksalmon'=>'E9967A',
			'darkseagreen'=>'8FBC8F',
			'darkslateblue'=>'483D8B',
			'darkslategray'=>'2F4F4F',
			'darkslategrey'=>'2F4F4F',
			'darkturquoise'=>'00CED1',
			'darkviolet'=>'9400D3',
			'deeppink'=>'FF1493',
			'deepskyblue'=>'00BFFF',
			'dimgray'=>'696969',
			'dimgrey'=>'696969',
			'dodgerblue'=>'1E90FF',
			'firebrick'=>'B22222',
			'floralwhite'=>'FFFAF0',
			'forestgreen'=>'228B22',
			'fuchsia'=>'FF00FF',
			'gainsboro'=>'DCDCDC',
			'ghostwhite'=>'F8F8FF',
			'gold'=>'FFD700',
			'goldenrod'=>'DAA520',
			'gray'=>'808080',
			'green'=>'008000',
			'greenyellow'=>'ADFF2F',
			'grey'=>'808080',
			'honeydew'=>'F0FFF0',
			'hotpink'=>'FF69B4',
			'indianred'=>'CD5C5C',
			'indigo'=>'4B0082',
			'ivory'=>'FFFFF0',
			'khaki'=>'F0E68C',
			'lavender'=>'E6E6FA',
			'lavenderblush'=>'FFF0F5',
			'lawngreen'=>'7CFC00',
			'lemonchiffon'=>'FFFACD',
			'lightblue'=>'ADD8E6',
			'lightcoral'=>'F08080',
			'lightcyan'=>'E0FFFF',
			'lightgoldenrodyellow'=>'FAFAD2',
			'lightgray'=>'D3D3D3',
			'lightgreen'=>'90EE90',
			'lightgrey'=>'D3D3D3',
			'lightpink'=>'FFB6C1',
			'lightsalmon'=>'FFA07A',
			'lightseagreen'=>'20B2AA',
			'lightskyblue'=>'87CEFA',
			'lightslategray'=>'778899',
			'lightslategrey'=>'778899',
			'lightsteelblue'=>'B0C4DE',
			'lightyellow'=>'FFFFE0',
			'lime'=>'00FF00',
			'limegreen'=>'32CD32',
			'linen'=>'FAF0E6',
			'magenta'=>'FF00FF',
			'maroon'=>'800000',
			'mediumaquamarine'=>'66CDAA',
			'mediumblue'=>'0000CD',
			'mediumorchid'=>'BA55D3',
			'mediumpurple'=>'9370D0',
			'mediumseagreen'=>'3CB371',
			'mediumslateblue'=>'7B68EE',
			'mediumspringgreen'=>'00FA9A',
			'mediumturquoise'=>'48D1CC',
			'mediumvioletred'=>'C71585',
			'midnightblue'=>'191970',
			'mintcream'=>'F5FFFA',
			'mistyrose'=>'FFE4E1',
			'moccasin'=>'FFE4B5',
			'navajowhite'=>'FFDEAD',
			'navy'=>'000080',
			'oldlace'=>'FDF5E6',
			'olive'=>'808000',
			'olivedrab'=>'6B8E23',
			'orange'=>'FFA500',
			'orangered'=>'FF4500',
			'orchid'=>'DA70D6',
			'palegoldenrod'=>'EEE8AA',
			'palegreen'=>'98FB98',
			'paleturquoise'=>'AFEEEE',
			'palevioletred'=>'DB7093',
			'papayawhip'=>'FFEFD5',
			'peachpuff'=>'FFDAB9',
			'peru'=>'CD853F',
			'pink'=>'FFC0CB',
			'plum'=>'DDA0DD',
			'powderblue'=>'B0E0E6',
			'purple'=>'800080',
			'red'=>'FF0000',
			'rosybrown'=>'BC8F8F',
			'royalblue'=>'4169E1',
			'saddlebrown'=>'8B4513',
			'salmon'=>'FA8072',
			'sandybrown'=>'F4A460',
			'seagreen'=>'2E8B57',
			'seashell'=>'FFF5EE',
			'sienna'=>'A0522D',
			'silver'=>'C0C0C0',
			'skyblue'=>'87CEEB',
			'slateblue'=>'6A5ACD',
			'slategray'=>'708090',
			'slategrey'=>'708090',
			'snow'=>'FFFAFA',
			'springgreen'=>'00FF7F',
			'steelblue'=>'4682B4',
			'tan'=>'D2B48C',
			'teal'=>'008080',
			'thistle'=>'D8BFD8',
			'tomato'=>'FF6347',
			'turquoise'=>'40E0D0',
			'violet'=>'EE82EE',
			'wheat'=>'F5DEB3',
			'white'=>'FFFFFF',
			'whitesmoke'=>'F5F5F5',
			'yellow'=>'FFFF00',
			'yellowgreen'=>'9ACD32');

		$color_name = strtolower($color_name);
		if (isset($colors[$color_name]))
		{
			return ('<span style="display: block;height: 30px; width: 30px;background-color:#' . $colors[$color_name].';border: 1px solid gray;line-height: 20px;"></span>');
		}
		else
		{
			return ($color_name);
		}
	}
	
	//call in frontent or woo variation display (cart-item-data.php)
	
		<dd class="<?php echo sanitize_html_class( 'variation-' . $data['key'] ); ?>">
			<?php if ($data['key'] == 'Color') : ?>
					<?php echo wp_kses_post( color_name_to_hex($data['display'])); ?>
					<?php else : ?>
					<?php echo wp_kses_post( (wpautop( $data['display'] ) )); ?>    
			<?php endif; ?>
         </dd>
	
*/	

//===============  change woocomerce VAT Or Tax Name =============//	

/*
	add_filter( 'woocommerce_countries_tax_or_vat', function () {
	  return __( 'GST', 'woocommerce' );
	});

*/	
//--------------------END-------------------------------//

//=== Move / Remove Coupon Form @ Cart & Checkout=====//
	
//remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );


//===Remove Related product from single product page ========//

//remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );


