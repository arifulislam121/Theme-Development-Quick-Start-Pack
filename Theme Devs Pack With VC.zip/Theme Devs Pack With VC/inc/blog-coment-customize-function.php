<?php

//===========================================
//default comment form customize
//===========================================


/**
 * Customize comment form default fields.
 * Move the comment_field below the author, email, and url fields.
 */
function wpse250243_comment_form_default_fields( $fields ) {
    $commenter     = wp_get_current_commenter();
    $user          = wp_get_current_user();
    $user_identity = $user->exists() ? $user->display_name : '';
    $req           = get_option( 'require_name_email' );
    $aria_req      = ( $req ? " aria-required='true'" : '' );
    $html_req      = ( $req ? " required='required'" : '' );
    $html5         = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : false;

	
    $fields = [
        'author' => '<div class="row"><div class="col-lg-6">
                              <div class="input-item comment-form-author">' . '<label for="author">' . __( 'Complete Name', 'textdomain'  ) . ( $req ? ' <span class="required">*</span>' : '' ) . '</label> ' .
                    '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" maxlength="245"' . $aria_req . $html_req . ' /></div>
                           </div>',
					
        'email'  => '<div class="col-lg-6">
                              <div class="input-item mt-xs-20 mt-md-20 comment-form-email"><label for="email">' . __( 'Email Address', 'textdomain'  ) . ( $req ? ' <span class="required">*</span>' : '' ) . '</label> ' .
                    '<input id="email" name="email" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" maxlength="100" aria-describedby="email-notes"' . $aria_req . $html_req  . ' /></div>
                           </div></div>',
	/*				
        'url'    => '<p class="comment-form-url"><label for="url">' . __( 'Website CUSTOMIZED', 'textdomain'  ) . '</label> ' .
                    '<input id="url" name="url" ' . ( $html5 ? 'type="url"' : 'type="text"' ) . ' value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="30" maxlength="200" /></p>',
					
	
*/		
		
		
    ];


    return $fields;
}
add_filter( 'comment_form_default_fields', 'wpse250243_comment_form_default_fields' );






//===========================================

//Add Rating Option In Coment section
//===========================================



// Add fields after default fields above the comment box, always visible

/*
	add_action( 'comment_form_logged_in_after', 'additional_fields' );
	add_action( 'comment_form_after_fields', 'additional_fields' );

	function additional_fields () {
	  echo '<p class="comment-form-title">'.
	  '<label for="title">' . __( 'Comment Title' ) . '</label>'.
	  '<input id="title" name="title" type="text" size="30"  tabindex="5" /></p>';

	  echo '<p class="comment-form-rating">'.
	  '<label for="rating">'. __('Rating') . '<span class="required">*</span></label>
	  <span class="commentratingbox">';

		//Current rating scale is 1 to 5. If you want the scale to be 1 to 10, then set the value of $i to 10.
		for( $i=1; $i <= 5; $i++ )
		echo '<span class="commentrating"><input type="radio" name="rating" id="rating" value="'. $i .'"/>'. $i .'</span>';

	  echo'</span></p>';

	}
*/

//===========================================

//Change the tag of the comment submit button
//===========================================

add_filter( 'comment_form_defaults', function( $defaults )
{
    // Edit this to your needs:
    $button = '<div class="submit-btn mt-30 mt-xs-20"><input name="%1$s" type="submit" id="%2$s" class="site-btn" value="%4$s" /></div>';

    // Override the default submit button:
    $defaults['submit_button'] = $button;

    return $defaults;
} );





//===========================================
//comment list Html Modify-----------
//===========================================


function mytheme_comment( $comment, $args, $depth ) {

	if ( 'div' === $args['style'] ) {
		$tag       = 'div';
		$add_below = 'comment';
	}
	else {
		$tag       = 'li';
		$add_below = 'div-comment';
	}

	$classes = ' ' . comment_class( empty( $args['has_children'] ) ? '' : 'parent', null, null, false );
	?>

	<<?= $tag . $classes; ?> id="comment-<?php comment_ID() ?>">
	<?php if ( 'div' != $args['style'] ) { ?>
		<div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php
	} ?>

	 <div class="comment-author position-relative mb-xs-30 mb-md-30">
	 
	   <?php
		if ( $args['avatar_size'] != 0 ) {
			echo get_avatar( $comment, $args['avatar_size'] );
		}
		
	/*	
		printf(
			__( '<cite class="fn">%s</cite> <span class="says">says:</span>' ),
			get_comment_author_link()
		);
		
	*/	
		?>
	</div>
	<div class="comment-content flex-1 pl-20 pl-xs-0">
	   <h4><?php printf(__( '%s' ),get_comment_author_link());?> <span class="text-uppercase"><?php
			printf(
				__( '%1$s at %2$s' ),
				get_comment_date(),
				get_comment_time()
			); ?></span></h4>
	   <p><?php comment_text(); ?></p>
	</div>
	
	<?php
		comment_reply_link(
			array_merge(
				$args,
				array(
					'add_below' => $add_below,
					'depth'     => $depth,
					'max_depth' => $args['max_depth']
				)
			)
		); ?>

	

	<?php if ( $comment->comment_approved == '0' ) { ?>
		<em class="comment-awaiting-moderation">
			<?php _e( 'Your comment is awaiting moderation.' ); ?>
		</em><br/>
	<?php } ?>

	
	
<!----
	<div class="comment-meta commentmetadata">
		<a href="<?php //echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>">
			<?php
		/*	
			printf(
				__( '%1$s at %2$s' ),
				get_comment_date(),
				get_comment_time()
			); 
		*/	
			?>
		</a>

		<?php //edit_comment_link( __( '(Edit)' ), '  ', '' ); ?>
	</div>

--->
	
<!---
	<div class="reply">
		<?php
	/*	comment_reply_link(
			array_merge(
				$args,
				array(
					'add_below' => $add_below,
					'depth'     => $depth,
					'max_depth' => $args['max_depth']
				)
			)
		); 
	*/	
		?>
	</div>
--->	
	

	<?php if ( 'div' != $args['style'] ) { ?>
		</div>
	<?php }
}
