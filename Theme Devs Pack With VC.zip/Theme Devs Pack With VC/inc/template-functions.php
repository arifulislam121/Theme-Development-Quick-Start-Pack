<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package QSInspection
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function qsinspectionbody_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'qsinspectionbody_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function qsinspectionpingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'qsinspectionpingback_header' );

function texasTiresv_the_breadcrumb() {
	global $wp_query;

	$queried_object = get_queried_object();

	$breadcrumb = '';
	$delimiter = ' / ';
	$before = '<li>';
	
	$after = '</li>';

	if ( ! is_front_page() )
	{
		$breadcrumb .= $before . '<a href="'.home_url( '/' ).'">'.esc_html__( 'Home', 'actavista' ).'</a>' . $after;
		/** If category or single post */

		if(is_category())
		{
			$cat_obj = $wp_query->get_queried_object();
			$this_category = get_category( $cat_obj->term_id );

			if ( $this_category->parent != 0 ) {
				$parent_category = get_category( $this_category->parent );
				$breadcrumb .= get_category_parents($parent_category, TRUE, $delimiter );
			}	
			$breadcrumb .= $before . '<a href="'.get_category_link(get_query_var('cat')).'">'.single_cat_title('', FALSE).'</a>' . $after;
		}
		elseif ( $wp_query->is_posts_page ) {
			$breadcrumb .= $before . $queried_object->post_title . $after;
		}
		elseif( is_tax() )
		{
			$breadcrumb .= $before . '<a href="'.get_term_link($queried_object).'">'.$queried_object->name.'</a>' . $after;
		}
		elseif(is_page()) /** If WP pages */
		{
			global $post;
			if($post->post_parent)
			{
				$anc = get_post_ancestors($post->ID);
				foreach($anc as $ancestor)
				{
					$breadcrumb .= $before . '<a href="'.get_permalink( $ancestor ).'">'.get_the_title( $ancestor ).' &nbsp;</a>' . $after;
				}
				$breadcrumb .= $before . ''.get_the_title( $post->ID ).'' . $after;
				
			}else $breadcrumb .= $before . ''.get_the_title().'' . $after;
		}
		elseif ( is_singular() )
		{
			if( $category = wp_get_object_terms( get_the_ID(), array( 'category', 'location', 'tax_feature' ) ) )
			{

				if( !is_wp_error($category) )
				{
					$breadcrumb .= $before . '<a href="'.get_term_link( QSInspection_set($category, '0' ) ).'">'.QSInspection_set( QSInspection_set( $category, '0' ), 'name').'&nbsp;</a>' . $after;
					$breadcrumb .= $before . ''.get_the_title().'' . $after;
				} else {
					$breadcrumb .= $before . ''.get_the_title().'' . $after;
				}
			}else{
				$breadcrumb .= $before . ''.get_the_title().'' . $after;
			}

		}
		elseif(is_tag()) $breadcrumb .= $before . '<a href="'.get_term_link($queried_object).'">'.single_tag_title('', FALSE).'</a>' . $after; /**If tag template*/
		elseif(is_day()) $breadcrumb .= $before . '<a href="#">'.esc_html__('Archive for ', 'actavista').get_the_time('F jS, Y').'</a>' . $after; /** If daily Archives */
		elseif(is_month()) $breadcrumb .= $before . '<a href="' .get_month_link(get_the_time('Y'), get_the_time('m')) .'">'.__('Archive for ', 'actavista').get_the_time('F, Y').'</a>' . $after; /** If montly Archives */
		elseif(is_year()) $breadcrumb .= $before . '<a href="'.get_year_link(get_the_time('Y')).'">'.__('Archive for ', 'actavista').get_the_time('Y').'</a>' . $after; /** If year Archives */
		elseif(is_author()) $breadcrumb .= $before . '<a href="'. esc_url( get_author_posts_url( get_the_author_meta( "ID" ) ) ) .'">'.__('Archive for ', 'actavista').get_the_author().'</a>' . $after; /** If author Archives */
		elseif(is_search()) $breadcrumb .= $before . ''.esc_html__('Search Results for ', 'actavista').get_search_query().'' . $after; /** if search template */
		elseif(is_404())  {
			$breadcrumb .= $before . ''.esc_html__('404 - Not Found', 'actavista').'' . $after; /** if search template */
		}  
		elseif ( is_post_type_archive('product') ) 
		{
			
			$shop_page_id = wc_get_page_id( 'shop' );
			if( get_option('page_on_front') !== $shop_page_id  )
			{
				$shop_page    = get_post( $shop_page_id );
				
				$_name = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
				
				if ( ! $_name ) {
					$product_post_type = get_post_type_object( 'product' );
					$_name = $product_post_type->labels->singular_name;
				}
				
				if ( is_search() ) {
					
					$breadcrumb .= $before . '<a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a>' . $delimiter . esc_html__( 'Search results for &ldquo;', 'actavista' ) . get_search_query() . '&rdquo;' . $after;
					
				} elseif ( is_paged() ) {
					
					$breadcrumb .= $before . '<a href="' . get_post_type_archive_link('product') . '">' . $_name . '</a>' . $after;
					
				} else {
					
					$breadcrumb .= $before . $_name . $after;
					
				}
			}
			
		}
		else 

			$breadcrumb .= $before . '<a href="'.get_permalink().'">'.get_the_title().'</a>' . $after; /** Default value */
		
	}

	return $breadcrumb;
}
/**
 * [texasTiresv_the_pagination description]
 *
 * @param  array   $args [description].
 * @param  integer $echo [description].
 * @return [type]        [description]
 * use <?php texasTiresv_the_pagination();?>
 */
function texasTiresv_the_pagination( $args = array(), $echo = 1 ) {

	global $wp_query;
	//printr($wp_query);
	$default = array('base' => str_replace(99999, '%#%', esc_url(get_pagenum_link(99999))), 'format' => '?paged=%#%', 'current' => max(1, get_query_var('paged')), 'total' => $wp_query->max_num_pages, 'next_text' =>__( '<i class="far fa-angle-right"></i>', 'actavista' ), 'prev_text' =>__( '<i class="far fa-angle-left"></i>', 'actavista' ), 'type' => 'list');

	$args = wp_parse_args($args, $default);

	$pagination = ''.str_replace('<ul class=\'page-numbers\'>', '<ul class="pagination justify-content-center">', paginate_links($args)).'';


	if (paginate_links(array_merge(array('type' => 'array'), $args))) {

		if ($echo) {

			echo '<nav aria-label="Page navigation example">'.wp_kses_post($pagination).'</nav>';

		}

		return $pagination;

	}
}

/**
 * [esperto_get_posts_array description]
 *
 * @param  string $title [description]
 * @param  array  $span     [description]
 
 call in vc 'value' => corsicana_get_posts_array( 'wpcf7_contact_form' ),
 */
function corsicana_get_posts_array($post_type) {
	$result = array();
	$args = array(
		'post_type' => $post_type,
		'post_status' => 'publish',
		'posts_per_page' => -1,
	);
	$posts = get_posts($args);

	if ($posts) {
		foreach ($posts as $post) {
			$result[] = array('value' => $post->ID, 'label' => $post->post_title);
		}
	}
	return $result;
}



//display vc autocomplete param type value
//call in vc  'values' => alispx_get_type_posts_data(),

//Post or product query

function alispx_get_type_posts_data($post_type = 'product')
{

  $posts = get_posts(array(
    'posts_per_page' => -1,
    'post_type'      => 'product',
	
  ));

  $result = array();
  foreach ($posts as $post)
  {
    $result[] = array(
      'value' => $post->ID,
      'label' => $post->post_title,
    );
  }
  return $result;
}


//Blog Post category  query

function agr_blogpost_category() {
	
$term_query =array( 
    'taxonomy' => 'service_category', // <-- Custom Taxonomy name..
    'orderby'  => 'name',
    'order'     => 'ASC',
    'child_of'   => 0,
    'parent' => 0,
    'fields'    => 'all',
    'hide_empty'  => false,
    );

$result = array();
  $categories= get_categories($term_query);
  
foreach ($categories as $post)
  {
    $result[] = array(
    'value' => $post->slug,
      'label' => $post->name,
    );
  } 
return $result;
 
 
}

//display post view

function gt_get_post_view() {
    $count = get_post_meta( get_the_ID(), 'post_views_count', true );
    return "$count views";
}
function gt_set_post_view() {
    $key = 'post_views_count';
    $post_id = get_the_ID();
    $count = (int) get_post_meta( $post_id, $key, true );
    $count++;
    update_post_meta( $post_id, $key, $count );
}
function gt_posts_column_views( $columns ) {
    $columns['post_views'] = 'Views';
    return $columns;
}
function gt_posts_custom_column_views( $column ) {
    if ( $column === 'post_views') {
        echo gt_get_post_view();
    }
}
add_filter( 'manage_posts_columns', 'gt_posts_column_views' );
add_action( 'manage_posts_custom_column', 'gt_posts_custom_column_views' );



//display Testimornial category


function testmornial_get_categories($arg = array('taxonomy' => 'testimornial_category', 'hide_empty' => FALSE, 'show_all' => true), $slug = FALSE, $vp = FALSE) {

        global $wp_taxonomies;

        $categories = get_categories($arg);
    
        $cats = array();

        if (is_wp_error($categories)) {
            return array('' => 'All');
        }

        if (Corsicana_set($arg, 'show_all') && $vp) {
            $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
        } elseif (Corsicana_set($arg, 'show_all')) {
            $cats['all'] = esc_html__('All Categories', 'lifeline2');
        }

        if (!Corsicana_set($categories, 'errors')) {
            foreach ($categories as $category) {
                if ($vp) {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[] = array('value' => $key, 'label' => $category->name);
                } else {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[$key] = $category->name;
                }
            }
        }

        return $cats;
    }

	//display Blog category


function blog_get_categories($arg = array('taxonomy' => 'testimornial_category', 'hide_empty' => FALSE, 'show_all' => true), $slug = FALSE, $vp = FALSE) {

        global $wp_taxonomies;

        $categories = get_categories($arg);
    
        $cats = array();

        if (is_wp_error($categories)) {
            return array('' => 'All');
        }

        if (Corsicana_set($arg, 'show_all') && $vp) {
            $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
        } elseif (Corsicana_set($arg, 'show_all')) {
            $cats['all'] = esc_html__('All Categories', 'lifeline2');
        }

        if (!Corsicana_set($categories, 'errors')) {
            foreach ($categories as $category) {
                if ($vp) {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[] = array('value' => $key, 'label' => $category->name);
                } else {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[$key] = $category->name;
                }
            }
        }

        return $cats;
    }
	

//display servie category


function carleones_get_categories($arg = array('taxonomy' => 'service_category', 'hide_empty' => FALSE, 'show_all' => true), $slug = FALSE, $vp = FALSE) {

        global $wp_taxonomies;

        $categories = get_categories($arg);
    
        $cats = array();

        if (is_wp_error($categories)) {
            return array('' => 'All');
        }

        if (Corsicana_set($arg, 'show_all') && $vp) {
            $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
        } elseif (Corsicana_set($arg, 'show_all')) {
            $cats['all'] = esc_html__('All Categories', 'lifeline2');
        }

        if (!Corsicana_set($categories, 'errors')) {
            foreach ($categories as $category) {
                if ($vp) {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[] = array('value' => $key, 'label' => $category->name);
                } else {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[$key] = $category->name;
                }
            }
        }

        return $cats;
    }


//woo product category

if (class_exists('WooCommerce') ){
function corsicana_get_productcategories($arg = array('taxonomy' => 'product_cat', 'hide_empty' => FALSE, 'show_all' => true), $slug = FALSE, $vp = FALSE) {

        global $wp_taxonomies;

        $categories = get_categories($arg);
    
        $cats = array();

        if (is_wp_error($categories)) {
            return array('' => 'All');
        }

        if (Corsicana_set($arg, 'show_all') && $vp) {
            $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
        } elseif (Corsicana_set($arg, 'show_all')) {
            $cats['all'] = esc_html__('All Categories', 'lifeline2');
        }

        if (!Corsicana_set($categories, 'errors')) {
            foreach ($categories as $category) {
                if ($vp) {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[] = array('value' => $key, 'label' => $category->name);
                } else {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[$key] = $category->name;
                }
            }
        }

        return $cats;
    }
  }
if (class_exists('WooCommerce') ){
  function QSInspection_get_categories($arg = FALSE, $slug = FALSE, $vp = FALSE) {
    global $wp_taxonomies;

    $terms = get_terms( array(
    'taxonomy' => 'product_cat',
    'hide_empty' => false,
) );



    $categories = get_categories($arg);
   
    $cats = array();

    if (is_wp_error($categories)) {
        return array('' => 'All');
    }

    if (Corsicana_set($arg, 'show_all') && $vp) {
        $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
    } elseif (Corsicana_set($arg, 'show_all')) {
        $cats['all'] = esc_html__('All Categories', 'lifeline2');
    }

    if (!Corsicana_set($categories, 'errors')) {
        foreach ($categories as $category) {
            if ($vp) {
                $key = ($slug) ? $category->slug : $category->term_id;
                $cats[] = array('value' => $key, 'label' => $category->name);
            } else {
                $key = ($slug) ? $category->slug : $category->term_id;
                $cats[$key] = $category->name;
            }
        }
    }

    return $cats;

   }
  }

 
  
 add_action( 'woocommerce_after_register_post_type', 'WC_test_gateway_plugin', 10, 0 ); 
    function WC_test_gateway_plugin(){
        //require_once get_theme_file_path() . '/inc/vc-shortcode/categories-wheels.php';
        //require_once get_theme_file_path() . '/inc/vc-shortcode/dually-product-slider.php';
      
	  
	  
	  
	  
	  
    }



