<?php

function texastirehero_slider($one, $two)
{

	$texastirsehero_slider = shortcode_atts([
		'heroslideiteam'        => ' ',
	
		
		

	], $one);

	ob_start();

	
	?>
	
	 <?php  $array = json_decode( urldecode( Corsicana_set( $texastirsehero_slider, 'heroslideiteam') ) );  ?>
    <?php if ($array) : ?>
	            <!-- hero-area -->
            <div class="active-hero-slider">

			
			<?php $counter=1;?>
			<?php foreach ( $array as $arr ) : ?>
			
                <div class="single-hero-slider" style="background-image: url('<?php echo wp_get_attachment_url(  Corsicana_set( $arr, 'bg_img' )) ?>');">

                    <a href="#about" class="mouse-icon"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/mouse.png" alt="mouse"></a>

                    <div class="hero-circle-shape">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/shape/hero-circle-shape.png" alt="shape">
                    </div>

                    <div class="hero-slider-indecator">
                        <span>0<?php echo $counter++?></span>
                        <span>  /  04</span>
                    </div>
                    
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-5 offset-xl-1 col-lg-6 col-md-8">
                                <div class="hero-content">
                                    <div class="hero-text">
                                        <h3><?php echo Corsicana_set( $arr, 'top_heading' ); ?></h3>
                                        <h1><?php echo Corsicana_set( $arr, 'sub_title' ); ?></h1>
                                        <p><?php echo Corsicana_set( $arr, 'descrip' ); ?></p>
                                        <div class="side-btn pt-50 pt-xs-20 white-hover">
                                            <a href="<?php echo Corsicana_set( $arr, 'btn_link' ); ?>"><?php echo Corsicana_set( $arr, 'btn_text' ); ?></a>
                                        </div>
                                    </div>
                                    <div class="hero-address pt-160 pt-xs-40">
                                        <ul>
                                            <li>
                                                <i class="far fa-phone"></i>
                                                <p><span>Phone line:</span><?php echo Corsicana_set( $arr, 'phone' ); ?></p>
                                            </li>
                                            <li>
                                                <i class="far fa-envelope-open"></i>
                                                <p><?php echo Corsicana_set( $arr, 'email' ); ?></p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

           <?php endforeach; ?>    
			   
			   
			   


            </div>

        </section>
        <!-- HERO-AREA END -->

    
  <?php endif; ?>
  
    <!-- HERO-AREA END -->

	
	
	<?php
	return ob_get_clean();
}
add_shortcode('texastirehero_slider', 'texastirehero_slider');

if (function_exists('vc_map')) {
	vc_map([
		'name'      => __('Hero Slider','kg1forged'),
		'base'      => 'texastirehero_slider',
		'icon' =>   get_template_directory_uri() . "/images/fevicon.png",
		'description'  => __('Hero Slider','kg1forged'),
		'category'    => 'KG1 Forged',
		'params'    => [
			
			
			 [
                'type'              => 'param_group',                       
                'value'             => '',
                'heading'           => esc_html__( 'Add Hero Slider Iteam', 'kg1forged' ),
                'param_name'        => 'heroslideiteam',
                'show_settings_on_create' => true,
                'params'            => [
					
                    [
					'param_name'      => 'bg_img',
					'type'          => 'attach_image',
					'heading'        =>__('Background Image','kg1forged'),
					],
					[
						'param_name'      => 'top_heading',
						'type'          => 'textfield',
						'heading'        =>__('Title','kg1forged'),
					],
					[
						'param_name'      => 'sub_title',
						'type'          => 'textfield',
						'heading'        =>__('Sub Title','kg1forged'),
					],
					[
						'param_name'      => 'descrip',
						'type'          => 'textarea',
						'heading'        =>__('Short Descriptions','kg1forged'),
					],
					[
						'param_name'      => 'btn_text',
						'type'          => 'textfield',
						'heading'        =>__('Button Text','kg1forged'),
					],
					[
						'param_name'      => 'btn_link',
						'type'          => 'textfield',
						'heading'        =>__('Button url','kg1forged'),
					],
					[
						'param_name'      => 'phone',
						'type'          => 'textfield',
						'heading'        =>__('Phone Number','kg1forged'),
					],
					[
						'param_name'      => 'email',
						'type'          => 'textfield',
						'heading'        =>__('Email Address','kg1forged'),
					],
					
					
                    
                    
					 
                ]

            ],

				

				
	            
				
					
				
			],



	]);
}





?>