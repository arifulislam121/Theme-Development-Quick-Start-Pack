<?php
function amepreciseshop_machcole($one, $two)
{

    $ameprecise_slider  = shortcode_atts([



       'product_id'        => ' ',
       'id'        => ' ',
       'chosestyle'        => ' ',
        

    ], $one);

    ob_start();
				 			

    ?>
 
<?php

		$product_id = explode( ',', American_set( $ameprecise_slider,'product_id'));
		
		
		//print_r ($product_id);

		$args = array(
					'post_type' => 'product', 
					'post_status' => 'publish',
					//'order' => American_set( $ameprecise_slider,'order'),
					//'posts_per_page' => American_set( $ameprecise_slider,'number'),
					'post__in'=>$product_id,
					
				/*	'tax_query'             => array(
						array(
							'taxonomy'      => 'product_cat',
							'field' => 'slug', //This is optional, as it defaults to 'term_id'
							'terms'         => $cat,
							'operator'      => 'IN' // Possible values are 'IN', 'NOT IN', 'AND'.
						),
						
					)
				*/		
				);
				$query = new WP_Query($args); 
				

		?>		

		
 <?php 
 
	$styles =American_set( $ameprecise_slider, 'chosestyle' ); 
	
 ?>		
		

<?php if('choise1'==$styles){?>		
		
       <!-- Meching Feature 1  -->
        <section class="meching-feature p-relative pb-120 pb-xs-80">

            <div class="shape-1"></div>
            <div class="shape-2"></div>

            <div class="container">			
			
				<?php if($query->have_posts()) : ?>		
					<?php $counter=1;?>
						<?php global  $woocommerce;  ?>
							<?php while ($query->have_posts()) : $query->the_post(); $meta = get_post_meta( get_the_ID(), 'product_tab', true ); global $product; ?>	
							
							   
								
					<?php endwhile; wp_reset_postdata(); ?> 
				<?php endif; ?>					
										
				
            </div>
        </section>
        <!-- Meching Feature 1 END -->


<?php }elseif('choise2'==$styles){?>

               <!-- Meching Feature 2  -->
        <section class="meching-feature feature-right p-relative  pb-120 pb-xs-80">
            <div class="shape-1"></div>
            <div class="shape-2"></div>
            <div class="container">			
			
				<?php if($query->have_posts()) : ?>		
					<?php $counter=1;?>
						<?php global  $woocommerce;  ?>
							<?php while ($query->have_posts()) : $query->the_post(); $meta = get_post_meta( get_the_ID(), 'product_tab', true ); global $product; ?>	
							
							  
								
						<?php endwhile; wp_reset_postdata(); ?> 
				<?php endif; ?>									
				
            </div>
        </section>
        <!-- Meching Feature 2 END -->

<?php }?>		
 
        
    <?php
    return ob_get_clean();
}
add_shortcode('machine_cole', 'amepreciseshop_machcole');

/**
 * Get all type posts
 *
 * @return void
 * @author alispx
 **/
function machine_get_type_posts_datas( $post_type = 'product' ) {

	$posts = get_posts( array(
		'posts_per_page' 	=> -1,
		'post_type'			=> $post_type,
	));

	$result = array();
	foreach ( $posts as $post )	{
		$result[] = array(
			'value' => $post->ID,
			'label' => $post->post_title,
		);
	}
	return $result;
}


add_action( 'vc_before_init', 'machine_post_finder_integrateWithVC' );

function machine_post_finder_integrateWithVC() {
   vc_map( array(
		'name'      => __('Machine Collection','american_precise'),
        'base'      => 'machine_cole',
		'class' 				=> 'machine-product',
		'icon' =>   get_template_directory_uri() . "/images/fevicon.png",
		'category' 				=> esc_html__( 'American Precise', 'alispx' ),
		'admin_enqueue_css' 	=> array( get_template_directory_uri . '/your-path/alispxvc.css' ),
		'description' 			=> esc_html__( 'Machine Collection Post Finder', 'american_precise' ),
		'params' 				=> array(
			array(
				'type' 			=> 'autocomplete',
				'class' 		=> '',
				'heading' 		=> esc_html__( 'Product Search', 'american_precise' ),
				'param_name' 	=> 'product_id',
				'settings'		=> array(
						'values' => machine_get_type_posts_datas(),
						'multiple'       => true,
						'min_length'     => 1, //keyword search length
						//'auto_focus'     => true,
						//'unique_values'  => true,
						//'display_inline' => true,
					),
			),
			array(
				'type'              => 'dropdown',
				'class'             => '',
				'heading'           => esc_html__( 'Choose Layout Style', 'american_precise'),
				'param_name'        => 'chosestyle',
				'value'             => [  
					esc_html__( 'Select Style', 'american_precise' ) => '',
					esc_html__( 'Style One', 'american_precise' ) => 'choise1' ,
					esc_html__( 'Style Two', 'american_precise' ) => 'choise2' 
				],
				'description'       => esc_html__( 'Select sorting order ascending or descending for events.', 'american_precise' ),
			)
		)
	) );
}






?>