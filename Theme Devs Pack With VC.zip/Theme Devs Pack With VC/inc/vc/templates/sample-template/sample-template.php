<?php
//This is description of template
return array(
	'name'             => esc_html__( 'Template Title', 'ciyashop' ),    // Template Title
	'template_category'=> esc_html__( 'Template Category', 'ciyashop' ), // Template Category
	// 'new'              => true,                                        // Enable to display New badge.
	'content'          => <<<CONTENT
Place your content here.
CONTENT
);