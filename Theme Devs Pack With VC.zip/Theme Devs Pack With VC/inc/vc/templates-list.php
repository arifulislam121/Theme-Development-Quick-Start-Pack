<?php
return array(

    'hero-slider',

 
	
    
	
	
);
