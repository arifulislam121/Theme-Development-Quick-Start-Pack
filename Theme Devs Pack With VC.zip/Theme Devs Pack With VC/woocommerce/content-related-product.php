<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
$options = get_option('tirepro');
$enable_whishlist = petrolyne_set($options,'enable_whishlist');
$enable_price = petrolyne_set($options,'enable_price');
$enable_size = petrolyne_set($options,'enable_size');
// Ensure visibility.
$enable_text = petrolyne_set($options,'enable_text');

$enable_rating = petrolyne_set($options,'enable_rating');

$shop_btn_chat = petrolyne_set($options,'shop_btn_chat');
$shop_chat_btn_link = petrolyne_set($options,'shop_chat_btn_link');

if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
$meta = get_post_meta( get_the_ID(), 'product_tab', true );


?>

 <div class="product-slide text-center relproimg">
		<span class="shape"></span>
		<span class="shape"></span>
		<span class="shape"></span>

		<a href="<?php the_permalink()?>"><img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id( get_the_ID() ) ); ?>" alt=""></a>

		<div class="shop-page-product">
			<h5>
			<?php $term_name =  wp_get_post_terms( get_the_ID(), 'product_cat' ); ?>
				<?php foreach ( $term_name as $term ) : ?>
						<span><?php echo petrolyne_set($term,'name');  ?></span>
					<?php endforeach; ?>	
				
				<a href="<?php the_permalink()?>"><?php the_title();  ?></a>
			</h5>
			<p>
				<?php
						$symbol=get_woocommerce_currency_symbol();
						$reprice=$product->get_regular_price();
						$saleprice=$product->get_sale_price();

					?>

				<?php if ($saleprice) : ?>
					<?php echo $symbol;?><?php echo $saleprice;?>
				<?php endif; ?>	
				<?php if ($reprice) : ?>
					<del>
					<?php echo $symbol;?><?php echo $reprice;?></del>
				<?php endif; ?>	
			</p>
		</div>
	</div>