<?php
/**
 * Single Product tabs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/tabs.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.8.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $product;

/**
 * Filter tabs and allow third parties to add their own.
 *
 * Each tab is an array containing title, callback and priority.
 *
 * @see woocommerce_default_product_tabs()
 */
$product_tabs = apply_filters( 'woocommerce_product_tabs', array() );

if ( ! empty( $product_tabs ) ) :  


$main_clas = $_SERVER['REQUEST_URI'];
                

if(false !== strpos($main_clas,'comment-page')) {

   $class = 'active'; 
}
else {
     $class = ''; 
}
?>


 <!-- SINGLE-SHOP TAB -->
<section class="single-shop-tab-area pt-120 pb-120 pt-xs-70 pb-xs-70 pt-md-90 pb-md-90">
	<div class="container px-4">
		<div class="row justify-content-center">
			  <div class="col-md-12">


				<div class="single-shop-links mb-60 mb-xs-30 mb-md-40">
				
				
					<?php $counter = 0; foreach ( $product_tabs as $key => $product_tab ) : ?>
						<?php 
						//if ( $class &&  $key == 'reviews' ){
							//$class = 'active';
						//} elseif(( $counter == 0 && $class == '' )){
							//$class = 'active';
						//}
						?>
						
						
							<div class="<?php echo  (  $counter == 0 )  ? 'active' : '';?> <?php echo esc_attr( $key ); ?>_tab single-shop-link " id="tab-title-<?php echo esc_attr( $key ); ?>" role="tab" aria-controls="tab-<?php echo esc_attr( $key ); ?>">
								
									<?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key ) ); ?>
							
							</div>
						<?php $counter++; endforeach; ?>
				
					</div>


			 <div class="single-shop-tabs">		
			<?php $counter = 0;  foreach ( $product_tabs as $key => $product_tab ) : ?>	

			
					<div class="<?php echo  ( $counter == 0 ) ? 'active' : '';?> single-shop-tab" id="tab-<?php echo esc_attr( $key ); ?>" role="tabpanel" aria-labelledby="tab-title-<?php echo esc_attr( $key ); ?>">
					 <?php    if( $key == 'reviews' ){   ?>
					
					<?php
						$rating_1 = $product->get_rating_count(1);
						$rating_2 = $product->get_rating_count(2);
						$rating_3 = $product->get_rating_count(3);
						$rating_4 = $product->get_rating_count(4);
						$rating_5 = $product->get_rating_count(5);
					?>
							

							<div style="flex-direction: row-reverse;" class="row gx-5">
                                   
                                    <div class="col-md-4">
                                        <div class="ratted-box">
                                            <div class="ratting-wrap mb-30">
                                                <div class="ratting-star">
                                                    <ul>
                                                       <?php if( ! empty($product->get_average_rating()) && $product->get_average_rating() > 0 ) {
															echo wc_get_rating_html($product->get_average_rating() );
														} ?>
                                                    </ul>
                                                </div>
                                                <span>(<?php echo $product->get_rating_count(); ?>)</span>
                                            </div>
                                            <div class="ratted-list">
											
                                                <ul>
                                                    <li>
                                                        <span>5 Stars</span>
                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo $rating_5; ?>%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                        <span><?php echo $rating_5; ?></span>
                                                    </li>
                                                    <li>
                                                        <span>4 Stars</span>
                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo $rating_4; ?>%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                        <span><?php echo $rating_4; ?></span>
                                                    </li>
                                                    <li>
                                                        <span>3 Stars</span>
                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo $rating_3; ?>%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                        <span><?php echo $rating_3; ?></span>
                                                    </li>
                                                    <li>
                                                        <span>2 Stars</span>
                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo $rating_2; ?>%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                        <span><?php echo $rating_2; ?></span>
                                                    </li>
                                                    <li>
                                                        <span>1 Stars</span>
                                                        <div class="progress">
                                                            <div class="progress-bar" role="progressbar"
                                                                style="width: <?php echo $rating_1; ?>%" aria-valuenow="75" aria-valuemin="0"
                                                                aria-valuemax="100"></div>
                                                        </div>
                                                        <span><?php echo $rating_1; ?></span>
                                                    </li>
                                                </ul>
												
												
                                            </div>
                                        </div>
                                    </div>
                                
                           
								

							<?php } ?>
									<?php
									
									if ( isset( $product_tab['callback'] ) ) {
										call_user_func( $product_tab['callback'], $key, $product_tab );
									}
									?>
									</div>
								</div>
							<?php $counter++; endforeach; ?>

							<?php do_action( 'woocommerce_product_after_tabs' ); ?>
					</div>


				</div>	
			</div>	
		</div>
</section>
<!-- SINGLE-SHOP TAB// -->

<?php endif; ?>

