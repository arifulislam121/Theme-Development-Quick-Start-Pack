
<script>
jQuery(document).ready(function(){
  
    //jQuery("input.test").append('<span class="shape"></span><span class="shape"></span><span class="shape"></span>');

});
</script>


<?php
/**
 * Display single product reviews (comments)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.3.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! comments_open() ) {
	return;
}
?>
<div class="col-md-7">

		<div class="review-items">
			<div class="section-content mb-30 mb-xs-20">
                           
                        
		<h4 class="woocommerce-Reviews-title">
			<?php
			$count = $product->get_review_count();
			if ( $count && wc_review_ratings_enabled() ) {
				/* translators: 1: reviews count 2: product name */
				$reviews_title = sprintf( esc_html( _n( '%1$s review for %2$s', '%1$s reviews for %2$s', $count, 'woocommerce' ) ), esc_html( $count ), '<span>' . get_the_title() . '</span>' );
				echo apply_filters( 'woocommerce_reviews_title', $reviews_title, $count, $product ); // WPCS: XSS ok.
			} else {
				esc_html_e( 'Reviews', 'woocommerce' );
			}
			?>
		</h4>
	</div>
					
			<?php if ( have_comments() ) : ?>
				
				 <div class="commentlist">
			
					<?php wp_list_comments( apply_filters( 'woocommerce_product_review_list_args', array( 'callback' => 'woocommerce_comments' ) ) ); ?>
				</div>
				

			<?php
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
				echo '<nav class="woocommerce-pagination">';
				paginate_comments_links(
					apply_filters(
						'woocommerce_comment_pagination_args',
						array(
							'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
							'next_text' => is_rtl() ? '&larr;' : '&rarr;',
							'type'      => 'list',
						)
					)
				);
				echo '</nav>';
			endif;
			?>
		<?php else : ?>
			<p class="woocommerce-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'woocommerce' ); ?></p>
		<?php endif; ?>
		
	</div>


<div class="clear"></div>
    
    
    <?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->id ) ) : ?>

               <div class="gray-form post-review-form text-center text-md-start review_form_wrapper">
                    <div id="review_form">
                      <!--- <h5>Leave a Review</h5> ---->                     
                            <?php
                                $class = is_user_logged_in() ? 'col-12 comment-boxx' : 'col-md-6';
                                $commenter = wp_get_current_commenter();

                                $comment_form = array(
                                   /* translators: %s is product title */
									'title_reply'         => have_comments() ? esc_html__( 'Add a review', 'woocommerce' ) : sprintf( esc_html__( 'Be the first to review &ldquo;%s&rdquo;', 'woocommerce' ), get_the_title() ),
									/* translators: %s is product title */
									'title_reply_to'      => esc_html__( 'Leave a Reply to %s', 'woocommerce' ),
									'title_reply_before'  => '<div id="reply-title" class="section-content mt-50 mt-xs-30 mt-md-40 mb-30 mb-xs-20 comment-reply-title">
											<h3>',
									'title_reply_after'   => '</h3></div>',
                                    'comment_notes_before' => '',
                                    'comment_notes_after'  => '',
                                    'fields'               => array(
                                        'author' => '<div class="col-md-6">' . '<div class="col-12">' .
                                                    '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" aria-required="true" placeholder="Full Name" /></p>',
                                        'email'  =>  
                                                    '<div class="col-12"><input placeholder="Email Address" id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" aria-required="true" /></div></div></div>',
                                    ),
                                    'label_submit'  => __( 'Post Review', 'woocommerce' ),
                                    'logged_in_as'  => '',
									'class_submit' => 'site-btn mt-10 test rebtn',
                                    'comment_field' => ''
                                );

                                if ( get_option( 'woocommerce_enable_review_rating' ) === 'yes' ) {
                                    $comment_form['comment_field'] = '<div class="ratting-wrap mb-20 ratreviw">
                                           <span>Your Rating</span><div class="ratting-star">
                                            <select name="rating" id="rating">
                                                <option value="">' . __( 'Rate&hellip;', 'woocommerce' ) . '</option>
                                                <option value="5">' . __( 'Perfect', 'woocommerce' ) . '</option>
                                                <option value="4">' . __( 'Good', 'woocommerce' ) . '</option>
                                                <option value="3">' . __( 'Average', 'woocommerce' ) . '</option>
                                                <option value="2">' . __( 'Not that bad', 'woocommerce' ) . '</option>
                                                <option value="1">' . __( 'Very Poor', 'woocommerce' ) . '</option>
                                            </select>
                                        </div></div>';
                                }

                                $comment_form['comment_field'] .= '<div class="row g-4 align-items-center"><p class="comment-form-comment"><div class="'.$class.'"><textarea id="comment" placeholder="Your Review..." name="comment" rows="4" aria-required="true"></textarea></div>';
                                comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form ) );
                            ?>
							
                        </div>
                </div>
            <?php else : ?>

                <p class="woocommerce-verification-required"><?php _e( 'Only logged in customers who have purchased this product may leave a review.', 'woocommerce' ); ?></p>

            <?php endif; ?>
           

	<div class="clear"></div>
</div>
	
	
	
	



	
</div>		
	
<!-----review section end tag ------>
	
