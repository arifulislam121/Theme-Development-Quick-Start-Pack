<?php
/**
 * Review Comments Template
 *
 * Closing li is left out on purpose!.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/review.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

 <div  <?php comment_class('review-item mb-30'); ?> id="li-comment-<?php comment_ID(); ?>">
	<div class="review-shape"></div>
 


	<div class="review-header">
		<div class="review-header-text">
			<h5> <?php echo $comment->comment_author; ?><span><?php $timestamp = strtotime( $comment->comment_date ); //Changing comment time to timestamp
                                            $date = date('F d, Y', $timestamp);
                                            echo $date;
                                            ?></span></h5>
		</div>
		
			<div id="custom_rating_star" class="ratting-star">
		
		
					<span style="width:<?php echo get_comment_meta( $comment->comment_ID, 'rating', true )*16; ?>px"></span>
				
			</div>
			
	</div>
	<p><?php echo $comment->comment_content; ?></p>
				
</div>				
				