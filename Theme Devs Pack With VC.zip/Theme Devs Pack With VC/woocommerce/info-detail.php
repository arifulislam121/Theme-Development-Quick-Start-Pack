<?php $meta = get_post_meta(get_the_ID(), 'product_tab', true); 
      $meta_list = Corsicana_set($meta, 'add_d_info');
      $side_img = Corsicana_set($meta, 'side_img');
      $add_included = Corsicana_set($meta, 'add_included'); 
      $add_benefits = Corsicana_set($meta, 'add_benefits');
      $add_specification = Corsicana_set($meta, 'add_specification');
      global $product;
?>
    <div class="single-shop-content mt-70 mt-xs-40 mt-md-50 ">
        <div class="single-shop-link mb-50 mb-xs-30 mb-md-40">
            <ul>
                <?php if (Corsicana_set($meta, 'addi_des_pro2')) : ?>
                    <li class="site-btn site-btn-alt active">Description</li>
                <?php endif; ?>
                <?php if ( $add_benefits ) : ?>
                    <li class="site-btn site-btn-alt">Benefits</li>
                <?php endif; ?>
                <?php if ( $add_specification ) : ?>
                    <li class="site-btn site-btn-alt">Specification</li>
                <?php endif; ?>
                <?php if ( $add_included ) : ?>
                    <li class="site-btn site-btn-alt">What’s included</li>
                <?php endif; ?>
                <li class="site-btn site-btn-alt">Reviews</li>
            </ul>
        </div>
    
    <div class="single-shop-tabs position-relative overflow-hidden">
        <?php $counter = ''; ?>
        <?php if (Corsicana_set($meta, 'addi_des_pro2')) : ?>
            <?php $counter = 'yes'; ?>
            <div class="single-shop-tab active">
                <div class="section-content mb-20">
                    <h4 class="text-uppercase">Description:</h4>
                    <p><?php echo Corsicana_set($meta, 'addi_des_pro'); ?></p>
                </div>
                <div class="row align-items-center g-lg-5 g-4 mb-40 mb-xs-30">
                    <div class="col-md-6">
                        <div class="section-content">
                            <p><?php echo Corsicana_set($meta, 'addi_des_pro2'); ?> </p>
                            <?php if ( $meta_list ) : ?>
                                <ul class="arrow-list mt-30 mt-xs-20">
                                    <?php foreach ( $meta_list as $list ) : ?>
                                        <li><?php echo Corsicana_set($list, 'add_info'); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="single-shop-img">
                            <img src="<?php echo Corsicana_set($side_img, 'url'); ?>" alt="">
                        </div>
                    </div>
                 
                    </div>
            </div>
        <?php endif; ?>
        <?php if ( $add_benefits ) : ?>
            <?php $counter = 'yes'; ?>
            <div class="single-shop-tab">
                <div class="section-content mb-40 mb-xs-30">
                    <h3 class="text-uppercase">Benefits:</h3>
                </div>

                <div class="row g-4 mb-60 mb-xs-40 mb-md-50">
                    <?php foreach ( $add_benefits as $benefit ) : ?>
                        <div class="col-12">
                            <div class="benefit-list section-content">
                                <h4 class="theme-color d-flex align-items-center">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/check-red.png" alt="">
                                     <span class="flex-1 ml-20"><?php echo Corsicana_set($benefit, 'add_benefit_title'); ?></span>
                                </h4>
                                <p><?php echo Corsicana_set($benefit, 'add_benefit_text'); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if ( $add_specification ) : ?>
            <?php $counter = 'yes'; ?>
            <div class="single-shop-tab">
                <div class="section-content mb-30">
                    <h3 class="text-uppercase">Specification:</h3>
                </div>

                <ul class="jik-jak-list mb-70 mb-xs-40 mb-md-50">
                    <?php foreach ( $add_specification as $specification ) : ?>
                    <li>
                        <div class="row">
                            <div class="col-md-4 col-5">
                                <h5><?php echo Corsicana_set($specification, 'add_spcification_label'); ?></h5>
                            </div>
                            <div class="col-md-8 col-7">
                                <h5><?php echo Corsicana_set($specification, 'add_benefit_info'); ?></h5>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if ( $add_included ) : ?>
            <?php $counter = 'yes'; ?>
            <div class="single-shop-tab">
                <div class="section-content mb-30">
                    <h3 class="text-uppercase">Whats Included:</h3>
                </div>

                <div class="shop-kit-slider-wrap mb-70 mb-xs-40 mb-md-50">
                    <div class="shop-kit-slider gx-3 gx-md-4">
                        <?php foreach ( $add_included as $included ) : ?>
                            <?php $img =  Corsicana_set($included, 'add_included_image'); ?>
                            <div class="shop-kit-slide">
                                <div class="shop-kit-img">
                                    <a href="javascript:void(0)"><img src="<?php echo Corsicana_set($img, 'url'); ?>" alt=""></a>
                                </div>
                                <div class="shop-kit-info">
                                    <h5 class="text-uppercase"><a href="javascript:void(0)"><?php echo Corsicana_set($included, 'add_included_title'); ?></a></h5>
                                </div>
                            </div>
                       <?php endforeach; ?>
                    </div>
                    
                    <div class="slider-nav black-slider-nav d-flex align-items-center justify-content-center mt-40 mt-xs-30"></div>
                </div>
             </div>
        <?php endif; ?>
                    
      
        <?php
            $rating_1 = $product->get_rating_count(1);
            $rating_2 = $product->get_rating_count(2);
            $rating_3 = $product->get_rating_count(3);
            $rating_4 = $product->get_rating_count(4);
            $rating_5 = $product->get_rating_count(5);
        ?>
        <div class="single-shop-tab <?php echo ($counter != 'yes') ? 'active' : ''; ?>">
            <div class="section-content mb-30">
                <h3 class="text-uppercase">Review:</h3>
            </div>
            <div class="row mb-40 mb-xs-30 g-4">
                <div class="col-md-4">
                    <div class="ratting-full-info">
                        <h1 class="retting-preview"><?php echo get_post_meta( get_the_ID(), '_wc_average_rating', true ); ?><span>/5</span></h1>
                        <div class="ratting-wrap">
                            <ul class="ratting-stfffar">
                                <?php if( ! empty($product->get_average_rating()) && $product->get_average_rating() > 0 ) {
                                    echo wc_get_rating_html($product->get_average_rating() );
                                } ?>
                            </ul>
                            <h5 class="text-uppercase">Based on <?php echo $product->get_rating_count(); ?>  Reviews</h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <ul class="ratting-progress-wrap">
                        <li>
                            <ul class="ratting-star">
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                            </ul>

                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $rating_5; ?>%"></div>
                            </div>

                            <h6><?php echo $rating_5; ?></h6>
                        </li>  
                        <li>
                            <ul class="ratting-star">
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                            </ul>

                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $rating_4; ?>%"></div>
                            </div>

                            <h6><?php echo $rating_4; ?></h6>
                        </li>  
                        <li>
                            <ul class="ratting-star">
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                            </ul>

                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $rating_3; ?>%"></div>
                            </div>

                            <h6><?php echo $rating_3; ?></h6>
                        </li>  
                        <li>
                            <ul class="ratting-star">
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                            </ul>

                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $rating_2; ?>%"></div>
                            </div>

                            <h6><?php echo $rating_2; ?></h6>
                        </li>  
                        <li>
                            <ul class="ratting-star">
                                <li class="ratted"><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                                <li class=""><i class="fas fa-star"></i></li>
                            </ul>

                            <div class="progress">
                                <div class="progress-bar" role="progressbar" style="width: <?php echo $rating_1; ?>%"></div>
                            </div>

                            <h6><?php echo $rating_1; ?></h6>
                        </li>  
                    </ul>
                </div>
            </div>
            
            
            


             <?php
               

                $args = array(
                   'status' => 'approve',
                   'type' => 'review',
                   'post_id' => get_the_id()
                );
              

                // The Query
                $comments_query = new WP_Comment_Query;
                $comments = $comments_query->query( $args );
                print_r(wp_list_comments( array( 'callback' => 'woocommerce_comments' ), $comments));exit;
     
                $count_comments = count($comments);
                $devided_coment = ( $count_comments > 2 ) ? $count_comments /2 : 0;
                $numpages = $comments_query->max_num_pages;
               $count = $comments_query->found_comments; 
               $max_num_pages = $comments_query->max_num_pages; 
               
            ?>

            <div class="row g-4 mb-70 mb-xs-40 mb-md-50">
                <?php
                // Comment Loop
                if ( $comments ) {
                   
                    foreach ( $comments as $comment ): ?>
                        <?php if ( $comment->comment_approved == '0' ) : ?>
                            <p class="meta waiting-approval-info">
                                <em><?php _e( 'Thanks, your review is awaiting approval', 'woocommerce' ); ?></em>
                            </p>
                        <?php else:  ?>    
                            <div class="col-12">
                                <div id="li-review-<?php echo $comment->comment_ID; ?>" class="round-ratted-bx section-content">
                           
                                    <div  class="star-rating">
                                        <span style="width:<?php echo get_comment_meta( $comment->comment_ID, 'rating', true )*22; ?>px"><span itemprop="ratingValue"><?php echo get_comment_meta( $comment->comment_ID, 'rating', true ); ?></span> <?php _e('out of 5', 'woocommerce'); ?></span>
                                    </div>        
                                                
                                   <h5 class="text-uppercase">by <?php echo $comment->comment_author; ?> 
                                        <span class="theme-color"> - <?php
                                            $timestamp = strtotime( $comment->comment_date ); //Changing comment time to timestamp
                                            $date = date('F d, Y', $timestamp);
                                            echo $date;
                                            ?>
                                        </span>
                                    </h5>
                                   <p><?php echo $comment->comment_content; ?></p>         
                                </div>
                            </div>
                        <?php endif;  ?>
                    <?php endforeach;
                  
                } 
             ?>
<?php if ($devided_coment > 1 ) : ?>
<nav class="mt-25 mt-xs-20">
                                    <ul class="pagination justify-content-center justify-content-md-end">
                                      <li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-left"></i></a></li>
                                      <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                                      <li class="page-item"><a class="page-link" href="#">4</a></li>
                                      <li class="page-item"><a class="page-link" href="#">5</a></li>
                                      <li class="page-item"><a class="page-link" href="#"><i class="fas fa-angle-right"></i></a></li>
                                    </ul>
                                  </nav>
                                  <?php endif; ?>
            </div>

            <?php if ( get_option( 'woocommerce_review_rating_verification_required' ) === 'no' || wc_customer_bought_product( '', get_current_user_id(), $product->id ) ) : ?>

                <div id="review_form_wrapper">
                    <div id="review_form">
                        <div class="section-content mb-30">
                            <h3 class="text-uppercase">Post Review:</h3>
                        </div>
                        <div class="shop-review-form gray-form text-center text-md-start">
                            <?php
                                $class = is_user_logged_in() ? 'col-12 comment-boxx' : 'col-md-6';
                                $commenter = wp_get_current_commenter();

                                $comment_form = array(
                                    'title_reply'          => '',
                                    'title_reply_to'       => __( 'Leave a Reply to %s', 'woocommerce' ),
                                    'comment_notes_before' => '',
                                    'comment_notes_after'  => '',
                                    'fields'               => array(
                                        'author' => '<div class="col-md-6">' . '<div class="col-12">' .
                                                    '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" aria-required="true" placeholder="Full Name" /></p>',
                                        'email'  =>  
                                                    '<div class="col-12"><input placeholder="Email Address" id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" aria-required="true" /></div></div></div>',
                                    ),
                                    'label_submit'  => __( 'Post Review', 'woocommerce' ),
                                    'logged_in_as'  => '',
                                    'comment_field' => ''
                                );

                                if ( get_option( 'woocommerce_enable_review_rating' ) === 'yes' ) {
                                    $comment_form['comment_field'] = '<div class="ratting-wrap d-inline-flex align-items-center mb-30 mb-xs-20">
                                            <p class="flex-1 mr-20 mb-0">Select Rating</p>
                                            <select name="rating" id="rating">
                                                <option value="">' . __( 'Rate&hellip;', 'woocommerce' ) . '</option>
                                                <option value="5">' . __( 'Perfect', 'woocommerce' ) . '</option>
                                                <option value="4">' . __( 'Good', 'woocommerce' ) . '</option>
                                                <option value="3">' . __( 'Average', 'woocommerce' ) . '</option>
                                                <option value="2">' . __( 'Not that bad', 'woocommerce' ) . '</option>
                                                <option value="1">' . __( 'Very Poor', 'woocommerce' ) . '</option>
                                            </select>
                                        </div>';
                                }

                                $comment_form['comment_field'] .= '<div class="row g-4 align-items-center"><p class="comment-form-comment"><div class="'.$class.'"><textarea id="comment" placeholder="Your Review..." name="comment" rows="4" aria-required="true"></textarea></div>';
                                comment_form( apply_filters( 'woocommerce_product_review_comment_form_args', $comment_form ) );
                            ?>
                        </div>
                    </div>
                </div>
            <?php else : ?>

                <p class="woocommerce-verification-required"><?php _e( 'Only logged in customers who have purchased this product may leave a review.', 'woocommerce' ); ?></p>

            <?php endif; ?>
        </div>
    </div>
</div>