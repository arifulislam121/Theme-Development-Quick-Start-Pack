 	<?php 
 
	$options = get_option('kg1forgedv2');
	
	
	//footer Useful LInk 
	$menutitle = Corsicana_set($options,'menutitle');
	$fmenulink = Corsicana_set($options,'fmenulink');
	
	//company info
	$comtitle = Corsicana_set($options,'comtitle');
	$comsdes = Corsicana_set($options,'comsdes');
	$comabtbtn = Corsicana_set($options,'abtbtn');
	
	
		//social
	$social_widget_title = Corsicana_set($options,'social_widget_title');



	
	//copyright content
	
	$foo_text = Corsicana_set($options,'foo_text');
	$subs_text = Corsicana_set($options,'subs_text');
	$subs_des = Corsicana_set($options,'subs_des');

	//FOOTER BACKGROUND
    $footerbg = Corsicana_set($options,'footer_top_bg');
    $footer_bottom_logo = Corsicana_set($options,'footer_bottom_logo');

?>
 
 <style type="text/css"> 
	
</style>
 
 
 
 
 
 <!-- FOOTER AREA -->
    <footer class="footer-area pt-120 pt-xs-70 pt-md-90" style="background-color: #00334A;">
        <img src="<?php echo esc_url($footerbg['url']);?>" alt="" class="absolute-img right-bottom">
        <div class="newsletter mb-60 mb-xs-40 mb-md-50">
            <div class="container">
                <div class="row g-4 align-items-center">
                    <div class="col-md-4">
                        <div class="section-content white-content">
                            <h5 class="m-0"><?php echo esc_html($subs_text);?></h5>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="newsletter-form">
                            <form action="#">
                                <div class="contact-input">
                                    <input type="email" placeholder="Email Address">
                                </div>
                                <button class="site-btn white-hover" type="submit">Subscribe Now</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="footer-content">
            <div class="container">
                <div class="row g-0">
                    <div class="col-md-4">
                        <div class="footer-item">
                            <div class="section-content white-content">
                                <h5><?php echo esc_html($comtitle);?></h5>
                                <p><?php echo esc_html($comsdes);?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="footer-item">
                            <div class="section-content white-content">
                                <h5><?php echo esc_html($menutitle);?></h5>
                                <ul class="arrow-list">
								
						<?php if (is_array($fmenulink) || is_object($fmenulink)){?>
						
						 <?php foreach ($fmenulink as $infoiem): ?>
							<?php if(!empty($infoiem)){?>
								
                                    <li><a href="<?php echo esc_url(Corsicana_set($infoiem,'titlelink'));?>"><?php echo esc_html(Corsicana_set($infoiem,'tiitlename'));?></a></li>
									
                            <?php }?>
						<?php endforeach; ?>
						
					<?php 	}?>          
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="footer-item">
                            <div class="section-content white-content">
                                <h5><?php echo esc_html($social_widget_title);?></h5>
                                <ul class="social-list">
								
								
								<?php $sociamedia=Corsicana_set($options,'sociamedia');?>
		
										<?php if (is_array($sociamedia) || is_object($sociamedia)){?>
										
										 <?php foreach ($sociamedia as $socilaitem): ?>
											<?php if(!empty($socilaitem)){?>
											
										<li>
											 <a href="<?php echo esc_url(Corsicana_set($socilaitem,'social_url'));?>"" target="_blank">
                                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/eagle.png" alt="" class="absolute-img">
                                            <i class="fab fa-<?php echo trim(str_replace('fa fa-','',esc_html(Corsicana_set($socilaitem,'social_icon')))); ?>"></i>
                                           <?php echo esc_html(Corsicana_set($socilaitem,'social_label'));?>
                                        </a>
										</li>
										
											<?php 	}?> 
										<?php endforeach; ?>
										
									<?php 	}?> 
								
					
										
										
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="copyright-wrap">
            <div class="container">
                <div class="row g-4 align-items-center">
                    <div class="col-md-8">
                        <div class="copyright text-center text-md-start">
                            <?php echo $foo_text; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="copyright-logo text-center text-md-end">
                            <a href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo esc_url($footer_bottom_logo['url']);?>" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- FOOTER AREA// -->



	<?php wp_footer(); ?> 

</body>

</html>