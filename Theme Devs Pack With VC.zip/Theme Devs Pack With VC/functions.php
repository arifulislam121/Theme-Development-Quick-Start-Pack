<?php


if ( ! defined( '_S_VERSION' ) ) {

	define( '_S_VERSION', '1.0.0' );
}


//remove unnecessary class id from wp nav menu


/*
	add_filter('nav_menu_item_id', 'clear_nav_menu_item_id', 10, 3);
	function clear_nav_menu_item_id($id, $item, $args) {
		return "";
	}

	add_filter('nav_menu_css_class', 'clear_nav_menu_item_class', 10, 3);
	function clear_nav_menu_item_class($classes, $item, $args) {
		return array();
	}
*/

//current menu active

add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);

function special_nav_class ($classes, $item) {
  if (in_array('current-menu-item', $classes) ){
    $classes[] = 'current ';
  }
  return $classes;
}


//============contact form7 submit button tag or style replace and customize function ===================//

/*
	//removing default submit tag//
	remove_action('wpcf7_init', 'wpcf7_add_form_tag_submit');

	//adding action with function which handles our button markup//
	add_action('wpcf7_init', 'twentysixteen_child_cf7_button');

	//adding out submit button tag//
	if (!function_exists('twentysixteen_child_cf7_button')) {
		function twentysixteen_child_cf7_button() {
		wpcf7_add_form_tag('submit', 'twentysixteen_child_cf7_button_handler');
		}
	}

	//out button markup inside handler//
	if (!function_exists('twentysixteen_child_cf7_button_handler')) {
		function twentysixteen_child_cf7_button_handler($tag) {
			$tag = new WPCF7_FormTag($tag);
			$class = wpcf7_form_controls_class($tag->type);
			$atts = array();
			$atts['class'] = $tag->get_class_option($class);
			$atts['class'] .= 'site-btn';
			$atts['id'] = $tag->get_id_option();
			$atts['tabindex'] = $tag->get_option('tabindex', 'int', true);
			$value = isset($tag->values[0]) ? $tag->values[0] : '';
			if (empty($value)) {
			$value = esc_html__('GET FREE QUOTE', 'twentysixteen');
			}
			$atts['type'] = 'submit';
			$atts = wpcf7_format_atts($atts);
			$html = sprintf('<button type="submit" class="site-btn">%s<i class="fal fa-angle-right"></i></button>',$value,$atts);
			return $html;
		}
	}

*/


//=== Remove auto p from Contact Form 7 shortcode output====//

/*
	add_filter('wpcf7_autop_or_not', 'wpcf7_autop_return_false');
	function wpcf7_autop_return_false() {
		return false;
	}
*



/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
add_theme_support( 'title-tag' );


/**
g
 */
require get_template_directory() . '/inc/custom-header.php';
require_once get_theme_file_path() . '/inc/framework-options.php';
//require_once get_theme_file_path() . '/inc/custom-metabox.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';
/**
 * tgm.
 */
require get_template_directory() . '/inc/tgm.php';
/**
 * include with functions.php below file
 */
require get_template_directory() . '/inc/include/after-setup.php';
require get_template_directory().  '/inc/include/widgets.php';
require get_template_directory().  '/inc/include/ACF-options.php';
require get_template_directory().  '/inc/include/frontent-scripts.php';
require get_template_directory().  '/inc/include/admin-scripts.php';
include_once get_template_directory() . '/inc/dotnotation.php';
include_once get_template_directory() . '/inc/blog-coment-customize-function.php';

//=========================Service Custom Post========================//

/*

	add_action( 'init', 'custom_post_type' );

	function custom_post_type() {
	 
	// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => _x( 'Services', 'Post Type General Name', 'twentytwenty' ),
			'singular_name'       => _x( 'Service', 'Post Type Singular Name', 'twentytwenty' ),
			'menu_name'           => __( 'Services', 'twentytwenty' ),
			'parent_item_colon'   => __( 'Parent Service', 'twentytwenty' ),
			'all_items'           => __( 'All Services', 'twentytwenty' ),
			'view_item'           => __( 'View Service', 'twentytwenty' ),
			'add_new_item'        => __( 'Add New Service', 'twentytwenty' ),
			'add_new'             => __( 'Add New', 'twentytwenty' ),
			'edit_item'           => __( 'Edit Service', 'twentytwenty' ),
			'update_item'         => __( 'Update Service', 'twentytwenty' ),
			'search_items'        => __( 'Search Service', 'twentytwenty' ),
			'not_found'           => __( 'Not Found', 'twentytwenty' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwenty' ),
		);
		 
	// Set other options for Custom Post Type
		 
		$args = array(
			'label'               => __( 'Services', 'twentytwenty' ),
			'labels'              => $labels,
			// Features this CPT supports in Post Editor
			'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt'),
			// You can associate this CPT with a taxonomy or custom taxonomy. 
			'taxonomies'          => array( 'service_category' ),
			// A hierarchical CPT is like Pages and can have//
			// Parent and child items. A non-hierarchical CPT
			//is like Posts.//
			
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'show_in_rest' => true,
	 
		);
		 
		// Registering your Custom Post Type
		register_post_type( 'dnm_services', $args );
	 
	}


	// ---------Create Service Custom Taxonomy----//


	add_action( 'init', 'create_topics_nonhierarchical_taxonomy', 0 );
	 
	function create_topics_nonhierarchical_taxonomy() {
	 
	// Labels part for the GUI
	 
	  $labels = array(
		'name' => _x( 'Services Category', 'taxonomy general name' ),
		'singular_name' => _x( 'Service Category', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Services Category' ),
		'popular_items' => __( 'Popular Services Category' ),
		'all_items' => __( 'All Services Category' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Services Category' ), 
		'update_item' => __( 'Update Services Category' ),
		'add_new_item' => __( 'Add New Services Category' ),
		'new_item_name' => __( 'New Services Category Name' ),
		'separate_items_with_commas' => __( 'Separate topics with commas' ),
		'add_or_remove_items' => __( 'Add or remove topics' ),
		'choose_from_most_used' => __( 'Choose from the most used topics' ),
		'menu_name' => __( 'Services Category' ),
	  ); 
	 
	// Now register the non-hierarchical taxonomy like tag
	 
	  register_taxonomy('service_category','dnm_services',array(
		'hierarchical' => false,
		'labels' => $labels,
		'show_ui' => true,
		'show_admin_column' => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var' => true,
		'rewrite' => array( 'slug' => 'service_category' ),
	  ));
	}

*/

//======================our works gallary =======================//

/*
	add_action( 'init', 'works_custom_post_type', 0 );
	
	function works_custom_post_type() {
	 
	// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => _x( 'Our Works', 'Post Type General Name', 'twentytwenty' ),
			'singular_name'       => _x( 'Works', 'Post Type Singular Name', 'twentytwenty' ),
			'menu_name'           => __( 'Works Gallery', 'twentytwenty' ),
			'parent_item_colon'   => __( 'Parent Works', 'twentytwenty' ),
			'all_items'           => __( 'All Works', 'twentytwenty' ),
			'view_item'           => __( 'View Works', 'twentytwenty' ),
			'add_new_item'        => __( 'Add New Works', 'twentytwenty' ),
			'add_new'             => __( 'Add New', 'twentytwenty' ),
			'edit_item'           => __( 'Edit Works', 'twentytwenty' ),
			'update_item'         => __( 'Update Works', 'twentytwenty' ),
			'search_items'        => __( 'Search Works', 'twentytwenty' ),
			'not_found'           => __( 'Not Found', 'twentytwenty' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwenty' ),
		);
		 
	// Set other options for Custom Post Type
		 
		$args = array(
			'label'               => __( 'Works', 'twentytwenty' ),
			'labels'              => $labels,
			// Features this CPT supports in Post Editor
			'supports'            => array( 'title','thumbnail', 'excerpt'),
			// You can associate this CPT with a taxonomy or custom taxonomy. 
			'taxonomies'          => array( 'works_category' ),
			// A hierarchical CPT is like Pages and can have//
			//Parent and child items. A non-hierarchical CPT//
			// is like Posts.//
		   
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'show_in_rest' => true,
	 
		);
		 
		// Registering your Custom Post Type
		register_post_type( 'our_works', $args );
	 
	}

	// ---------Create Works Gallery Custom Taxonomy//

	 
	function create_topics_worksgallery_taxonomy() {
	 
	// Labels part for the GUI
	 
	  $labels = array(
		'name' => _x( 'Works Category', 'taxonomy general name' ),
		'singular_name' => _x( 'Works Category', 'taxonomy singular name' ),
		'search_items' =>  __( 'Search Works Category' ),
		'popular_items' => __( 'Popular Works Category' ),
		'all_items' => __( 'All Works Category' ),
		'parent_item' => null,
		'parent_item_colon' => null,
		'edit_item' => __( 'Edit Works Category' ), 
		'update_item' => __( 'Update Works Category' ),
		'add_new_item' => __( 'Add New Works Category' ),
		'new_item_name' => __( 'New Works Category Name' ),
		'separate_items_with_commas' => __( 'Separate topics with commas' ),
		'add_or_remove_items' => __( 'Add or remove topics' ),
		'choose_from_most_used' => __( 'Choose from the most used topics' ),
		'menu_name' => __( 'Works Category' ),
	  ); 
	 
	// Now register the non-hierarchical taxonomy like tag
	 
	  register_taxonomy('works_category','our_works',array(
		'hierarchical' => false,
		'labels' => $labels,
		'show_ui' => true,
		'show_admin_column' => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var' => true,
		'rewrite' => array( 'slug' => 'works_category' ),
	  ));
	}

	add_action( 'init', 'create_topics_worksgallery_taxonomy', 0 );


*/


//==================Testimornial =================//


/*
	add_action( 'init', 'testi_custom_post_type', 0 );
	function testi_custom_post_type() {
	 
	// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => _x( 'Testimornial', 'Post Type General Name', 'a1overhead' ),
			'singular_name'       => _x( 'Testimornial', 'Post Type Singular Name', 'a1overhead' ),
			'menu_name'           => __( 'Testimornial', 'a1overhead' ),
			'parent_item_colon'   => __( 'Parent Testimornial', 'a1overhead' ),
			'all_items'           => __( 'All Testimornial', 'a1overhead' ),
			'view_item'           => __( 'View Testimornial', 'a1overhead' ),
			'add_new_item'        => __( 'Add New Testimornial', 'a1overhead' ),
			'add_new'             => __( 'Add New', 'a1overhead' ),
			'edit_item'           => __( 'Edit Testimornial', 'a1overhead' ),
			'update_item'         => __( 'Update Testimornial', 'a1overhead' ),
			'search_items'        => __( 'Search Testimornial', 'a1overhead' ),
			'not_found'           => __( 'Not Found', 'a1overhead' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'a1overhead' ),
		);
		 
	// Set other options for Custom Post Type
		 
		$args = array(
			'label'               => __( 'Testimornial', 'a1overhead' ),
			'labels'              => $labels,
			// Features this CPT supports in Post Editor
			'supports'            => array( 'title','thumbnail', 'editor'),
			// You can associate this CPT with a taxonomy or custom taxonomy. 
			'taxonomies'          => array( 'testimornial_category' ),
			// A hierarchical CPT is like Pages and can have
			// Parent and child items. A non-hierarchical CPT
			// is like Posts.
			// 
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'capability_type'     => 'post',
			'show_in_rest' => true,
	 
		);
		 
		// Registering your Custom Post Type
		register_post_type( 'testimornial', $args );
	 
	}

*/
	

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}


//==================Include VC Template Addon File==============================//

// Theme vc-shortcode
 require_once get_theme_file_path() . '/inc/vc-shortcode/hero-slider.php';
 
 

 


//--------------------END-------------------------------//

/*
 * Codestar Freamwork
 */

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	//require get_template_directory() . '/inc/woocommerce.php';
}


//require_once get_parent_theme_file_path('/inc/vc/vc-fallback-functions.php'); // Fallback for vc based functions.

// Extend VC.
require_once get_parent_theme_file_path('/inc/vc/vc-init-admin.php');
require_once get_parent_theme_file_path('/inc/vc/vc-init.php');


 function defaults_menu()
        {

            echo ' <ul>
	      <li><a href="' . home_url() . '" title="Home">Home</a></li>
	      </ul>';
        }



		
function qsinspectionget_page_as_list(){

	$args = wp_parse_args(array(
		'post_type'		=>'page',
		'post_per_page'	=>-1,
	));
	$posts = get_posts($args);

	$post_options = array(esc_html__('--select page--','stock-toolkit')=>'');
	if($posts){
		foreach ($posts as $post) {
			$post_options[$post ->post_title] = $post->ID;
		}
	}
	return $post_options;
}



/**
 * [Corsicana_set description]
 *
 * @param  array  $data [description]
 * @return [type]       [description]
 */
function Corsicana_set( $var, $key, $def = '' ) {
        //if( ! $var ) return false;

        if ( is_object( $var ) && isset( $var->$key ) ) return $var->$key;
        elseif( is_array( $var ) && isset( $var[$key] ) ) return $var[$key];
        elseif( $def ) return $def;
        else return false;
    }
function Corsicana_get_categories($arg = FALSE, $slug = FALSE, $vp = FALSE) {
    global $wp_taxonomies;

    $terms = get_terms( array(
    'taxonomy' => 'service_category',
    'hide_empty' => false,
) );


//print_r($terms); exit;
    $categories = get_categories($arg);
    $cats = array();

    if (is_wp_error($categories)) {
        return array('' => 'All');
    }

    if (Corsicana_set($arg, 'show_all') && $vp) {
        $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
    } elseif (Corsicana_set($arg, 'show_all')) {
        $cats['all'] = esc_html__('All Categories', 'lifeline2');
    }

    if (!Corsicana_set($categories, 'errors')) {
        foreach ($categories as $category) {
            if ($vp) {
                $key = ($slug) ? $category->slug : $category->term_id;
                $cats[] = array('value' => $key, 'label' => $category->name);
            } else {
                $key = ($slug) ? $category->slug : $category->term_id;
                $cats[$key] = $category->name;
            }
        }
    }

    return $cats;
}