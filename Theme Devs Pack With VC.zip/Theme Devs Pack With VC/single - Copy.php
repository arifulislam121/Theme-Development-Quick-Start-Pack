<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Petrolyne
 */

get_header();

$meta = get_post_meta(get_the_ID(), 'blog_tab', true);



?>

   <section class="blog-details-area pt-100">
        <div class="container">

			<?php while (have_posts()): the_post(); ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="blog-details-content mb-60">
                           <?php the_post_thumbnail( 'full' ); ?>


                            <h4><?php the_title(); ?></h4>
                            <div class="author-action">
                                <span><i class="fal fa-clock"></i> <?php echo get_the_date( 'd M, Y' ); ?></span>
                                <span><i class="fal fa-user"></i> <?php the_author(); ?></span>
                            </div>

                           <?php the_content(); ?>
                        </div>
                    </div>
                </div>
                <?php $meta = get_post_meta( get_the_id(), 'blog_tab', true ); 
                		$gallery = petrolyne_set($meta, 'post_gallery'); 
                		$gallery_ = explode(',', $gallery); 
               ?>
                <div class="row">
					<?php foreach ($gallery_ as $gal) :  ?>
                    	<div class="col-md-4">
                            <div class="blog-de-img">
                               <?php echo wp_get_attachment_image( $gal, 'full' ); ?>
                            </div>
                        </div>
	               <?php endforeach; ?>
                </div>

                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="blog-about-text">
                            <p><?php echo petrolyne_set($meta, 'testimonial_content'); ?></p>
                            <h4><?php echo petrolyne_set($meta, 'testimonial_author'); ?> <span><?php echo petrolyne_set($meta, 'testimonial_designation'); ?></span></h4>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="post-tag-wrapper">

                            <div class="tag-inner">
                                <strong><?php esc_html_e('Tags', 'petrolyne'); ?>:</strong>
                                <div class="tagg">
                                   <?php the_tags( '', ', ', '' ); ?>
                                </div>
                            </div>

                            <div class="tag-inner">
                                <strong><?php esc_html_e('Share', 'petrolyne'); ?> :</strong>
                                <?php echo petrolyne_social_share_output_without_color(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile;  ?>
                       
        </div>
    </section>

<?php

	$terms = get_the_terms( get_the_ID(), 'category' );
	$term_list = wp_list_pluck( $terms, 'slug' );
	$related_args = array(
		'post_type' => 'post',
		
		'posts_per_page' => 4,
		'post_status' => 'publish',
		'post__not_in' => array( get_the_ID() ),
		'orderby' => 'rand',
		'tax_query' => array(
			array(
				'taxonomy' => 'category',
				'field' => 'slug',
				'terms' => $term_list
			)
		)
	);
	$query  =  new WP_Query( $related_args );
?>

         <section class="blog-related-area">
                <div class="container">
                     <div class="row">
                         <div class="col-lg-12">
                             <div class="related-title">
                                 <h2>Related Blog</h2>
                             </div>
                         </div>
                     </div>

                     <div class="row">
						<?php if ($query->have_posts()): ?>
							<?php  while ($query->have_posts()): $query->the_post(); ?>
		                         <div class="col-lg-3 col-md-6">
		                             <div class="related-item">
		                                 <div class="related-thumb">
		                                    <?php the_post_thumbnail( ); ?>
		                                 </div>
		                                 <div class="related-text">
		                                    <div class="author-action">
		                                        <span><i class="fal fa-clock"></i> <?php echo get_the_date( 'd M, Y' ); ?>
		                                    </span>
		                                        <span><i class="fal fa-user"></i>  <?php the_author(); ?></span>
		                                    </div>
		                                     <h4><?php the_title(); ?></h4>
		                                     <p><?php echo wp_trim_words(get_the_content(), 15); ?></p>
		                                     <a href="<?php the_permalink(); ?>" class="site-btn">Read more</a>
		                                 </div>
		                             </div>
		                         </div>
                     		<?php endwhile; wp_reset_postdata(); ?>
						<?php endif; ?>
                         
                     </div>
                </div>
            </section>
            <section class="blog-form-area pb-100">
            	<div class="container">
	                <?php   if ( comments_open() || get_comments_number() ) :
	                comments_template();
	            endif; ?>
	        	</div>
            </section>
<?php get_footer();
