<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package QSInspection
 */

?>
<?php $meta = get_post_meta( get_the_ID(), 'services_tab', true ); ?>

 <div class="col-lg-3 col-md-4 col-6">
	<div class="company-slide">
		<span class="company-icon mb-30 mb-xs-20">
			<img src="<?php echo Corsicana_set(Corsicana_set( $meta,'icon_img'), 'url');  ?>" alt="">
		</span>
		<div class="section-content">
			<h4><a href="<?php the_permalink(); ?>"><?php the_title();  ?></a></h4>
			<p><?php echo wp_trim_words(get_the_content(),13,false)?></p>
			<a href="<?php the_permalink(); ?>" class="circle-icon"><i class="fas fa-angle-right"></i></a>
		</div>
	</div>
</div>
        <!-- BLOG-PAGE -->
        <section class="our-blog pt-120 pb-120 pt-xs-70 pb-xs-70 pt-md-90 pb-md-90">
            <div class="container">
                <div class="row gy-md-5 g-4">
				
				
				
				
                    <div class="col-md-6">
                        <div class="blog-item">
                            <div class="blog-img">
                                <img src="./assets/img/our-blog/1.jpg" alt="">
                            </div>
                            <div class="advice-slide text-center overflow-hidden position-relative">
                                <div class="section-content">
                                    <div class="advice-bx">
                                        <h5 class="title text-uppercase">April 5, 2021</h5>
                                        <h4 class="mt-10"><a href="<?php the_permalink(); ?>"><?php the_title();  ?></a></h4>
                                    </div>
                                    <h6 class="title text-uppercase">5k Views, 6 comments</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                
            
             
          
                
                </div>
                
                <div class="section-btn text-center pt-70 pt-xs-40 pt-md-50">
                    <a href="#" class="site-btn"><i class="fas fa-spinner"></i>load more</a>
                </div>
            </div>
        </section>
        <!-- BLOG-PAGE// -->