<?php
/**
 * Template part for displaying not results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package QSInspection
 */

?>
<?php $meta = get_post_meta( get_the_ID(), 'services_tab', true ); ?>

  <?php 	
$options = get_option('corsicana');

   //coming soon
	$des = Corsicana_set($options,'des');
	$nbgimahe = Corsicana_set($options,'nbgimahe');
	


?>

<style type="text/css"> 

#notfunct{margin-top:0px!important};
</style>

<!-- error-page -->
    <section id="notfunct" class="error-page page-title-area bg-attachment overflow-hidden pt-200 pb-120 pt-xs-70 pb-xs-70 pb-md-90 pt-md-90" style="background-image: url(<?php echo $nbgimahe['url']?>);">
        <div class="section-overlay absolute-bg"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <div class="section-content text-center white-content">
                        <h1>4<span class="primary-color">0</span>4</h1>
                        <h3><?php echo $des;?></h3>
                        <div class="float-input mt-50 mt-xs-30 mt-md-40">
						
						<form method="get" id="searchform" action="<?php echo home_url(); ?>/">
                               
                                <input type="text" value="<?php esc_attr_e( 'search keyword...', 'coesicana' ); ?>" name="s" id="s" onfocus="if (this.value == '<?php esc_attr_e( 'search keyword...', 'coesicana' ); ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php esc_attr_e( 'search keyword...', 'coesicana' ); ?>';}" />
								<button type="submit" class="icon icon-alt" value="<?php esc_attr_e( 'search', 'coesicana' ); ?>"><i class="fas fa-search"></i></button>
                            </form>
							
			
                        </div>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="site-btn site-btn-alt black-hover mt-20">Back Homepage</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- error-page// -->