

<?php $meta = get_post_meta( get_the_ID(), 'services_tab', true ); ?>
<?php $enable_whawepro = Corsicana_set($meta,'enable_whawepro'); ?>
<?php $enable_feaserctn = Corsicana_set($meta,'enable_feaserctn'); ?>
<?php $enable_requesform = Corsicana_set($meta,'enable_requesform'); ?>
<?php $enable_galctn = Corsicana_set($meta,'enable_galctn'); ?>


<!-- SERVICE FEATURE  -->
    <section class="service-feature p-relative mt-120 mb-120">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="section-title pt-70 pb-70">
                        <h2><?php the_title();?></h2>
                        <h6 class="mb-60 mb-xs-30"><?php echo Corsicana_set( $meta,'subtitle');  ?></h6>
                        <p><?php the_content();?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-right-thumb">
            <img src="<?php echo wp_get_attachment_url( get_post_thumbnail_id() ); ?>" alt="">
            <div class="sf-icon"><img src="<?php echo Corsicana_set(Corsicana_set( $meta,'icon_img'), 'url');  ?>" alt=""></div>
            <div class="ss-shape"></div>
        </div>
    </section>
	
	
<?php if( $enable_whawepro):?>	
	
    <section class="service-feature sf-section-2 p-relative mb-120">
        <div class="container">
            <div class="row align-items-center justify-content-end">
                <div class="col-md-6">
                    <div class="section-title pt-70 pb-70">
                        <h2><?php echo Corsicana_set( $meta,'whattitle1');  ?> <br> <?php echo Corsicana_set( $meta,'whattitle2');  ?></h2>

                        <ul class="checked-list mt-40 mt-xs-30">
						
						<?php $oferitem=Corsicana_set($meta,'oferitems');?>
		
								<?php if (is_array($oferitem) || is_object($oferitem)){?>
								
								 <?php foreach ($oferitem as $oftem): ?>
									<?php if(!empty($oftem)){?>
										<li><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/check.png" alt=""><?php echo Corsicana_set($oftem,'oftitle');?></li>
									<?php }?>
								<?php endforeach; ?>
								
							<?php 	}?>  
                            
							
                            
                        </ul>

                    </div>
                </div>
            </div>
        </div>
        <div class="service-right-thumb">
            <img src="<?php echo Corsicana_set(Corsicana_set( $meta,'what_featurimg'), 'url');  ?>" alt="">
            <div class="ss-shape"></div>
        </div>
    </section>
    <!-- SERVICE FEATURE end -->
	
<?php endif;?>	



