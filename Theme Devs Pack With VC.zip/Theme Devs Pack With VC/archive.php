<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package gonzainsu
 */

get_header();

$meta = get_post_meta( get_the_ID(), 'page_meta_opt', true );
$banner_enable = Corsicana_set($meta,'banner_enable');
$banner_img = Corsicana_set($meta,'banner_img');
$feature_img = Corsicana_set($meta,'feature_img');
$banner_title = Corsicana_set($meta,'banner_title');
$banner_text = Corsicana_set($meta,'banner_text');

?>




<!--======== PAGE TITLE ========-->
      <section class="page-title-area d-flex align-items-end" style="background-image: url('<?php echo get_template_directory_uri(); ?>/assets/img/page-title/bg.jpg');">
         <div class="container">
            <div class="row align-items-end">
               <div class="col-md-12">
                  <div class="section-content mb-50 mb-xs-80">
				  
				  <?php
				the_archive_title( '<h1 class="page-title">', '</h1>' );
				the_archive_description( '<p class="archive-description">', '</p>' );
				?>

                     <div class="breadcrumb mt-45 mt-xs-20">
                        <ul>
                           <li><a href="<?php echo esc_url(home_url('/')); ?>"><i class="fal fa-home-lg-alt"></i> Home</a></li>
                           <li><a href="#"><?php the_archive_title( '<h1 class="bredcumb-title">', '</h1>' ); ?></a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!--======== PAGE TITLE// ========-->

	  
	  
	        <!--======== BLOG AREA ========-->
      <section class="blog-area pt-120 pb-120 pt-md-80 pb-md-80 pt-xs-70 pb-xs-70">
         <div class="container">
            <div class="row gx-5">
               <div class="col-lg-8 col-md-7">

			   
			   
	<?php if ( have_posts() ) : ?>
		

			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
				get_template_part( 'template-parts/content', get_post_type() );

			endwhile;
			

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
                 





                  <div class="text-center text-md-start">
                     <div class="blog-pagination">
					 
					 <?php the_posts_navigation();?>
					 
                       
                     </div>
                  </div>

               </div>
			   
			<?php 
		$terms = get_the_terms( get_the_ID(), 'category' );
			$term_list = wp_list_pluck( $terms, 'slug' );
			$related_args = array(
				'post_type' => 'post',		
				'posts_per_page' => 4,
				'post_status' => 'publish',
				'post__not_in' => array( get_the_ID() ),
				'orderby' => 'rand',
				'tax_query' => array(
					array(
						'taxonomy' => 'category',
						'field' => 'slug',
						'terms' => $term_list
					)
				)
			);
			$query  =  new WP_Query( $related_args );
		?>		
			   	   
			   
               <div class="col-lg-4 col-md-5">
                  <div class="blog-sidebar mt-xs-70">
                    
					   <div class="recent-blog">
                        <h3 class="mb-40 position-relative">Recent News</h3>
	
			<?php if ($query->have_posts()): ?>
							<?php  while ($query->have_posts()): $query->the_post(); ?>			
                        <!-- single item  -->
                        <div class="blog-item mt-30">
                           <div class="blog-thumb position-relative mb-20">
                              <img class="w-100" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(),'full'));  ?>" alt="">
                              <span class="el-absolute bottom-left text-uppercase"><?php echo get_the_date(); ?></span>
                           </div>
                           <div class="blog-content">
                              <h5><a href="<?php the_permalink()?> "><?php the_title(); ?> </a></h5>
                              <div class="meta">
                                 <ul class="d-flex align-items-center">
                                    <li>By <?php the_author(); ?></li>
                                 </ul>
                              </div>
                           </div>
                        </div>

             <?php endwhile; wp_reset_postdata(); ?>
						<?php endif; ?>   
						
						
                     </div>
					 
					 
                     <div class="sidebar-categories">
                        <h3 class="mb-40 position-relative">Categories</h3>
                        <div class="categories-list">
						
						
						<?php
							  $categories = get_categories();
							  $i = 0;
							  foreach ($categories as $category) {
								$i++;
								echo ' <a href="' . get_category_link($category->term_id) . '">' . $category->name . '<span>' . $category->category_count . '</span></a>';
							  }
					    ?> 

                        </div>
                     </div>
					 
                  </div>
               </div>
			   
			   
			   
            </div>
         </div>
      </section>
      <!--======== BLOG AREA// ========-->
	  


<?php
get_footer();
