<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package a1overhead
 */

get_header();
?>


<?php $meta = get_post_meta( get_the_ID(), 'services_tab', true ); ?>
<?php $enable_serheader = Corsicana_set($meta,'enable_serheader'); ?>



<?php if ($enable_serheader){?>

 <!-- PAGE TITLE  -->
    <section class="page-title d-flex align-items-center p-relative bg-attachment"
        style="background-image: url(<?php echo Corsicana_set(Corsicana_set( $meta,'cusimg'), 'url');  ?>);">
        <!-- SHAPE  -->
        <div class="pt-shape">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <!-- SHAPE  end-->
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 text-center">
                    <div class="pt-text">
                        <h2><?php echo Corsicana_set( $meta,'custitle');  ?></h2>
                        <h4><?php echo Corsicana_set( $meta,'cusdes');  ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php }else{?>

 <!-- PAGE TITLE  -->
 
 <?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'single-post-thumbnail' ); ?>
    <section class="page-title d-flex align-items-center p-relative bg-attachment"
        style="background-image: url(<?php echo $image[0]; ?>);">
        <!-- SHAPE  -->
        <div class="pt-shape">
            <span></span>
            <span></span>
            <span></span>
        </div>
        <!-- SHAPE  end-->
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 text-center">
                    <div class="pt-text">
                        <h2><?php the_title()  ?></h2>
                        <h4> <?php the_excerpt(); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php }?>



	<main class="main">

		<?php
		while ( have_posts() ) :
			the_post();

		
			get_template_part( 'template-parts/content-service', 'service-page' );
			
		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php

get_footer();
