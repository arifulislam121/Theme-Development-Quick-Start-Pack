<?php

// Control core classes for avoid errors
if (class_exists('CSF')) {

    //
    // Set a unique slug-like ID
    $prefix = 'corleonev1';

    //
    // Create options
    CSF::createOptions($prefix, array(
        'menu_title' => 'CorleOne Options',
        'menu_slug'  => 'corleone-options',
    ));

    CSF::createSection($prefix, array(
        'title'     => 'General',
        'icon'      => 'fa fa-cog',
        'fields'    => array(
            
                         array(
                'type'    => 'heading',
                'content' => 'Primary Color',
            ),
            array(
                'id'          => 'primaycolor',
                'type'        => 'color',
                'title'       => 'Select Your Primary color',
                'default'      =>'#da1f26'
               
                
            ),
             array(
                'type'    => 'heading',
                'content' => 'Secondary Color',
            ),
            array(
                'id'          => 'secondarycolor',
                'type'        => 'color',
                'title'       => 'Select Your Secondary color',
                'default'      =>'#222222'
               
                
            ),
            array(
                'type'    => 'heading',
                'content' => 'Third Color',
            ),
            array(
                'id'          => 'thirdcolor',
                'type'        => 'color',
                'title'       => 'Select Your Third color',
                'default'      =>'#767676'
               
                
            ),
            
           


        )
    ));

    //
    // Create a section
    // 
    CSF::createSection( $prefix, array(
  'id'    => 'header',
  'title' => 'Header',
  'icon'  => 'fa fa-plus-circle',
) );

    CSF::createSection($prefix, array(
        'parent'      => 'header',
        'title'  => 'Header',
        'icon'    => 'fa fa-code',
        'fields' => array(
   
        array(
                'id'          => 'hedbg',
                'type'        => 'media',
                'title'       => 'Upload your Header Background Image',

            ),
            array(
                'id'          => 'sitelogo',
                'type'        => 'media',
                'title'       => 'Upload Logo',

            ),
			  array(
                'id'          => 'sitefavi',
                'type'        => 'media',
                'title'       => 'Upload Site Fevicon',

            ),  
			array(
                'id'        => 'contacttext',
                'type'      => 'text',
                'title'     => 'Contact Button Label',
				'default'  => 'Contact',
            ),
			array(
                'id'        => 'contacturl',
                'type'      => 'text',
                'title'     => 'Contact Button URL',
				'default'  => '#',
            ),
          

        )
    )
);

	


	// Menu Options
	
      CSF::createSection($prefix, array(
        'parent'      => 'header',
        'title'     => 'Main Menu',
        'icon'      => 'fa fa-cog',
        'fields'    => array(
          array(
                'id'          => 'menu_color',
                'type'        => 'color',
                'title'       => 'Menu color',
                'default'      =>'#ffffff'
               
                
            ),
          array(
                'id'          => 'menu_color_hover',
                'type'        => 'color',
                'title'       => 'Menu Hover color',
                'default'      =>'#EF0000'
               
                
            ),
          
             array(
                'id'          => 'sticky_menu',
                'type'        => 'switcher',
                'title'       => 'Sticky Menu',
                'description' => 'Turn on to enable a Sticky menu.'
                
            ),
              array(
                'id'          => 'get_a_qoute',
                'type'        => 'switcher',
                'title'       => 'Get A Qoute',
                'description' => 'Turn on to enable a Get a Qoute.'
                
            ),
               array(
                'id'          => 'menu_buttons',
                'type'        => 'text',
                'title'       => 'Get A Quote',
                'default'     => 'Get A Quote',
                'dependency' => array('get_a_qoute', '==', 'true'),
                
            ),
                array(
                'id'          => 'menu_buttons_url',
                'type'        => 'text',
                'title'       => 'URL',
                'dependency' => array('get_a_qoute', '==', 'true'),
                
            ),
                 array(
                'id'          => 'menu_buttons_text_color',
                'type'        => 'color',
                'default'     =>'#ffffff',
                'title'       => 'Button Text Color',
                'dependency' => array('get_a_qoute', '==', 'true'),
                
            ),
               array(
                  'id'        => 'menu_buttons_color',
                  'type'      => 'color_group',
                  'title'     => 'Button Background',
                  'options'   => array(
                    'color-1' => 'Color 1',
                    'color-2' => 'Color 2',
                    'color-3' => 'Color 3',
                  ),
                   'dependency' => array('get_a_qoute', '==', 'true'),
                
                ),
  
        )
    ));
	
	
    CSF::createSection($prefix, array(
        'title'     => 'Social',
        'icon'      => 'fa fa-share',
        'fields'    => array(
            array(
                'type'    => 'heading',
                'content' => 'Follow us',
                ),

               
                array(
                        'id'          => 'follow_us_fb',
                        'type'        => 'text',
                        'title'       => 'Facebook',
						'default'     =>'#'
                    ),
               
                 array(
                        'id'          => 'follow_us_twi',
                        'type'        => 'text',
                        'title'       => 'Twitter',
                       'default'     =>'#'
                        
                    ),
					
                
                

        )
    ));	
  
    CSF::createSection( $prefix, array(
  'id'    => 'footer',
  'title' => 'Footer',
  'icon'  => 'fa fa-plus-circle',
) );
     CSF::createSection($prefix, array(
        'title'  => 'Footer Top',
        'parent'      => 'footer',
        'icon'    => 'fa fa-picture-o',
        'fields' => array(
              array(
                'type'    => 'heading',
                'content' => 'Footer Background',
            ),
              array(
                  'id'    => 'footer_top_bg',
                  'type'  => 'media',
                  'title' => 'Background Image',
                 
                ),
				
				array(
						'type'    => 'heading',
						'content' => 'Company Info ',
					  ),
 
                   array(
					'id'          => 'comlogo',
					'type'        => 'media',
					'title'       => 'Add Your Company Logo',
					),
					 array(
					'id'          => 'comsdes',
					'type'        => 'textarea',
					'title'       => 'Write Your Company Short Descriptons',
					'default'     =>'In the world of luxury high-end forged wheels, Corleone Forged is transcending from one level to the next.'
					),

				   array(
						'type'    => 'heading',
						'content' => ' Contact Us',
					 ),
                   array(
					'id'          => 'fcaddress',
					'type'        => 'textarea',
					'title'       => 'Location Address',
					'default'     =>  '3604 Mansfield Hwy Fort Worth, TX 76119',
					),
					array(
					'id'          => 'fcemail',
					'type'        => 'text',
					'title'       => 'Email Address',
					'default'     =>  'Sales@CorleoneForged.com',
					),
					array(
					'id'          => 'fcphone',
					'type'        => 'text',
					'title'       => 'Phone Number',
					'default'     =>  '8 800 567.890.11',
					),
					array(
					  'id'        => 'opthour',
					  'type'      => 'group',
					  'title'     => 'Operation Hour',
					  'fields'    => array(
						array(
						  'id'    => 'optday',
						  'type'  => 'text',
						  'title' => 'Operation Days',
						),
						array(
						  'id'    => 'opttime',
						  'type'  => 'text',
						  'title' => 'Operation Time',
						),
						
					  ),
					),
					array(
						'type'    => 'heading',
						'content' => 'Footer Useful Links  ',
					  ),
					array(
						  'id'    => 'footer_ustoplab',
						  'type'  => 'text',
						  'title' => 'Top Label',
						  'default'     =>'Userful Links'
						 
						),
					array(
						'type'    => 'heading',
						'content' => 'Footer Product Tags Links  ',
					  ),
					array(
						  'id'    => 'footer_prtaglab',
						  'type'  => 'text',
						  'title' => 'Top Label',
						  'default'     =>'Product Tags'
						 
						),	

			
				
				
        )
    ));
    CSF::createSection($prefix, array(
        'title'  => 'Footer Bottom',
        'parent'      => 'footer',
        'icon'    => 'fa fa-picture-o',
        'fields' => array(
            
            array(
                'type'    => 'heading',
                'content' => 'Footer Bottom ',
            ),
            array(
                'id'          => 'foot_btom',
                'type'        => 'color',
                'title'       => 'Background',
                'default'     =>'#17171A'

            ),

            array(
                'id'          => 'foo_text',
                'type'        => 'wp_editor',
                'title'       => '@Copyright',
                'default'     =>'© Copyright 2020'

            ),
             
      


        )
    ));
}

// metabox

// Control core classes for avoid errors
if (class_exists('CSF')) {

    //
    // Set a unique slug-like ID
    $prefix = 'page_meta_opt';


    // Create a metabox
    CSF::createMetabox($prefix, array(
        'title'     => 'Page Settings',
        'post_type' => 'page',
        'context'   => 'side'
    ));

    //
    // Create a section
    CSF::createSection($prefix, array(
        'title'  => 'Header',
        'fields' => array(
            array(
                'id'    => 'header_enable',
                'type'  => 'switcher',
                'title' => 'Header Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),

        )
    ));

    //
    // Create a section
    CSF::createSection($prefix, array(
        'title'  => 'Footer',
        'fields' => array(

            // A textarea field
            array(
                'id'    => 'footer_enable',
                'type'  => 'switcher',
                'title' => 'Footer Enable/Disable',
                'default' => true,
                'text_on' => 'Enable',
                'text_off' => 'Disable',
                'text_width' => 100
            ),

        )
    ));

    // Create a metabox
    CSF::createMetabox('product_tab', array(
        'title'     => 'Additional Information',
        'post_type' => 'product',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section
    CSF::createSection('product_tab', array(
        'title'  => 'Additional Description',

        'fields' => array(
            array(
                'id'    => 'addi_img_1',
                'type'  => 'media',
                'title' => 'Left Image',

            ),

            array(
                'id'    => 'addi_img_2',
                'type'  => 'media',
                'title' => 'Right Image',

            ),
            array(
                'id'    => 'addi_des_1',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),
            array(
                'type'    => 'heading',
                'content' => 'Video Block',
            ),
            array(
                'id'    => 'addi_video_thumb',
                'type'  => 'media',
                'title' => 'Video Thumbnail',

            ),
            array(
                'id'    => 'addi_video',
                'type'  => 'text',
                'title' => 'Video Url',
            ),
            array(
                'id'    => 'addi_des_2',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),
            array(
                'type'    => 'heading',
                'content' => 'Left Image Block',
            ),
            array(
                'id'    => 'addi_left_img',
                'type'  => 'media',
                'title' => 'Left Image',

            ),
            array(
                'id'    => 'addi_left_img_right_des',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),

            array(
                'type'    => 'heading',
                'content' => 'Right Image Block',
            ),

            array(
                'id'    => 'addi_right_img',
                'type'  => 'media',
                'title' => 'Right Image',

            ),
            array(
                'id'    => 'addi_right_img_left_des',
                'type'  => 'wp_editor',
                'title' => 'Short Description',

            ),

        )
    ));

    CSF::createSection('product_tab', array(
        'title'  => 'Product Code',

        'fields' => array(
            array(
                'id'    => 'product_code',
                'type'  => 'text',
                'title' => 'Product Code',

            ),

        )
    ));

    CSF::createMetabox('services_tab', array(
        'title'     => 'Services Information',
        'post_type' => 'dnm_services',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section
    CSF::createSection('services_tab', array(
        'title'  => 'Services Image',

        'fields' => array(
            array(
                'id'    => 'ser_img',
                'type'  => 'media',
                'title' => 'Service Image',
            ),

           
        )
    ));
	
	CSF::createSection('services_tab', array(
        'title'  => 'Button',

        'fields' => array(
            
            array(
                'id'    => 'btn_text',
                'type'  => 'text',
                'title' => 'Button label',
            ),
			array(
                'id'    => 'btn_link',
                'type'  => 'text',
                'title' => 'Button Link',
            ),
        )
    ));
	CSF::createSection('services_tab', array(
        'title'  => 'Extra Setting',

        'fields' => array(
            
            array(
                'id'    => 'activecls',
                'type'  => 'switcher',
                'title' => 'Enable/Disable',
            ),
			
        )
    ));
	
	 CSF::createMetabox('works_gal_tab', array(
        'title'     => 'Works Gallery Information',
        'post_type' => 'our_works',
        'priority'    => 'high',
        'context'   => 'normal'

    ));

    // Create a section
    CSF::createSection('works_gal_tab', array(
        'title'  => 'Works Image',

        'fields' => array(
            array(
                'id'    => 'works_img',
                'type'  => 'media',
                'title' => 'Background Image',
            ),

           
        )
    ));
	// Create a section
    CSF::createSection('works_gal_tab', array(
        'title'  => 'Works Video',

        'fields' => array(
            array(
                'id'    => 'works_video',
                'type'  => 'text',
                'title' => 'Works Video URL',
            ),

           
        )
    ));
	
	CSF::createMetabox('blog_post_tab', array(
        'title'     => 'Post Extra setting',
        'post_type' => 'post',
        'priority'    => 'high',
        'context'   => 'normal'

    ));
	// Create a section
    CSF::createSection('blog_post_tab', array(
        'title'  => 'Background Image',

        'fields' => array(
            array(
                'id'    => 'bg_image',
                'type'  => 'media',
                'title' => 'Add Post Background Image',
            ),

           
        )
    ));
	// Create a section
    CSF::createSection('blog_post_tab', array(
        'title'  => 'Extra Settings',

        'fields' => array(
            array(
                'id'    => 'activeclass',
                'type'  => 'switcher',
                'title' => 'Enable /Disable Post Box Style',
            ),

           
        )
    ));
	
	
	
	
}