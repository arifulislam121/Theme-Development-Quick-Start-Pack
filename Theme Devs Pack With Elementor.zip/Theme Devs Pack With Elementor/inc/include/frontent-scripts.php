<?php


/**
 * Enqueue scripts and styles.
 */
function corleonev1scripts() {
   
 wp_enqueue_style('bootstrapmin-css',get_theme_file_uri('/assets/css/bootstrap.min.css'),array(),_S_VERSION);
   wp_enqueue_style('animate-css',get_theme_file_uri('/assets/css/animate.css'),array(),_S_VERSION);
   wp_enqueue_style('magnific-css',get_theme_file_uri('/assets/css/magnific-popup.css'),array(),_S_VERSION);
   wp_enqueue_style('fontawesome-css',get_theme_file_uri('/assets/css/fontawesome.min.css'),array(),_S_VERSION);
   wp_enqueue_style('slick-css',get_theme_file_uri('/assets/css/slick.css'),array(),_S_VERSION);
   wp_enqueue_style('spacing-css',get_theme_file_uri('/assets/css/spacing.css'),array(),_S_VERSION);
  wp_enqueue_style('main-style-css',get_theme_file_uri('/assets/css/style.css'),array(),_S_VERSION);
   
   wp_enqueue_style('responsive-css',get_theme_file_uri('/assets/css/responsive.css'),array(),_S_VERSION);

   
    
   	
	 
	//root Theme css
	
	wp_enqueue_style( 'texastirv1-stylesheet', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'qsinspection-style', 'rtl', 'replace' );

	//Wocommerce Custom Css
	
	//wp_enqueue_style('woocss',get_theme_file_uri('/woocommerce.css'),array(),_S_VERSION);

	//---------javascript file from here-------------------//
	
	wp_enqueue_script( 'bootstrap-js', get_theme_file_uri('/assets/js/bootstrap.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'slick-js', get_theme_file_uri('/assets/js/slick.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'magnific-popup-js', get_theme_file_uri('/assets/js/magnific-popup.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'scrollup-js', get_theme_file_uri('/assets/js/scrollup.min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'one-page-nav-js', get_theme_file_uri('/assets/js/one-page-nav-min.js'), array('jquery'), _S_VERSION, true );
	wp_enqueue_script( 'skrollr-js', get_theme_file_uri('/assets/js/skrollr.min.js'), array('jquery'), _S_VERSION, true );

	
	
	// CUSTOM Main JS
	
	wp_enqueue_script( 'main-js', get_theme_file_uri('/assets/js/main.js'), array('jquery'), _S_VERSION, true );

 
 wp_enqueue_script('jquery');
 


}
add_action( 'wp_enqueue_scripts', 'corleonev1scripts' );