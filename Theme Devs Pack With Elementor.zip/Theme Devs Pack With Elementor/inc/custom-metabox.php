<?php 


function texas_meta_box(){
	
	add_meta_box(
	'postbox_class',
	'Post Setting options ',
	'meta_box_er_output',
	'post',
	'normal'
	);
	
	
}

add_action('add_meta_boxes','texas_meta_box');



function meta_box_er_output($post){ ?>
	<label for="postcls">Add Your Post Box Style Class ( Example : flex-row-reverse )</label>
	<p><input class="widefat" id="postcls" type="text" name="poststlecls" placeholder="Post Box Style Class"
	value="<?php echo get_post_meta($post->ID,'poststlecls',true);?>"/></p>
	
	
<?php }





function Dtabase_a_pathabo($post_id){
	
	update_post_meta($post_id,'poststlecls',$_POST['poststlecls']);

}

add_action('save_post','Dtabase_a_pathabo');



?>