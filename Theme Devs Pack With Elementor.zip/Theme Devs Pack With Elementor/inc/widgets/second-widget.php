<?php

//Widgtes Name :Create Custom Widgets

namespace Elementor;

class Second_widget extends Widget_Base {
	
	//widgets Name
	public function get_name(){
		return "Second-Widget";
	}
	//widgets Title
	public function get_title(){
		return "Second Widget";
	}
	//widgets Icon
	public function get_icon() {
		return 'fa fa-code';
	}
	//widgets Category
	public function get_categories() {
		return [ 'second-category' ];
	}
	
	//widgets Controls
	
	protected function _register_controls() {

	//section one		
		$this->start_controls_section(
			'section_0ne',
			[
				'label' => __( 'Button Text', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'text',
			[
				'label' => __( 'Button Text', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'New Button', 'plugin-name' ),
			]
		);

		//section 0ne Style Tabs
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_one_style',
			[
				'label' => __( 'Section One Style', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->end_controls_section();
		
		//section Two
		$this->start_controls_section(
			'section_two',
			[
				'label' => __( 'Button Url', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'url',
			[
				'label' => __( 'URL to embed', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'input_type' => 'url',
				'placeholder' => __( 'https://your-link.com', 'plugin-name' ),
			]
		);

		$this->end_controls_section();
		
		//section Two Style Tabs
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_two_style',
			[
				'label' => __( 'Section Two Style', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->end_controls_section();
		


	}
	
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Second_widget );











































