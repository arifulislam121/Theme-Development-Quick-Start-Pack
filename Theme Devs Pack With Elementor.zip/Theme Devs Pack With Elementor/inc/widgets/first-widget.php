<?php

//Widgtes Name :Create Custom Widgets

namespace Elementor;

class First_widget extends Widget_Base {
	
	//widgets Name
	public function get_name(){
		return "First-Widget";
	}
	//widgets Title
	public function get_title(){
		return "First Widget";
	}
	//widgets Icon
	public function get_icon() {
		return 'fa fa-user';
	}
	//widgets Category
	public function get_categories() {
		return [ 'first-category' ];
	}
	
	//widgets Controls
	
	protected function _register_controls() {

	//section one		
		$this->start_controls_section(
			'section_0ne',
			[
				'label' => __( 'Button Text', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'text',
			[
				'label' => __( 'Button Text', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __( 'New Button', 'plugin-name' ),
			]
		);

		$this->end_controls_section();
		
		//section 0ne Style Tabs
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_one_style',
			[
				'label' => __( 'Section One Style', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_section();
		
		//section Two
		$this->start_controls_section(
			'section_two',
			[
				'label' => __( 'Button Url', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'url',
			[
				'label' => __( 'URL to embed', 'plugin-name' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'input_type' => 'url',
				'placeholder' => __( 'https://your-link.com', 'plugin-name' ),
			]
		);

		$this->end_controls_section();
		
		//section Two Style Tabs
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_two_style',
			[
				'label' => __( 'Section Two Style', 'plugin-name' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'plugin-domain' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .wrapper',
			]
		);

		
		$this->end_controls_section();


	}
	
	
}
Plugin::instance()->widgets_manager->register_widget_type( new First_widget );











































