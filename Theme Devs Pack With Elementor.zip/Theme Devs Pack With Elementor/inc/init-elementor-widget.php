<?php 

class ElementorCustomElement
{

	private static $instance = null;

	public static function get_instance()
	{
		if (!self::$instance)
			self::$instance = new self;
		return self::$instance;
	}

	public function init()
	{
		add_action('elementor/widgets/widgets_registered', array($this, 'widgets_registered'));
	}

	public function widgets_registered()
	{
 
      // We check if the Elementor plugin has been installed / activated.
		if (defined('ELEMENTOR_PATH') && class_exists('Elementor\Widget_Base')) {
 
         //widget Register Directory Files
		 
			require_once(get_theme_file_path().'/inc/widgets/first-widget.php' );
			require_once(get_theme_file_path().'/inc/widgets/second-widget.php' );
			require_once(get_theme_file_path().'/inc/widgets/slider-widget.php' );
			require_once(get_theme_file_path().'/inc/widgets/product-catgory-widget.php' );
			require_once(get_theme_file_path().'/inc/widgets/logo-carousel.php' );
			require_once(get_theme_file_path().'/inc/widgets/preview-card.php' );
			require_once(get_theme_file_path().'/inc/widgets/pricing-table.php' );
			require_once(get_theme_file_path().'/inc/widgets/product-carousel.php' );
			require_once(get_theme_file_path().'/inc/widgets/product-hover-card.php' );
			require_once(get_theme_file_path().'/inc/widgets/ajax-product-tabs.php' );
			

		}
	}
}

ElementorCustomElement::get_instance()->init();


//widgets Custom Category

function add_elementor_widget_categories( $elements_manager ) {

	$elements_manager->add_category(
		'first-category',
		[
			'title' => __( 'First Category', 'plugin-name' ),
			'icon' => 'fa fa-plug',
		]
	);
	$elements_manager->add_category(
		'second-category',
		[
			'title' => __( 'Second Category', 'plugin-name' ),
			'icon' => 'fa fa-plug',
		]
	);

}
add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );








?>