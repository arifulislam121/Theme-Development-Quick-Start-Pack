 
 
 
<?php 
 
	$options = get_option('corleonev1');
	
	
	//footer Useful LInk 
	$footer_ustoplab = QSInspection_set($options,'footer_ustoplab');
	$footer_prtaglab = QSInspection_set($options,'footer_prtaglab');
	
	//company info
	$comlogo = QSInspection_set($options,'comlogo');
	$comsdes = QSInspection_set($options,'comsdes');
	
	
	//social
	$follow_us_fb = QSInspection_set($options,'follow_us_fb');
	$follow_us_twi = QSInspection_set($options,'follow_us_twi');
	
    
	//contact info
	
	$fcaddress = QSInspection_set($options,'fcaddress');
	$fcemail = QSInspection_set($options,'fcemail');
	$fcphone = QSInspection_set($options,'fcphone');	
	$opthour = QSInspection_set($options,'opthour');
	
	
	
	//copyright content
	
	$foo_text = QSInspection_set($options,'foo_text');

	//FOOTER BACKGROUND
    $footerbg = QSInspection_set($options,'footer_top_bg');

?>
 
 <style type="text/css"> 
	
</style>
 
 
 <footer>
        <div class="footer-area bg-attachment" style="background-image: url(<?php echo $footerbg['url'];?>);">   
            <div class="container">
                <div class="footer-content pt-100 pb-70 pt-xs-70 pb-xs-40 pt-md-90 pb-md-60">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 mb-30">
                            <div class="footer-logo">
                                <a class="mb-30 d-block" href="<?php echo esc_url(home_url('/')); ?>"><img src="<?php echo $comlogo['url'];?>" alt="logo"></a>
                                <p><?php echo $comsdes;?></p>

                                <div class="social-links">
                                    <ul>
                                        <li><a href="<?php echo $follow_us_fb;?>"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="<?php echo $follow_us_twi;?>"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-6 mb-30">
                            <div class="footer-menu-wrap">
                                <h4 class="footer-item-title"><?php echo $footer_ustoplab;?></h4>
                                <div class="footer-menu">
                                   <?php wp_nav_menu(array(
									   'menu' => '', 
									   'items_wrap'=>'%3$s', 
									   'container' => false,
									   'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
									   'theme_location'    => "useful-menu"
									)); ?>
							
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 mb-30">
                            <div class="footer-tag-wrap">
                                <h4 class="footer-item-title"><?php echo $footer_prtaglab;?></h4>
                                <div class="footer-tag">

								<?php wp_nav_menu(array(
									   'menu' => '', 
									   'items_wrap'=>'%3$s', 
									   'container' => false,
									   'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
									   'theme_location'    => "product-tags"
									)); ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6 mb-30">
                            <div class="footer-tag-wrap">
                                <h4 class="footer-item-title">Contact Us</h4>
                                <div class="footer-contact mb-30">
                                    <ul>

                                        <li>
                                           <i class="fas fa-map-marker-alt"></i>
                                           <?php echo $fcaddress; ?>
                                        </li>
                                        
                                        <li>
                                           <i class="fas fa-envelope"></i>
                                           <?php echo $fcemail; ?>
                                        </li>

                                        <li class="footer-contact-phn">
                                           <i class="fas fa-phone"></i>
                                           <span>Phone:</span> <?php echo $fcphone; ?>
                                        </li>

                                    </ul>
                                </div>
                                <div class="footer-open-time">
                                    <h5>Operation Hours</h5>
                                    <ul>

								<?php	if (is_array($opthour) || is_object($opthour)){
									 foreach ($opthour as $opthours): ?>
							  
										<li>
                                           <span><?php echo $opthours['optday']; ?></span> <?php echo $opthours['opttime'];?>
                                        </li>
								<?php endforeach; }?>
                                        
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="copyright-area">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <div class="copyright-text">
                                <?php echo $foo_text; ?> <a href="<?php echo esc_url(home_url('/')); ?>">Corleone Forged</a> All Rights Reserved.
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="dnm-text text-end">
                                Customized by <a href="https://designnearme.com/">DesignNearMe.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>



    <!-- Popper.js first, then Bootstrap JS -->
    


    <!-- CUSTOM JS -->
    

	
<?php wp_footer(); ?> 		
</body>

</html>