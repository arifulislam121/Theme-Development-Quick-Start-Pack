<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <!-- Required meta tags -->
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- widgets Custom CSS -->

	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/widget.css" />	

	
	<!-- widgets Custom js -->

	
	<?php 	
		$options = get_option('corleonev1');

		$site_fevicon = QSInspection_set($options,'sitefavi');
	?>

<link rel="shortcut icon" type="image/x-icon" href="<?php echo $site_fevicon['url']?>">	
	
	
<?php wp_head(); ?> 
</head>

<?php 	
$options = get_option('corleonev1');

	$site_logo = QSInspection_set($options,'sitelogo');
	$site_fevicon = QSInspection_set($options,'sitefavi');
	$headerbg = QSInspection_set($options,'hedbg');
    
	//contact button
	$contacttext = QSInspection_set($options,'contacttext');
	$contacturl = QSInspection_set($options,'contacturl');
	
	
	//social
	$follow_us_fb = QSInspection_set($options,'follow_us_fb');
	$follow_us_twi = QSInspection_set($options,'follow_us_twi');
	
    
	//copyright content
	
	$foo_text = QSInspection_set($options,'foo_text');

    
    //theme color
    $primaycolor = QSInspection_set($options,'primaycolor');
    $secondarycolor = QSInspection_set($options,'secondarycolor');
     $thirdcolor = QSInspection_set($options,'thirdcolor');
    

    
    
   

?>	

<!--Theme Color Css---->

<style type="text/css"> 

:root {
	--theme-color:<?php echo $primaycolor; ?>;
	--text-color:  <?php echo $thirdcolor; ?>;
	--heading-color: <?php echo $secondarycolor; ?>;
	--black: #000000;
	--white: #ffffff;
	--hr-color: #cccccc;
}
.header-area.sticky {
	position: fixed;
	background-image: url(<?php echo $headerbg['url']?>);
	box-shadow: 0 5px 5px rgba(255,255,255,.03);
	padding: 10px 0;
	animation: slideInDown .5s ease;
	background-size: cover;
}
</style>



<body <?php body_class();?>>

    <div id="home"></div>
    <!-- PRELOADER -->
    <div class="preloader">
        <div class="spinner">
            <div class="rect1"></div>
            <div class="rect2"></div>
            <div class="rect3"></div>
            <div class="rect4"></div>
            <div class="rect5"></div>
          </div>
    </div>
    <!-- PRELOADER END -->

    <!-- HEADER-AREA -->
    <header>
        <div class="header-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <div class="logo">
                            <a href="<?php echo esc_url(home_url('/')); ?>">
                                <img src="<?php echo $site_logo['url']?>" alt="logo">
                            </a>
                        </div>

                        
                        <a href="" class="search-icon d-md-none"><i class="far fa-search"></i></a>

                        
                        <div class="resonsive-slide-overlay d-md-none"></div>

                        <div class="humberger-bar d-md-none">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>

                        <div class="resonsive-slide d-md-none">
                            <div class="responsive-menu">
                                <script type="text/javascript"> 
								
								 jQuery(document).ready(function(){
								  jQuery('#menu-mobile-menu li:first').addClass('current');
								});
						
							</script>
							
								<?php wp_nav_menu(array(
								   'menu' => '', 
								   'items_wrap'=>'%3$s', 
								   'container' => false,
								   'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
								   'theme_location'    => "mobile"
								)); ?>
                            </div>

                            <div class="responsive-others">
                                <div class="resposive-btns text-center">
                                    <a href="<?php echo $contacturl;?>" class="site-btn"><?php echo $contacttext;?></a>
                                </div>

                                <div class="copyright-text">
                                    <?php echo $foo_text; ?> <a href="<?php echo esc_url(home_url('/')); ?>">Corleone Forged</a> All Rights Reserved.
                                </div>
                                
                            </div>
                        </div>

                    </div>

                    <div class="col-md-8">
                        <div class="mainmenu d-none d-md-block">
                            <script type="text/javascript"> 
								
									 jQuery(document).ready(function(){
									  jQuery('#menu-main-menu li:first').addClass('current');
									});
							
								</script>
								
								<?php wp_nav_menu(array(
								   'menu' => '', 
								   'items_wrap'=>'%3$s', 
								   'container' => false,
								   'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
								   'theme_location'    => "main-menu"
								)); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- HEADER-AREA END -->