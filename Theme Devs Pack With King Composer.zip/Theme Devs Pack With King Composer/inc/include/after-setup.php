<?php
if ( ! function_exists( 'texastiresetup' ) ) :

	function texastiresetup() {

		load_theme_textdomain( 'texastire', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		add_theme_support( 'title-tag' );

        add_theme_support( 'woocommerce' );
		add_theme_support( 'post-thumbnails' );


		// This theme uses wp_nav_menu() in one location.
		register_nav_menus(
			array(
				'main-menu' => esc_html__( 'Main Menu', 'texastire' ),
				'useful-menu' => esc_html__( 'Useful Link Menu', 'texastire' ),
				'mobile' => esc_html__( 'Mobile', 'texastire' ),
				'product-tags' => esc_html__( 'Product Tags', 'texastire' ),
			)

		);


		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
			)
		);

		// Set up the WordPress core custom background feature.
		add_theme_support(
			'custom-background',
			apply_filters(
				'qsinspectioncustom_background_args',
				array(
					'default-color' => 'ffffff',
					'default-image' => '',
				)
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );


		add_theme_support(
			'custom-logo',
			array(
				'height'      => 250,
				'width'       => 250,
				'flex-width'  => true,
				'flex-height' => true,
			)
		);
	}
endif;
add_action( 'after_setup_theme', 'texastiresetup' );

function qsinspectioncontent_width() {

	$GLOBALS['content_width'] = apply_filters( 'qsinspectioncontent_width', 640 );
}
add_action( 'after_setup_theme', 'qsinspectioncontent_width', 0 );