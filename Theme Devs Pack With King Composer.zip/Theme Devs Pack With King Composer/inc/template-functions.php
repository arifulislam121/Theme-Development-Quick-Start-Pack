<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package QSInspection
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function qsinspectionbody_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'qsinspectionbody_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function qsinspectionpingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'qsinspectionpingback_header' );



/**
 * [esperto_get_posts_array description]
 *
 * @param  string $title [description]
 * @param  array  $span     [description]
 
 call in vc 'value' => qsinspection_get_posts_array( 'wpcf7_contact_form' ),
 */
function qsinspection_get_posts_array($post_type) {
	$result = array();
	$args = array(
		'post_type' => $post_type,
		'post_status' => 'publish',
		'posts_per_page' => -1,
	);
	$posts = get_posts($args);

	if ($posts) {
		foreach ($posts as $post) {
			$result[] = array('value' => $post->ID, 'label' => $post->post_title);
		}
	}
	return $result;
}



//display vc autocomplete param type value
//call in vc  'values' => alispx_get_type_posts_data(),

//Post or product query

function alispx_get_type_posts_data($post_type = 'product')
{

  $posts = get_posts(array(
    'posts_per_page' => -1,
    'post_type'      => 'product',
  ));

  $result = array();
  foreach ($posts as $post)
  {
    $result[] = array(
      'value' => $post->ID,
      'label' => $post->post_title,
    );
  }
  return $result;
}


//Blog Post category  query

function agr_blogpost_category() {
	
$term_query = new WP_Term_Query( array( 
    'taxonomy' => 'category', // <-- Custom Taxonomy name..
    'orderby'  => 'name',
    'order'     => 'ASC',
    'child_of'   => 0,
    'parent' => 0,
    'fields'    => 'all',
    'hide_empty'  => false,
    ) );

$result = array();
  $categories= get_categories($term_query);
  
foreach ($categories as $post)
  {
    $result[] = array(
    'value' => $post->slug,
      'label' => $post->name,
    );
  } 
return $result;
 
 
}

if (class_exists('WooCommerce') ){
function carleone_get_categories($arg = array('taxonomy' => 'product_cat', 'hide_empty' => FALSE, 'show_all' => true), $slug = FALSE, $vp = FALSE) {

        global $wp_taxonomies;

        $categories = get_categories($arg);
    
        $cats = array();

        if (is_wp_error($categories)) {
            return array('' => 'All');
        }

        if (QSInspection_set($arg, 'show_all') && $vp) {
            $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
        } elseif (QSInspection_set($arg, 'show_all')) {
            $cats['all'] = esc_html__('All Categories', 'lifeline2');
        }

        if (!QSInspection_set($categories, 'errors')) {
            foreach ($categories as $category) {
                if ($vp) {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[] = array('value' => $key, 'label' => $category->name);
                } else {
                    $key = ($slug) ? $category->slug : $category->term_id;
                    $cats[$key] = $category->name;
                }
            }
        }

        return $cats;
    }
  }
if (class_exists('WooCommerce') ){
  function QSInspection_get_categoriess($arg = FALSE, $slug = FALSE, $vp = FALSE) {
    global $wp_taxonomies;

    $terms = get_terms( array(
    'taxonomy' => 'service_category',
    'hide_empty' => false,
) );



    $categories = get_categories($arg);
   
    $cats = array();

    if (is_wp_error($categories)) {
        return array('' => 'All');
    }

    if (QSInspection_set($arg, 'show_all') && $vp) {
        $cats[] = array('value' => 'all', 'label' => esc_html__('All Categories', 'lifeline2'));
    } elseif (QSInspection_set($arg, 'show_all')) {
        $cats['all'] = esc_html__('All Categories', 'lifeline2');
    }

    if (!QSInspection_set($categories, 'errors')) {
        foreach ($categories as $category) {
            if ($vp) {
                $key = ($slug) ? $category->slug : $category->term_id;
                $cats[] = array('value' => $key, 'label' => $category->name);
            } else {
                $key = ($slug) ? $category->slug : $category->term_id;
                $cats[$key] = $category->name;
            }
        }
    }

    return $cats;

   }
  }

 add_action( 'woocommerce_after_register_post_type', 'WC_test_gateway_plugin', 10, 0 ); 
    function WC_test_gateway_plugin(){
        //require_once get_theme_file_path() . '/inc/vc-shortcode/categories-wheels.php';
        //require_once get_theme_file_path() . '/inc/vc-shortcode/dually-product-slider.php';
        //require_once get_theme_file_path() . '/inc/vc-shortcode/standard-product-slider.php';
        //require_once get_theme_file_path() . '/inc/vc-shortcode/concave-product-slider.php';
        //require_once get_theme_file_path() . '/inc/vc-shortcode/monoblock-product-slider.php';
    }


