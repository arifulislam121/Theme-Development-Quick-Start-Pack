<?php

function corleonofroad_slider($atts, $content)
{

	$corleofroad_slider = shortcode_atts([
		'name'        => ' ',
		'des'        => ' ',
		'customclass'        => ' ',
		'custom_prostyle'        => ' ',
		'text_limit'        => ' ',
        'number'        => ' ',
        'order'        => ' ',
        'cat'        => ' ',
		

		

	], $atts);

	//creating variable
	extract($corleofroad_slider);
	
	ob_start();

	//extra class add when access kc default css (custom style css)
	
	$wrap_class=apply_filters( 'kc-el-class', $atts );
	$wrap_class[]=$custom_prostyle;
	$extra_class=implode(' ',$wrap_class);
	
	
    $cat = explode(',',  QSInspection_set( $corleofroad_slider,'cat'));
	
	
    $args = array(
        'post_type' => 'product',
        'order' => QSInspection_set( $corleofroad_slider,'order'),
        'posts_per_page' => QSInspection_set( $corleofroad_slider,'number'),
       
    );
	
	
	if (!($cat) && QSInspection_set($cat, 0) == 'all') {
        array_shift($cat);
    }

    if (!empty($cat) && QSInspection_set($cat, 0) != '')
        $args['tax_query'] = array(array('taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => (array) $cat));
	


    $query = new WP_Query($args);
  
	
	?>
	

 <?php if($query->have_posts()) : ?>
 
     <!-- PRODUCT-AREA -->
        <section id="wheel" class="product-area overflow-hidden pt-120 pb-120 pt-xs-70 pb-xs-70 pt-md-90 pb-md-90" style="background-image: url(./assets/img/product/product-bg.png);" style="background-image: url(./assets/img/about/about-bg.jpg);">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-title text-center mb-10">
                            <h3 data-bottom-top="transform: translate(-200px, 0px); opacity: 0;" data-center-top="transform: translate(0, 0); opacity: 1;"><?php echo QSInspection_set( $corleofroad_slider, 'name' ); ?></h3>
                            <p data-bottom-top="transform: translate(200px, 0px); opacity: 0;" data-center-top="transform: translate(0, 0); opacity: 1;"><?php echo QSInspection_set( $corleofroad_slider, 'des' ); ?></p>
                        </div>
                    </div>
                </div>
                
				
                <div class="product-active-slider" data-bottom-top="transform: translate(0px, 200px); opacity: 0;" data-center-top="transform: translate(0, 0); opacity: 1;">

				
	<?php while($query->have_posts()) : $query->the_post(); ?>
				
                    <div class="single-product-slider">
                        <div class="product-img-wrapper mb-20">
                            <div class="product-img bg-attachment" style="background-image: url(<?php echo wp_get_attachment_url( get_post_thumbnail_id() ); ?>);"></div>
                        </div>
    
                        <div class="product-info text-center">
                            <h4><a href=""><?php the_title(); ?></a></h4>
                            <p>ABRAMO | OF-3964</p>
                        </div>
                    </div>
					
      <?php endwhile; wp_reset_postdata(); ?> 
	  

                </div>
            </div>
        </section>
		

<?php endif; ?>			
        <!-- PRODUCT-AREA END -->

 


	
	
	<?php
	return ob_get_clean();
}
add_shortcode('off_roadpr_slider', 'corleonofroad_slider');


add_action('init','offroad_slider_section');

if(!function_exists('offroad_slider_section')){

function offroad_slider_section(){

if (function_exists('kc_add_map')) {
		kc_add_map([
			'off_roadpr_slider' => array(
                'name' => esc_html__('OFF Road Product Slider','corleone'),
                'description' => 'OFF Road Product Slider shortcode',
                'icon' => 'fa fa-code',
                'category' => 'CorleOne',
                'params' => array(
                    'content'=>array(
						
						//4th field
						array(
							'name' => 'name',
							'label' => esc_html__('Top Title','corleone'),
							'type' => 'text',  // USAGE TEXT TYPE
							'value' => 'I am King Composer Title', // remove this if you do not need a default content
							'description' => 'Section Title',
						),
						//5th field
						array(
							'name' => 'des',
							'label' => esc_html__('Section Description','corleone'),
							'type' => 'textarea',  // USAGE TEXT TYPE
							'value' => 'I am King Composer Description', // remove this if you do not need a default content
							'description' => 'Section Description',
						),
						 array(
								'name'        	=> 'order',
								'label'       	=> esc_html__('Order','ThemeName'),
								'description' 	=> esc_html__('Sort posts. ','ThemeName'),
								'type'        	=> 'select',
								'options' 		=> array( 
									'ASC' 		=> 'ASC ( Lowest to highest )',
									'DESC' 		=> 'DESC ( Highest to lowest )',
								), 
								'value' 		=> 'DESC'
							),
						array(
								'name' 			=> 'number',
								'label' 		=> esc_html__( 'Post Count', 'ThemeName' ),
								'type' 			=> 'number_slider', 
								'options' 		=> array(    
									'min' 		=> 0,
									'max' 		=> 100,
									'show_input' => true
								),
								'value' 		=> '2', 
								'description' 	=> esc_html__( 'The number of items you want to show', 'ThemeName' ),
							),
							array(
								'name' => 'text_limit',
								'label' => esc_html__('Text Limit','corleone'),
								'type' => 'text',  // USAGE TEXT TYPE
								'description' => esc_html__( 'Enter number of text words limit to show content.', 'corleone' ),
								),
							array(
								'name' => 'cat',
								'label' => esc_html__('Select Categories', 'corleone'),
								'type' => 'checkbox',  // USAGE CHECKBOX TYPE
								'options' => array_flip(carleone_get_categories(array('taxonomy' => 'product_cat', 'hide_empty' => true, 'show_all' => false), true)),
								'value' => 'DEFAULT-CONTENT', 
								'description' => esc_html__('Choose product posts categories for which posts you want to show', 'lifeline2')
							),
						array(
							'name' => 'choose',
							'label' => 'Choice',
							'type' => 'select',  // USAGE SELECT TYPE
							'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'image' => 'Image',
									'icon' => 'Icon',
								)
							),
						array(
							'name' => 'image',
							'label' => esc_html__('Upload Your Image','corleone'),
							'type' => 'attach_image',  // USAGE TEXT TYPE need a default content
							'description' => 'Upload Your Image',
							'relation' => array(
										'parent'    => 'choose',
										'show_when' => 'image'
										// 'hide_when' => 'yes'
										// hide_when has the opposite effect
										// NOTICE: Only use one show_when or hide_when in the same time
										// 'show_when' => 'yes,ok,right'
										// 'show_when' => array( 'yes', 'ok', 'right' )
									)
						),
						array(
							'name' => 'icon',
							'label' => esc_html__('Select Your Icon','corleone'),
							'type' => 'icon_picker',  // USAGE TEXT TYPE need a default content
							'description' => 'Select Your Icon',
							'relation' => array(
										'parent'    => 'choose',
										'show_when' => 'icon'
										// 'hide_when' => 'yes'
										// hide_when has the opposite effect
										// NOTICE: Only use one show_when or hide_when in the same time
										// 'show_when' => 'yes,ok,right'
										// 'show_when' => array( 'yes', 'ok', 'right' )
									)
						),
						array(
							'name' => 'customclass',
							'label' => esc_html__('Custom Class Name','corleone'),
							'type' => 'text',  // USAGE TEXT TYPE need a default content
							'description' => 'Add Your Custom Class Name',
						),
						
						
						
						
					),
					//Display Style Tab//
					'style'=>array(
							array(
							'name' => 'custom_prostyle',
							'type' => 'css',
							'options' => array(
								array(
								   'screens' => 'any,1024,768,479-667', // use one or many screens, the "any" is desktop screen 
								   
								   //Style Apply For Parent Tag Without Selector
									'Typography' => array(
											array('property' => 'border', 'label' => 'Color'),
											array('property' => 'border-radius', 'label' => 'Border Radius'),
														
										),
										 //Style Apply For Child Tag With Selector
										'Title' => array(
												array(
												'property' => 'color', 
												'label' => 'paragrap Color',
												'selector'=>'+ .title'
												),
												array(
												'property' => 'font-size', 
												'label' => 'Font Size',
												'selector'=>'+ .title'
												),
												array(
												'property' => 'font-family', 
												'label' => 'Font Family',
												'selector'=>'+ .title'
												),
												array(
												'property' => 'font-style', 
												'label' => 'Font Family',
												'selector'=>'+ .title'
												),
											),
										'Description' => array(
												array(
												'property' => 'color', 
												'label' => 'paragrap Color',
												'selector'=>'+ .des'
												),
												array(
												'property' => 'font-size', 
												'label' => 'Font Size',
												'selector'=>'+ .des'
												),
												array(
												'property' => 'font-family', 
												'label' => 'Font Family',
												'selector'=>'+ .des'
												),
												array(
												'property' => 'font-style', 
												'label' => 'Font Family',
												'selector'=>'+ .des'
												),
											),	
								)	
							)
						)
					),	
					//--------end------------//			
                )
            ),
		]);
		
		
	}
  }
}



?>