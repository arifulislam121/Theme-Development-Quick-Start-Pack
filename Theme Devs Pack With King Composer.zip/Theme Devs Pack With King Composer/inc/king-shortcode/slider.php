<?php 

/*
  * Hero slider Shortcode 
  * =======================================================
  *    Register Hero slider shortcode
  * =======================================================
*/



add_action('init', 'ThemeName_hero_slider_maping_func');



if(!function_exists('ThemeName_hero_slider_maping_func')){
	function ThemeName_hero_slider_maping_func(){

		$slider_arg = array();
		$terms = get_terms( 'product_cat', array(
		    'hide_empty' => false,
		) );

		if(!is_wp_error( $terms )){
			foreach( $terms as $term ){
				$slider_arg[$term->slug] = $term->name;
			}
		}
		array_push( $slider_arg , 'ALL' ) ;



		if(function_exists('kc_add_map')){
			kc_add_map(
	 			array(
		        	'ThemeName_hero_slider' => array(
						'name'        => esc_html__('99fy: Hero Slider', '99fy'),
						'description' => esc_html__('Hero slider', '99fy'),
						'icon'        => 'fa-header',
						'category'    => 'CorleOne',
						'params'      => array(
				         	'General' => array(
				                array(
				                    'name'        	=> 'category',
				                    'label'       	=> esc_html__('Category','ThemeName'),
				                    'description' 	=> esc_html__('Show posts associated with certain categories.','ThemeName'),
				                    'type'        	=> 'multiple',
				                    'options' 		=> $slider_arg, 
				                    'value' 		=> '0'
				                ),
				                array(
				                    'name'        	=> 'order',
				                    'label'       	=> esc_html__('Order','ThemeName'),
				                    'description' 	=> esc_html__('Sort posts. ','ThemeName'),
				                    'type'        	=> 'select',
				                    'options' 		=> array( 
										'ASC' 		=> 'ASC ( Lowest to highest )',
										'DESC' 		=> 'DESC ( Highest to lowest )',
									), 
				                    'value' 		=> 'DESC'
				                ),
								array(
									'name' 			=> 'per_page',
									'label' 		=> esc_html__( 'Slide Count', 'ThemeName' ),
									'type' 			=> 'number_slider', 
									'options' 		=> array(    
										'min' 		=> 0,
										'max' 		=> 100,
										'show_input' => true
									),
									'value' 		=> '1', 
									'description' 	=> esc_html__( 'The number of items you want to show', 'ThemeName' ),
								),
								array(
									'type'			=> 'toggle',
									'label'			=> __( 'Auto Play', 'ThemeName' ),
									'name'			=> 'autoplay',
									'description'	=> __( 'The carousel automatically plays when site loaded.', 'ThemeName' ),
									'value'			=> 'yes',

								),

								array(
									'type'			=> 'toggle',
									'label'			=> __( 'Loop', 'ThemeName' ),
									'name'			=> 'loop',
									'description'	=> __( 'Infinity loop. Duplicate last and first items to get loop illusion', 'ThemeName' ),
									'value'			=> 'yes',

								),

								array(
									'type'			=> 'text',
									'label'			=> __( 'Autoplay Timeout', 'ThemeName' ),
									'name'			=> 'autoplaytimeout',
									'description'	=> __( 'Autoplay interval timeout.', 'ThemeName' ),
									'value'			=> 5000,

								),
								 array(
				                    'name'        	=> 'custom_css_class',
				                    'label'       	=> esc_html__('CSS Class','ThemeName'),
				                    'description' 	=> esc_html__('Custom css class for css customisation','ThemeName'),
				                    'type'        	=> 'text'
				                ),

				         	),

	                        'animate' => array(
								array(
									'name'    => 'animate',
									'type'    => 'animate'
								)
							), //End of animate
						)//prarams
					)
		        )
			);
		}
	}
}



if( !function_exists ('ThemeName_hero_slider_shortcode_func')){
	function ThemeName_hero_slider_shortcode_func( $atts,$content){

	extract($atts);

	//get kc classes
	$kc_classes = apply_filters( 'kc-el-class', $atts );
	if(!empty($custom_css_class)){
		$kc_classes[] = $custom_css_class;
	}

	$kc_classes = implode(' ', $kc_classes);

	$args = array(
	    'post_type'         => 'product',
	    'posts_per_page'    => $per_page == 0 ? -1 : $per_page,
	    'order'				=> $order,
	);

	if(!empty($category) && $category != '0'){
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => explode(',', $category),
			)
		);
	}

	$shortcode_id = 'shortcode_'.$_id;
	
	$query = new WP_Query($args);
	if($query->have_posts()):
	
	ob_start();

?>

<!-- Start Slider Area-->
<div id="<?php echo esc_attr( $shortcode_id ); ?>" class="sc_hero_slider slider-area <?php echo esc_attr( $kc_classes ); ?>">

	<div class="slider-active owl-carousel">
	<?php while($query->have_posts()): $query->the_post();

		$bg_image = '';
		$bg_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( ), 'full' );

		if($bg_image_url){
			$bg_image = 'style="background-image: url('. $bg_image_url[0].')"';
		}
	?>
		
		<div class="single-slider bg-img" <?php echo $bg_image; ?>>
	        <?php the_content( ); ?>
		</div>

	<?php
	    endwhile; // main loop
	    wp_reset_postdata();

	    $autoplay = $autoplay == 'yes' ? 'true' : 'false';
	    $loop     = $loop == 'yes' ? 'true' : 'false';
	    $autoplaytimeout    = $autoplaytimeout;

	?>
	</div>

</div>

<script>

(function($){

	if ($('#<?php echo esc_js($shortcode_id); ?> .slider-active').length) {
	  $('#<?php echo esc_js($shortcode_id); ?> .slider-active').owlCarousel({
	      loop: <?php echo esc_js($loop); ?>,
	      autoplay: <?php echo esc_js($autoplay); ?>,
	      autoplayTimeout: <?php echo esc_js($autoplaytimeout); ?>,
	      animateOut: 'fadeOut',
	      animateIn: 'fadeIn',
	      item: 1,
	      responsive: {
	          0: {
	              items: 1
	          },
	          768: {
	              items: 1
	          },
	          1000: {
	              items: 1
	          }
	      }
	  });
	}

})(jQuery);

</script>

<?php
	endif; // have posts

	return ob_get_clean();

	}
	add_shortcode('ThemeName_hero_slider','ThemeName_hero_slider_shortcode_func');
}