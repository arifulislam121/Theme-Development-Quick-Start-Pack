<?php

function corleoneabt_us($atts, $content)
{

	$corleone_about = shortcode_atts([
		'bg_img'        => ' ',
		'abt_img1'        => ' ',
		'abt_img2'        => ' ',
		'name'        => ' ',
		'des'        => ' ',
		'color'        => ' ',
		'customclass'        => ' ',
		'listiteam'        => ' ',
		'custom_style'        => ' ',
		
		
	
		
		

	], $atts);

	//creating variable
	extract($corleone_about);
	
	ob_start();

	//extra class add when access kc default css 
	$wrap_class=apply_filters( 'kc-el-class', $atts );
	$wrap_class[]=$custom_style;
	$extra_class=implode(' ',$wrap_class);
	
	?>
	

	
	            <!-- ABOUT-AREA -->
        <section class="about-area bg-attachment pt-120 pb-90 pt-xs-70 pb-xs-40 pt-md-90 pb-md-60" style="background-image: url(<?php echo wp_get_attachment_url(  QSInspection_set( $corleone_about, 'bg_img' )) ?>);" data-bottom-top="background-position: center 100%" data-top-bottom="background-position: center 0%">
            <div class="container">
                <div class="row align-items-center" >
                    <div class="col-md-5 mb-30">
                        <div class="about-imgs text-end" data-bottom-top="transform: translate(-200px, 0px); opacity: 0;" data-center-top="transform: translate(0, 0; opacity: 1;)">
                            <div class="about-img-wrap">
                                <div class="about-img bg-attachment" style="background-image: url(<?php echo wp_get_attachment_url(  QSInspection_set( $corleone_about, 'abt_img1' )) ?>);"></div>
                            </div><br>
                            <div class="about-img-wrap">
                                <div class="about-img bg-attachment" style="background-image: url(<?php echo wp_get_attachment_url(  QSInspection_set( $corleone_about, 'abt_img2' )) ?>);"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 mb-30 offset-md-1">

                        <div class="about-content" data-bottom-top="transform: translate(200px, 0px); opacity: 0;" data-center-top="transform: translate(0, 0); opacity: 1;">
                            <div class="section-title white-title mb-40 mb-xs-20 mb-md-30 <?php echo $extra_class;?>">
							
							
							<!---style attribuite add---->
							
                                <h3 class ="title"><?php echo QSInspection_set( $corleone_about, 'name' ); ?></h3>
								
                                <p class="des"><?php echo QSInspection_set( $corleone_about, 'des' ); ?></p>
                            </div>

                            <div class="row">
							
							
							
                               <?php foreach ( $listiteam as $arr ) : ?>
							
                                <div class="col-md-6 mb-30 mb-xs-20">
                                    <div class="section-item">
                                        <h4><?php echo QSInspection_set( $arr, 'listitle' ); ?></h4>
                                        <p><?php echo QSInspection_set( $arr, 'lisdes' ); ?></p>
                                    </div>
                                </div>
							<?php endforeach; ?>   	
								
                             
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ABOUT-AREA END -->

 


	
	
	<?php
	return ob_get_clean();
}
add_shortcode('about_us', 'corleoneabt_us');


add_action('init','about_us_section');

if(!function_exists('about_us_section')){

function about_us_section(){

if (function_exists('kc_add_map')) {
		kc_add_map([
			'about_us' => array(
                'name' => esc_html__('About Us','corleone'),
                'description' => 'This is my shortcode',
                'icon' => 'fa fa-code',
                'category' => 'CorleOne',
                'params' => array(
                    'content'=>array(
						//1st field
						array(
							'name' => 'bg_img',
							'label' => esc_html__('Background Image','corleone'),
							'type' => 'attach_image',  // USAGE TEXT TYPE need a default content
							'description' => 'Section Background Image',
						),
						//2nd field
						array(
							'name' => 'abt_img1',
							'label' => esc_html__('About Image-01','corleone'),
							'type' => 'attach_image',  // USAGE TEXT TYPE need a default content
							'description' => 'About Image-01',
						),
						//3rd field
						array(
							'name' => 'abt_img2',
							'label' => esc_html__('About Image-02','corleone'),
							'type' => 'attach_image',  // USAGE TEXT TYPE need a default content
							'description' => 'About Image-02',
						),
						//4th field
						array(
							'name' => 'name',
							'label' => esc_html__('Top Title','corleone'),
							'type' => 'text',  // USAGE TEXT TYPE
							'value' => 'I am King Composer Title', // remove this if you do not need a default content
							'description' => 'Section Title',
						),
						//5th field
						array(
							'name' => 'des',
							'label' => esc_html__('Section Description','corleone'),
							'type' => 'textarea',  // USAGE TEXT TYPE
							'value' => 'I am King Composer Description', // remove this if you do not need a default content
							'description' => 'Section Description',
						),
						
						//6th field
						array(
							'type'			=> 'group',
							'label'			=> esc_html__('List Options', 'corleone'),
							'name'			=> 'listiteam',
							'description'	=> __( 'Add Your List Item Attribute', 'corleone' ),
							'options'		=> array('add_text' => __('Add new Short Description', 'corleone')),
							'value' => base64_encode( json_encode(array(
									"1" => array(
										"value" => "90",
										"label" => "Development"
									),
									"2" => array(
										"value" => "80",
										"label" => "Design"
									),
									"3" => array(
										"value" => "70",
										"label" => "Marketing"
									)
								) ) ),		
							'params' => array(
								array(
									'type' => 'text',
									'label' => __( 'label', 'KingComposer' ),
									'name' => 'label',
									'description' => __( 'Enter value of bar.', 'KingComposer' ),
									'admin_label' => true,
								),
								array(
									'type' => 'text',
									'label' => __( 'title', 'corleone' ),
									'name' => 'listitle',
									'description' => __( 'Enter Your Title', 'corleone' ),
									'admin_label' => true,
								),
								array(
									'type' => 'textarea',
									'label' => __( 'Descriptions', 'corleone' ),
									'name' => 'lisdes',
									'description' => __( 'Enter Your Description', 'corleone' ),
									'admin_label' => true,
								),
								
							),
						),
						array(
							'name' => 'choose',
							'label' => 'Choice',
							'type' => 'select',  // USAGE SELECT TYPE
							'options' => array(  // THIS FIELD REQUIRED THE PARAM OPTIONS
									'image' => 'Image',
									'icon' => 'Icon',
								)
							),
						array(
							'name' => 'image',
							'label' => esc_html__('Upload Your Image','corleone'),
							'type' => 'attach_image',  // USAGE TEXT TYPE need a default content
							'description' => 'Upload Your Image',
							'relation' => array(
										'parent'    => 'choose',
										'show_when' => 'image'
										// 'hide_when' => 'yes'
										// hide_when has the opposite effect
										// NOTICE: Only use one show_when or hide_when in the same time
										// 'show_when' => 'yes,ok,right'
										// 'show_when' => array( 'yes', 'ok', 'right' )
									)
						),
						array(
							'name' => 'icon',
							'label' => esc_html__('Select Your Icon','corleone'),
							'type' => 'icon_picker',  // USAGE TEXT TYPE need a default content
							'description' => 'Select Your Icon',
							'relation' => array(
										'parent'    => 'choose',
										'show_when' => 'icon'
										// 'hide_when' => 'yes'
										// hide_when has the opposite effect
										// NOTICE: Only use one show_when or hide_when in the same time
										// 'show_when' => 'yes,ok,right'
										// 'show_when' => array( 'yes', 'ok', 'right' )
									)
						),
						array(
							'name' => 'customclass',
							'label' => esc_html__('Custom Class Name','corleone'),
							'type' => 'text',  // USAGE TEXT TYPE need a default content
							'description' => 'Add Your Custom Class Name',
						),
						
						
						
						
					),
					//Display Style Tab//
					'style'=>array(
							array(
							'name' => 'custom_style',
							'type' => 'css',
							'options' => array(
								array(
								   'screens' => 'any,1024,768,479-667', // use one or many screens, the "any" is desktop screen 
								   
								   //Style Apply For Parent Tag Without Selector
									'Typography' => array(
											array('property' => 'border', 'label' => 'Color'),
											array('property' => 'border-radius', 'label' => 'Border Radius'),
														
										),
										 //Style Apply For Child Tag With Selector
										'Title' => array(
												array(
												'property' => 'color', 
												'label' => 'paragrap Color',
												'selector'=>'+ .title'
												),
												array(
												'property' => 'font-size', 
												'label' => 'Font Size',
												'selector'=>'+ .title'
												),
												array(
												'property' => 'font-family', 
												'label' => 'Font Family',
												'selector'=>'+ .title'
												),
												array(
												'property' => 'font-style', 
												'label' => 'Font Family',
												'selector'=>'+ .title'
												),
											),
										'Description' => array(
												array(
												'property' => 'color', 
												'label' => 'paragrap Color',
												'selector'=>'+ .des'
												),
												array(
												'property' => 'font-size', 
												'label' => 'Font Size',
												'selector'=>'+ .des'
												),
												array(
												'property' => 'font-family', 
												'label' => 'Font Family',
												'selector'=>'+ .des'
												),
												array(
												'property' => 'font-style', 
												'label' => 'Font Family',
												'selector'=>'+ .des'
												),
											),	
								)	
							)
						)
					),	
					//--------end------------//			
                )
            ),
		]);
		
		
	}
  }
}



?>