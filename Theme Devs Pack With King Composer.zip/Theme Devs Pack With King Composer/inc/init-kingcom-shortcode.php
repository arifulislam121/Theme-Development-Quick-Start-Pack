<?php 



// Theme king-shortcode

 require_once get_theme_file_path() . '/inc/king-shortcode/about-us.php';
 require_once get_theme_file_path() . '/inc/king-shortcode/slider.php';
 require_once get_theme_file_path() . '/inc/king-shortcode/off-road-product-slider.php';
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 ?>